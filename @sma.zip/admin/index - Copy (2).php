<!DOCTYPE html>
<html lang="en">
<head> 
  <title>School Backend-Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/logo_s.jpg" type="image/x-icon">
  <meta name="Keywords" content="">
  <meta name="Description" content="App to allow schools to manage their students, log payments, daily progress report etc from a parent - centre viewpoint with ease.">
   <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
 <!--<script src="js/jquery.min.js"></script>
  <script src="js/angular.js"></script>
	<script src="js/angular-route.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/sidenavjs.js"></script>
<link rel="stylesheet" href="css/dskstyles.css"/>
<link rel="stylesheet" href="css/sidenavcentrecss.css"/>-->

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sidebars.css" rel="stylesheet">
	<link href="../assets/dist/css/offcanvas.css" rel="stylesheet">

<style>
/* .sidenav a:visited, .offcanvas a:focus{
    color:#fff;
} */

/* Note: Try to remove the following lines to see the effect of CSS positioning */
.affix {
      top: 0;
      width: 100%;
  }

.affix + .container-fluid {
      padding-top: 70px;
  }
  
  .ellpsi:hover{
	font-size:0.98em;
	color:#ffcb05;
	cursor:pointer;
	}
	.ellpsi{
	font-size:1.2em;
	}
</style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60" ng-app="myApp">

<div class="row" style="">
<div class="col-2 col-sm-1" style="">
  <div class="" style="width:5.5em;">
  
    <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
      <li>
        <a href="#cdailyreports" class="nav-link active py-3 border-bottom" title="Progress Report" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Progress Report"><i class="bi bi-ui-checks-grid" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link py-3 border-bottom" aria-current="page" title="Attendance" data-bs-toggle="tooltip" data-bs-placement="right">
          <span aria-label="Attendance"><i class="bi bi-calendar-check" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#staffmgr" class="nav-link py-3 border-bottom" title="Manage Teachers" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Manage Teachers"><i class="bi bi-plugin" style="font-size:2em;"></i></span>
        </a>
      </li>
	    <li>
        <a href="#pupilsprofile" class="nav-link py-3 border-bottom" title="Set pupils Profile" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Set pupils Profile"><i class="bi bi-person-vcard" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#" class="nav-link py-3 border-bottom" title="Messages" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Messages"><i class="bi bi-chat-left-text" style="font-size:2em;"></i></span>
        </a>
      </li>
    </ul>
    <div class="dropdown border-top">
      <a href="#" class="d-flex align-items-center justify-content-center p-3 link-dark text-decoration-none dropdown-toggle" id="dropdownUser3" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="https://github.com/mdo.png" alt="mdo" width="24" height="24" class="rounded-circle">
      </a>
      <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser3">
        <li><a class="dropdown-item" href="#">New project...</a></li>
        <li><a class="dropdown-item" href="#">Settings</a></li>
        <li><a class="dropdown-item" href="#">Profile</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="#">Sign out</a></li>
      </ul>
    </div>
  </div>
</div>

 <div class="col-10 col-sm-11">
      <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Daily Progress Report</h1>
       
<div class="card">
<div class="card-body">
<p>
<h3>View by</h3>
  <div class="form-group">
  <label for="pupiltclass">Pupil Class:</label>
  <select class="form-control" id="pupiltclass">
	<option>---</option>
    <option>Reception 1</option>
    <option>Reception 2</option>
    <option>Nursery 1</option>
    <option>Nursery 2</option>
	<option>Basic 1</option>
	<option>Basic 2</option>
	<option>Basic 3</option>
	<option>Basic 4</option>
	<option>Basic 5</option>
	<option>Basic 6</option>
  </select>
</div>
</p>
<hr>
<h3>Week 5</h3>
<h4>Today - <?php print date("D, d M Y")?> |<b> Basic 4</b></h4>



<button type="button" class="btn btn-primary btn-xs" onclick="pfinck();scrolltoView();">Previous Weeks</button>
<button type="button" class="btn btn-primary btn-xs" onclick="dprmondays();dprtuesdays();dprwednesdays();dprthursdays();dprfridays();">Next/Now</button>


<div class="row" id="dprviews">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotattendance">Attendance</label>
  <select class="form-control" id="rpotattendance">
    <option value="444">---</option>
	<option value="0">I was early to school</option>
    <option value="1">I cried when I was dropped</option>
    <option value="2">I was late for assembly</option>
    <option value="3">I was late to school</option>
	<option value="4">I was absent from school</option>
  </select>
</div>
</div>
<div class="col-sm-1" style="">
</div>
<div class="col-sm-7" style="">
<table class="table" id="attendance" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Attendance</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>0: I was early to school</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	 <tr style="">
        <td>1: I cried when I was dropped</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>2: I was late for assembly</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>3: I was late to school</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>4: I was absent from school</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpottemperamnet">Temperament/Mood</label>
  <select class="form-control" id="rpottemperamnet">
  <option value="0">---</option>
    <option value="5"> I was quiet</option>
    <option value="6">I was happy</option>
    <option value="7">I was active</option>
    <option value="8">I was moody</option>
	<option value="9">I was sleepy</option>
	<option value="10">I was friendly</option>
	<option value="11">I was unhappy</option>
	<option value="12">I wasm curious</option>
	<option value="13">I was stubborn</option>
	<option value="14">I cried a lot today</option>
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="temperamntMood" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Temperament/Mood</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>5: I was quiet</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>6: I was happy</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>7: I was active</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>8: I was moody</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>9: I was sleepy</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>10: I was friendly</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>11: I was unhappy</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>12: I was curious</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>13: I was stubborn</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>14: I cried a lot today</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotlearning">Learning / Class Participation</label>
  <select class="form-control" id="rpotlearning">
  <option value="0">---</option>
    <option value="15">I took part in today's activities</option>
    <option value="16">I was not interested in todays activities</option>
    <option value="17">I enjoyed my number work</option>
    <option value="18">I enjoyed my letter work</option>
	<option value="19">I enjoyed rhymes</option>
	<option value="20">I enjoyed Audio-Visual aid/TV programmes</option>
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="learningpartcptn" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Learning / Class Participation</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>15: I took part in today's activities</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>16: I was not interested in todays activities</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>17: I enjoyed my number work</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>18: I enjoyed my letter work</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>19: I enjoyed rhymes</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>20: I enjoyed Audi-Visual aid/TV programmes</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotnaprest">Nap / Rest period</label>
  <select class="form-control" id="rpotnaprest">
  <option value="0">---</option>
    <option value="21">I slept for a short time</option>
    <option value="22">I slept today</option>
    <option value="23">I did not sleep at all</option>
    <option value="24">I slept for a long time</option>
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="napnrest" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Nap / Rest period</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>21: I slept for a short time</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>22: I slept today</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>23: I did not sleep at all</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>24: I slept for a long time</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>


<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpottoileting">Toileting / Potty Time</label>
  <select class="form-control" id="rpottoileting">
  <option value="0">---</option>
    <option value="25">I wet myself</option>
    <option value="26">I did not wet myself</option>
    <option value="27">I used the toilet with some help</option>
    <option value="28">I used the toilet myself</option>
	<option value="29">My diapers were changed</option>
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="toiletingpotty" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Toileting / Potty Time</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>25: I wet myself</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>26: I did not wet myself</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>27: I used the toilet with some help</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>28: I used the toilet myself</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>29: My diapers were changed</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpothlthstatus">State of health</label>
  <select class="form-control" id="rpothlthstatus">
  <option value="0">---</option>
    <option value="30">I was well</option>
    <option value="31">I vomitted</option>
    <option value="32">I was feverish</option>
    <option value="33">I had slight headache</option>
	<option value="34">I had stomache ache</option>
	<option value="35">I was at the sick bay</option>
	<option value="36">I had a cold</option>
	<option value="37">I was stooling</option>
	<option value="38">My temperature was a bit high</option>	
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="healthstatus" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>State of health</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>30: I was well</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>31: I vomitted</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>32: I was feverish</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>33: I had slight headache</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>34: I had stomache ache</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>35: I was at the sick bay</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>36: I had a cold</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>37: I was stooling</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>38: My temperature was a bit high</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotrecreation">Recreation/Play</label>
  <select class="form-control" id="rpotrecreation">
  <option value="0">---</option>
    <option value="39">I played outdoor</option>
    <option value="40">I played indoors</option>
    <option value="41">I played with my friends</option>
    <option value="42">I was rough at play</option>
	<option value="43">I did not play</option>
	<option value="44">I played alone</option>
  </select>
</div>
</div>
<div class="col-sm-1">

</div>
<div class="col-sm-7">
<table class="table" id="recraatnplay" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Recreation/Play</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>39: I played outdoor</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>40: I played indoors</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>41: I played with my friends</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>42: I was rough at play</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>43: I did not play</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>44: I played alone</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotappearance">Appearance/Dressing</label>
  <select class="form-control" id="rpotappearance">
  <option value="0">---</option>
    <option value="45">My hair was tidy</option>
    <option value="46">My hair was untidy today</option>
    <option value="47">I was roughly dressed</option>
    <option value="48">I was neatly dressed</option>
	<option value="49">I did not wear the correct uniform to school</option>
	<option value="50">I did not wear my socks</option>
  </select>
</div>
</div>
<div class="col-sm-1"></div>
<div class="col-sm-7">
<table class="table" id="appearancedressn" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Appearance/Dressing</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>45: My hair was tidy</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>46: My hair was untidy today</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>47: I was roughly dressed</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>48: I was neatly dressed</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>49: I did not wear the correct uniform to school</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  	  <tr style="">
        <td>50: I did not wear my socks</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpothwork">Home Assignment</label>
  <select class="form-control" id="rpothwork">
    <option value="0">---</option>
    <option value="51">I did my homework</option>
    <option value="52">I did not do my home work</option>
    <option value="53"> My home work was neatly done</option>
    <option value="54">My home work was rough</option>
	<option value="55"> I did not bring my home work</option>
  </select>
</div>
</div>
<div class="col-sm-1">

</div>
<div class="col-sm-7">
<table class="table" id="homework" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Home Assignment</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
	<td>51: I did my homework</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>52: I did not do my home work</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>53: My home work was neatly done</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>54: My home work was rough</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>55: I did not bring my home work</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
</div>
</div>

<div class="row">
<div class="col-sm-4">
<div class="form-group dproptions">
  <label for="rpotmeals">Meal</label>
  <select class="form-control" id="rpotmeals">
    <option value="0">---</option>
	<option value="56">I ate all my food</option>
    <option value="57">I ate a little of my food</option>
    <option value="58">I ate none of my food</option>
    <option value="59">I did not like my food</option>
	<option value="60">I wanted to eat the school food</option>
  </select>
</div>
<div class="dproptions">
<hr>
<label class="radio-inline" style="color:#015393;font-size:0.75em;"><input type="radio" name="datechoice10" id="todaydate" value="" onclick="gtPresentdate()" checked>Today? <span style="color:#015393;font-size:0.75em;"><?php print date('Y-m-d');?></span></label> 

<label class="radio-inline" style="color:#015393;font-size:0.75em;"><input type="radio" name="datechoice10" id="otherdateropt" value="" onclick="dprOtherdate();">Other day?</label>

<hr>
<div class="form-group" id="otherdatediv" style="display:none;">
  <input type="date" class="form-control" id="otherdate">
</div>
<input type="hidden" id="getdatchosenid" name="getdatchosen">
<hr>
<button otherdatemealdivtype="button" class="btn btn-default btn-block" id="pushalldailyreport">Update</button>
</div>
</div>
<div class="col-sm-1">

</div>
<div class="col-sm-7">
<table class="table" id="meals" style="font-size:0.85em;width:100%;">
    <thead>
      <tr>
	  <th>Meal</th>
        <th>M</th>
        <th>T</th>
        <th>W</th>
		<th>Th</th>
        <th>F</th>
      </tr>
    </thead>
    <tbody>
	<tr style="">
        <td>56: I ate all my food</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>57: I ate a little of my food</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>58: I ate none of my food</td>
        <td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>59: I did not like my food</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
	  <tr style="">
        <td>60: I wanted to eat the school food</td>
		<td>
		<div class="weekindicators mondays" style=""></div>
		</td>
        <td>
		<div class="weekindicators tuesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators wednesdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators thursdays" style=""></div>
		</td>
		<td>
		<div class="weekindicators fridays" style=""></div>
		</td>
      </tr>
    </tbody>
  </table>
<p><a href="#">Would you want to make an <strong>update</strong> for this pupil?</a></p>
</div>
</div>







</div>   
</div> 
      </div>
    </div>
   </div>
   
</div>

<div class="container py-4">
  
<div class="row">
<div class="col-sm-12 mt-2">
      <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Attendance Manager</h1>
        <p class="col-md-8 fs-4"></p>
		
		
		
		
		
		
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
    </div>
   </div>
   </div>
   
   
<div class="row">
      <div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Teacher Manager</h1>
<div class="row">
    <div class="col-sm-4">
      <h3>Basic Info</h3>
	  <div class="form-group">
  <label for="stafTitle">Title:</label>
  <select class="form-control" id="stafTitle">
	<option value="0">Mr.</option>
	<option value="1">Mrs.</option>
    <option value="2">Miss</option>
  </select>
</div>
  <div class="form-group">
  <label for="jobDescrtn">Job Designation:</label>
  <select class="form-control" id="jobDescrtn">
    <option value="0">Teacher</option>
	<option value="1">Ast.Teacher</option>
    <option value="2">Admin</option>
  </select>
</div>
     <div class="form-group">
    <label for="stafsurName">Surname:</label>
    <input type="text" class="form-control" id="stafsurName">
  </div>
   <div class="form-group">
    <label for="staffName">Firstname:</label>
    <input type="text" class="form-control" id="staffName">
  </div>
   <div class="form-group">
    <label for="stafPwd">Create Password:</label>
    <input type="text" class="form-control" id="stafPwd" maxlength="8">
  </div>
  <!-- <div class="form-group">
    <label for="stafoName">Othername:</label>
    <input type="text" class="form-control" id="stafoName">
  </div>

   <div class="form-group">
    <label for="stafPix">Add Picture:</label>
    <input type="file" class="form-control" id="stafPix">
  </div>-->

</div>
   <div class="col-sm-4">
      <h3>Education</h3>
	   <div class="form-group">
  <label for="stafQualifc">Qualification:</label>
  <select class="form-control" id="stafQualifc">
    <option value="0">SSCE</option>
	<option value="1">L.Diploma</option>
    <option value="2">H.Diploma</option>
	<option value="3">Degree</option>
	<option value="4">Masters</option>
	<option value="5">Doctorate</option>
  </select>
</div>

<hr>
 <div class="form-group">
  <label for="selClassTaught">Class Taught:</label>
  <select class="form-control" id="selClassTaught">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>

<div class="form-group">
  <label for="classalias1" title="">Class Arm:</label>
  <select class="form-control" id="classalias1">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>

</div>
<div class="col-sm-4">
<h3>View</h3>
<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="../#home">Preview</a></li>
  <!--<li><a data-toggle="tab" href="../#menu1">Assign</a></li>-->
</ul>
<table class="table table-sm table-bordered">
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">names</th>
            <th scope="col">edit</th>
            <th scope="col">suspend</th>
          </tr>
          </thead>
          <tbody id="mypreviewlist"></tbody>
        </table>
		</div>
</div>
		<button type="button" class="btn btn-info mt-2" id="poststaffscontent">Submit</button>
      </div>
   </div>
 </div>
   
<div class="row">
<div class="col-sm-12 mt-2">
      <div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Pupil Manager</h1>
        <p class="col-md-8 fs-4"></p>
		<nav>
          <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-basicinfo-tab" data-bs-toggle="tab" data-bs-target="#basicInfo" type="button" role="tab" aria-controls="nav-admin" aria-selected="false">Basic Info</button>			
            <button class="nav-link" id="nav-viewpupils-tab" data-bs-toggle="tab" data-bs-target="#viewpupils" type="button" role="tab" aria-controls="viewpupils" aria-selected="true">Pupils Profile</button>
          </div>
        </nav>
		<div class="tab-content" id="nav-tabContent">
<div class="tab-pane fade active show" id="basicInfo" role="tabpanel" aria-labelledby="basicInfo">
 <div class="row">
 
    <div class="col-sm-4">
      <h3>Pupils-Details</h3>
    <div class="form-group">
    <label>Pupil's Name:</label>
    <input type="text" class="form-control" id="pupilsName0" placeholder="Surname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName1" placeholder="Firstname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName2" placeholder="Middlename" style="margin:4px 0px;">
  </div>
  
   <!--
   <div id="uploadmsg">Ok</div>
   <form action="" enctype="multipart/form-data" method="post" name="pupilpixtured" id="pupilpixture">
  <div class="form-group">
    <label for="pupilsPix">Upload picture:</label>
    <input type="file" class="form-control" id="pupilsPix">
	<input type="button" class="btn btn-primary btn-xs" id="pupilimgbtn" onclick="determImgCatgox(pupilpixture.id)" value="upload">
  </div>
  </form>-->
  <div class="form-group">
  <label for="selgender">Gender:</label>
  <select class="form-control" id="selgender">
    <option value="0">Female</option>
    <option value="1">Male</option>
  </select>
</div>

 <div class="form-group">
  <label for="selPresntclass">Class:</label>
  <select class="form-control" id="selPresntclass">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
 <div class="form-group">
  <label for="classalias2" data-toggle="tooltip" title="Edit in settings">Class Arm: <i class="fa fa-info-circle" style="color:#101010;" title=""></i></label>
  <select class="form-control" id="classalias2">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>
    </div>
  
    <div class="col-sm-4">
    
    </div>
  </div>
  </div>
	
		  
	<div class="tab-pane fade" id="viewpupils" role="tabpanel" aria-labelledby="viewpupils">
    <div class="row">
	
    <div class="col-sm-4">
	<h3>Basic 4</h3>
	<hr>
	</div>
	<div class="col-sm-4">
	<img src="images/happiness-4628417_1920.jpg" alt="" class="">
	</div>
	<div class="col-sm-4">
	<p>Kemi Thomas</p>
	
	<hr>
	</div>
	</div>
          </div>
        </div>
		<button type="button" class="btn btn-info mt-2" id="postpupilscontent">Submit</button>
      </div>
    </div>
   </div>
   </div>
   

<div class="row">
<div class="col-sm-12 mt-2">
<div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-2">
        <h1 class="display-5 fw-bold">Messages</h1>
        <p class="col-md-8 fs-4"></p>
		<div class="card" style="border:1px solid teal;background-color:#fff; border-radius:5px;">
<div class="card-body">
<div class="row" style="padding:5px;">
<div class="col-sm-2 bg-light" style="border-radius:10px 0px 0px 10px;">
<div style="padding:15px 3px 0px 3px;display: block;margin:0 auto;" id="activemessages"></div>
<div style="margin:25px auto;">
<button type="button" class="btn btn-outline-dark bt-sm" style="font-size:0.7em;" id="getloadtest">New</button>
</div>
</div>
<div class="col-sm-10" style="border-radius:0px 10px 10px 0px;padding:5px;">
<!--////-->
<div class="row">
<div class="col-sm-12" id="showblitzedchat">meta details sender here</div>
</div>
<!--////-->
<div class="row">
<div class="col-sm-12 dropdown">
<div style="float:right;" class="dropdown-center">
<span class="ellpsi" id="dropdownMenuButtonSM" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical" title="Settings"></i></span>

   <ul class="dropdown-menu" style="">
              <li><a class="dropdown-item" href="#">star</a></li>
              <!--<li><a class="dropdown-item" href="#">Report</a></li>
              <li><a class="dropdown-item" href="#">Delete conversation</a></li>-->
            </ul>
  </div>
</div>
</div>
<!--Chat Pond -->
<div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">New Messages</h6>
	<div class="d-flex text-muted pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>

      <p class="pb-3 mx-4 mb-0 small lh-sm border-bottom">
        <strong class="d-block text-gray-dark">full name</strong>
        Some representative placeholder content, with some information about this user. Imagine this being some sort of status update, perhaps?
		<div class="d-flex justify-content-between">
          <a href="#">reply</a>
        </div>
      </p>
    </div>
    <div class="d-flex text-muted pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>

      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
		<p class="pb-3 mx-3">
       
        Some representative placeholder content, with some information about this user. Imagine this being some sort of status update, perhaps?
		
      </p>
          <a href="#">reply</a>
        </div>
        <span class="d-block">@username</span>
      </div>
	
    </div>
    <div class="d-flex text-muted pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>

      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
          <a href="#">Follow</a>
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>
    <div class="d-flex text-muted pt-3">
      <svg class="bd-placeholder-img flex-shrink-0 me-2 rounded" width="32" height="32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: 32x32" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#007bff"></rect><text x="50%" y="50%" fill="#007bff" dy=".3em">32x32</text></svg>

      <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
        <div class="d-flex justify-content-between">
          <strong class="text-gray-dark">Full Name</strong>
          <a href="#">Follow</a>
        </div>
        <span class="d-block">@username</span>
      </div>
    </div>
    <small class="d-block text-end mt-3">
      <a href="#">All suggestions</a>
    </small>
  </div>
  
<div id="chatponddiv" style="max-height:200px;overflow-y:scroll;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesquLorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesqu

Lorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesqu

</div>
<!--Chat Pond ends-->
</div>
<div class="col-sm-1" style="">
<div class="row">
<div class="col-sm-12">
<button type="button" class="btn btn-outline-warning bt-sm" style="font-size:0.7em;float:right;border-radius:500px;width:48px;height:48px;" title="blitzer" id="blitzer">
<i class="bi bi-lightning-charge" style="cursor:pointer;"></i>
</button>
</div>
</div>
</div>
</div>
<!--===========1=============-->
<div class="row">
<div class="col-sm-1">
<!--<button type="button" class="btn btn-outline-warning bt-sm" id="rebuild">Rebuild </button>-->
</div>
<div class="col-sm-11">
message notification
</div>
</div>
<!--===========2=============-->
<div class="row" style="margin-top:5px;">
<div class="col-sm-6" style="">
<form class="form-inline" action="" style="margin:0 auto;" id="findmembrfrm" name="findmembrfrm">
    <input class="form-control mr-sm-2" type="text" placeholder="find members" style="height:32px;" id="mwembrschat" name="mwembrschat">
    <button class="btn btn-primary btn-sm mt-1" type="button" id="mwembrschatbtn" name="mwembrschatbtn">Search</button>
  </form>

  <br>
  <table class="table" style="">
  <tbody id="searchedmembrlist" name="searchedmembrlist"></tbody>
  </table>
<p id="listtostore"></p>
<span>
<button type="button" class="btn btn-outline-dark btn-sm" style="font-size:0.7em;" id="membrtsrchd">message</button>
</span>
</div>
<div class="col-sm-6">
<form>
<div class="form-group">
  <textarea class="form-control" rows="3" id="messagerscweekly" name="msagerscweekly" disabled style="cursor:not-allowed;" title="find member to message;"></textarea>
</div>
</form>
<button type="button" class="btn btn-outline-dark bt-sm float-end mt-1" id="messagerybtn" name="messagerybtn" style="font-size:0.7em;" disabled title="send">send</button>
</div>

</div>
<!--============3============-->
<div class="row">
<div class="col-sm-2">
</div>
<div class="col-sm-4">
<p></p>
</div>
<div class="col-sm-6" style="margin-top:5px;">
</div>
</div>
<!--============4============-->
</div>
</div>
      </div>
    </div>
   </div>
   </div>
</div>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Made By <a href="tel:+23408020597327" title="AlphaTrax">AlphaTrax Software</a> for You &copy; <?php print date('Y') ?></p>
</footer>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/sidebars.js"></script>
<script src="../assets/dist/js/offcanvas.js"></script>
<script src="js/teacherentry.js"></script>
<script src="../assets/scripts/pupilsprofile/js/pupilsprofiletodb.js"></script>
<!--<script src="rotescripts/swallowr/pupilsprofile/js/pupilpixuploader.js"></script>
<script src="rotescripts/swallowr/pupilsprofile/js/pupilsprofiletodb.js"></script>
<script src="rotescripts/swallowr/dailyprogsreports/js/dailyprogreport.js"></script>
<script src="rotescripts/swallowr/dailyprogsreports/js/weeklyretriev.js"></script>
<script src="rotescripts/renderer/dailyprogsreports_v/js/pullitemsdpr.js"></script>
<script src="js/messageschat.js"></script>-->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){
   
      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
    });
  });
  
  // Slide in elements on scroll
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
</body>
</html>