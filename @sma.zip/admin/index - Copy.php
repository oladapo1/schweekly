<!DOCTYPE html>
<html lang="en">
<head> 
  <title>School Backend-Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/logo_s.jpg" type="image/x-icon">
  <meta name="Keywords" content="">
  <meta name="Description" content="App to allow schools to manage their students, log payments, daily progress report etc from a parent - centre viewpoint with ease.">
   <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
 <!--<script src="js/jquery.min.js"></script>
  <script src="js/angular.js"></script>
	<script src="js/angular-route.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/sidenavjs.js"></script>
<link rel="stylesheet" href="css/dskstyles.css"/>
<link rel="stylesheet" href="css/sidenavcentrecss.css"/>-->

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sidebars.css" rel="stylesheet">
<style>
/* .sidenav a:visited, .offcanvas a:focus{
    color:#fff;
} */

/* Note: Try to remove the following lines to see the effect of CSS positioning */
.affix {
      top: 0;
      width: 100%;
  }

.affix + .container-fluid {
      padding-top: 70px;
  }
  
  .ellpsi:hover{
	font-size:0.98em;
	color:#ffcb05;
	cursor:pointer;
	}
	.ellpsi{
	font-size:1.2em;
	}
</style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60" ng-app="myApp">

<div class="row" style="">
<div class="col-2 col-sm-1" style="">
  <div class="" style="width:5.5em;">
  
    <ul class="nav nav-pills nav-flush flex-column mb-auto text-center">
      <li>
        <a href="#cdailyreports" class="nav-link active py-3 border-bottom" title="Progress Report" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Progress Report"><i class="bi bi-ui-checks-grid" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li class="nav-item">
        <a href="#" class="nav-link py-3 border-bottom" aria-current="page" title="Attendance" data-bs-toggle="tooltip" data-bs-placement="right">
          <span aria-label="Attendance"><i class="bi bi-calendar-check" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#staffmgr" class="nav-link py-3 border-bottom" title="Manage Teachers" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Manage Teachers"><i class="bi bi-plugin" style="font-size:2em;"></i></span>
        </a>
      </li>
	    <li>
        <a href="#pupilsprofile" class="nav-link py-3 border-bottom" title="Set pupils Profile" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Set pupils Profile"><i class="bi bi-person-vcard" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#" class="nav-link py-3 border-bottom" title="Messages" data-bs-toggle="tooltip" data-bs-placement="right">
          <span class="" aria-label="Messages"><i class="bi bi-chat-left-text" style="font-size:2em;"></i></span>
        </a>
      </li>
    </ul>
    <div class="dropdown border-top">
      <a href="#" class="d-flex align-items-center justify-content-center p-3 link-dark text-decoration-none dropdown-toggle" id="dropdownUser3" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="https://github.com/mdo.png" alt="mdo" width="24" height="24" class="rounded-circle">
      </a>
      <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser3">
        <li><a class="dropdown-item" href="#">New project...</a></li>
        <li><a class="dropdown-item" href="#">Settings</a></li>
        <li><a class="dropdown-item" href="#">Profile</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="#">Sign out</a></li>
      </ul>
    </div>
  </div>
</div>

 <div class="col-10 col-sm-11">
      <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Daily Progress Report</h1>
       
	   
	   
	   
	   
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
    </div>
   </div>
   
</div>

<div class="container py-4">
  
<div class="row">
<div class="col-sm-12 mt-2">
      <div class="p-5 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Attendance Manager</h1>
        <p class="col-md-8 fs-4"></p>
		
		
		
		
		
		
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
    </div>
   </div>
   </div>
   
   
<div class="row">

      <div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Teacher Manager</h1>
<div class="row">
    <div class="col-sm-4">
      <h3>Basic Info</h3>
	  <div class="form-group">
  <label for="stafTitle">Title:</label>
  <select class="form-control" id="stafTitle">
    <option>---</option>
	<option>Mr.</option>
	<option>Mrs.</option>
    <option>Miss</option>
  </select>
</div>
  <div class="form-group">
  <label for="jobDescrtn">Job Designation:</label>
  <select class="form-control" id="jobDescrtn">
  <option>---</option>
    <option>Teacher</option>
	<option>Ast.Teacher</option>
    <option>Admin</option>
  </select>
</div>
     <div class="form-group">
    <label for="stafsurName">Surname:</label>
    <input type="text" class="form-control" id="stafsurName">
  </div>
   <div class="form-group">
    <label for="staffName">Firstname:</label>
    <input type="text" class="form-control" id="staffName">
  </div>
   <div class="form-group">
    <label for="stafoName">Othername:</label>
    <input type="text" class="form-control" id="stafoName">
  </div>

   <div class="form-group">
    <label for="stafPix">Add Picture:</label>
    <input type="file" class="form-control" id="stafPix">
  </div>

</div>
   <div class="col-sm-4">
      <h3>Education</h3>
	   <div class="form-group">
  <label for="stafQualifc">Qualification:</label>
  <select class="form-control" id="stafQualifc">
  <option>---</option>
    <option>SSCE</option>
	<option>L.Diploma</option>
    <option>H.Diploma</option>
	<option>Degree</option>
	<option>Masters</option>
	<option>Doctorate</option>
  </select>
</div>
<hr>
 
     <div class="form-group">
  <label for="stafgender">Gender:</label>
  <select class="form-control" id="stafgender">
  <option>---</option>
    <option>Female</option>
    <option>Male</option>
  </select>
</div>

<hr>
 <div class="form-group">
  <label for="selClassTaught">Class Taught:</label>
  <select class="form-control" id="selClassTaught">
  <option>---</option>
    <option>Reception 1</option>
    <option>Reception 2</option>
    <option>Nursery 1</option>
    <option>Nursery 2</option>
	<option>Basic 1</option>
	<option>Basic 2</option>
	<option>Basic 3</option>
	<option>Basic 4</option>
	<option>Basic 5</option>
	<option>Basic 6</option>
  </select>
</div>
 <div class="form-group">
    <label for="stafPwd">Create Password:</label>
    <input type="password" class="form-control" id="stafPwd">
  </div>
</div>
<div class="col-sm-4">
<h3>View</h3>
<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="../#home">Preview</a></li>
  <!--<li><a data-toggle="tab" href="../#menu1">Assign</a></li>-->
</ul>

<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
    <h3>Team Members</h3>
		<hr>
  <?php//$objLoadteam->loadteamtoView();?>
  <div id="teampreview">
  </div>
</div>
</div>
</div>
</div>
		<button type="button" class="btn btn-info" id="poststaffscontentNow">Submit</button>
	
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
   </div>
 </div>
   
<div class="row">
<div class="col-sm-12 mt-2">
      <div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Pupil Manager</h1>
        <p class="col-md-8 fs-4"></p>
		<nav>
          <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-basicinfo-tab" data-bs-toggle="tab" data-bs-target="#basicInfo" type="button" role="tab" aria-controls="nav-admin" aria-selected="false">Basic Info</button>			
            <button class="nav-link" id="nav-viewpupils-tab" data-bs-toggle="tab" data-bs-target="#viewpupils" type="button" role="tab" aria-controls="viewpupils" aria-selected="true">Pupils Profile</button>
          </div>
        </nav>
		<div class="tab-content" id="nav-tabContent">
<div class="tab-pane fade active show" id="basicInfo" role="tabpanel" aria-labelledby="basicInfo">
 <div class="row">
 
    <div class="col-sm-4">
      <h3>Pupils-Details</h3>
    <div class="form-group">
    <label>Pupil's Name:</label>
    <input type="text" class="form-control" id="pupilsName0" placeholder="Surname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName1" placeholder="Firstname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName2" placeholder="Middlename" style="margin:4px 0px;">
  </div>
  <div id="uploadmsg">Ok</div>
   <form action="" enctype="multipart/form-data" method="post" name="pupilpixtured" id="pupilpixture">
  <div class="form-group">
    <label for="pupilsPix">Upload picture:</label>
    <input type="file" class="form-control" id="pupilsPix">
	<input type="button" class="btn btn-primary btn-xs" id="pupilimgbtn" onclick="determImgCatgox(pupilpixture.id)" value="upload">
  </div>
  </form>
  <div class="form-group">
  <label for="selgender">Gender:</label>
  <select class="form-control" id="selgender">
    <option>Female</option>
    <option>Male</option>
  </select>
</div>

 <div class="form-group">
  <label for="selPresntclass">Present Class:</label>
  <select class="form-control" id="selPresntclass">
  <option>---</option>
    <option>Reception 1</option>
    <option>Reception 2</option>
    <option>Nursery 1</option>
    <option>Nursery 2</option>
	<option>Basic 1</option>
	<option>Basic 2</option>
	<option>Basic 3</option>
	<option>Basic 4</option>
	<option>Basic 5</option>
  </select>
</div>
 <div class="form-group">
  <label for="classalias2" data-toggle="tooltip" title="Edit in settings">Present Class Alias: <i class="fa fa-info-circle" style="color:#101010;" title=""></i></label>
  <select class="form-control" id="classalias2">
    <option>---</option>
    <option>A</option>
    <option>B</option>
    <option>C</option>
    <option>D</option>
    <option>E</option>
  </select>
</div>
    </div>
  
    <div class="col-sm-4">
      <h3>Guardian Info</h3>
   <div class="form-group">
    <label for="pupilsGuard1">Guardian1:</label>
    <input type="text" class="form-control" id="pupilsGuard1">
  </div>
   <div class="form-group">
    <label for="pupilsGuard1ContactNo">Guardian1 Contact #:</label>
    <input type="tel" class="form-control" id="pupilsGuard1ContactNo">
  </div>
  <div class="form-group">
  <label for="selReltoGuard1">Relationship:</label>
  <select class="form-control" id="selReltoGuard1">
    <option>Father</option>
    <option>Mother</option>
    <option>Uncle</option>
    <option>Aunt</option>
	<option>Other</option>
  </select>
</div>
  <hr>
    <div class="form-group">
    <label for="pupilsGuard2">Guardian2:</label>
    <input type="text" class="form-control" id="pupilsGuard2">
  </div>
  <div class="form-group">
    <label for="pupilsGuard2ContactNo">Guardian2 Contact #:</label>
    <input type="tel" class="form-control" id="pupilsGuard2ContactNo">
  </div>
    <div class="form-group">
  <label for="selReltoGuard2">Relationship:</label>
  <select class="form-control" id="selReltoGuard2">
    <option>Father</option>
    <option>Mother</option>
    <option>Uncle</option>
    <option>Aunt</option>
	<option>Other</option>
  </select>
</div>
    </div>
  </div>
  </div>
	
		  
	<div class="tab-pane fade" id="viewpupils" role="tabpanel" aria-labelledby="viewpupils">
    <div class="row">
	
    <div class="col-sm-4">
	<h3>Basic 4</h3>
	<hr>
	</div>
	<div class="col-sm-4">
	<img src="images/happiness-4628417_1920.jpg" alt="" class="">
	</div>
	<div class="col-sm-4">
	<p>Kemi Thomas</p>
	
	<hr>
	</div>
	</div>
          </div>
        </div>
		<button type="button" class="btn btn-info" id="postpupilscontentNow">Submit</button>
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
      </div>
    </div>
   </div>
   </div>
   

<div class="row">
<div class="col-sm-12 mt-2">
<div class="p-2 mb-4 bg-light rounded-3">
      <div class="container-fluid py-2">
        <h1 class="display-5 fw-bold">Messages</h1>
        <p class="col-md-8 fs-4"></p>
		<div class="card" style="border:1px solid teal;background-color:#fff; border-radius:5px;">
<div class="card-body">
<div class="row" style="padding:5px;">
<div class="col-sm-2 bg-light" style="border-radius:10px 0px 0px 10px;">
<div style="padding:15px 3px 0px 3px;display: block;margin:0 auto;" id="activemessages"></div>
<div style="margin:25px auto;">
<button type="button" class="btn btn-outline-dark bt-sm" style="font-size:0.7em;" id="getloadtest">New</button>
</div>
</div>
<div class="col-sm-10" style="border-radius:0px 10px 10px 0px;padding:5px;">
<!--////-->
<div class="row">
<div class="col-sm-12" id="showblitzedchat">meta details sender here</div>
</div>
<!--////-->
<div class="row">
<div class="col-sm-12 dropdown">
<div style="float:right;" class="dropdown-center">
<span class="ellpsi" id="dropdownMenuButtonSM" data-bs-toggle="dropdown"><i class="bi bi-three-dots-vertical" title="Settings"></i></span>

   <ul class="dropdown-menu" style="">
              <li><a class="dropdown-item" href="#">star</a></li>
              <!--<li><a class="dropdown-item" href="#">Report</a></li>
              <li><a class="dropdown-item" href="#">Delete conversation</a></li>-->
            </ul>
  </div>
</div>
</div>
<!--Chat Pond -->
<div id="chatponddiv" style="max-height:200px;overflow-y:scroll;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesquLorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesqu

Lorem ipsum dolor sit amet, consectetur adipiscing elit. orci urna. In et augue ornare, tempor massa in, luctus sapien. Proin a diam et dui fermentum dolor molestie vel id neque. Donec sed tempus enim, a congue risus. Pellen tesqu

</div>
<!--Chat Pond ends-->
</div>
<div class="col-sm-1" style="">
<div class="row">
<div class="col-sm-12">
<button type="button" class="btn btn-outline-warning bt-sm" style="font-size:0.7em;float:right;border-radius:500px;width:48px;height:48px;" title="blitzer" id="blitzer">
<i class="bi bi-lightning-charge" style="cursor:pointer;"></i>
</button>
</div>
</div>
</div>
</div>
<!--===========1=============-->
<div class="row">
<div class="col-sm-1">
<!--<button type="button" class="btn btn-outline-warning bt-sm" id="rebuild">Rebuild </button>-->
</div>
<div class="col-sm-11">
message notification
</div>
</div>
<!--===========2=============-->
<div class="row" style="margin-top:5px;">
<div class="col-sm-6" style="">
<form class="form-inline" action="" style="margin:0 auto;" id="findmembrfrm" name="findmembrfrm">
    <input class="form-control mr-sm-2" type="text" placeholder="find members" style="height:32px;" id="mwembrschat" name="mwembrschat">
    <button class="btn btn-primary btn-sm mt-1" type="button" id="mwembrschatbtn" name="mwembrschatbtn">Search</button>
  </form>

  <br>
  <table class="table" style="">
  <tbody id="searchedmembrlist" name="searchedmembrlist"></tbody>
  </table>
<p id="listtostore"></p>
<span>
<button type="button" class="btn btn-outline-dark btn-sm" style="font-size:0.7em;" id="membrtsrchd">message</button>
</span>
</div>
<div class="col-sm-6">
<form>
<div class="form-group">
  <textarea class="form-control" rows="3" id="messagerscweekly" name="msagerscweekly" disabled style="cursor:not-allowed;" title="find member to message;"></textarea>
</div>
</form>
<button type="button" class="btn btn-outline-dark bt-sm float-end mt-1" id="messagerybtn" name="messagerybtn" style="font-size:0.7em;" disabled title="send">send</button>
</div>

</div>
<!--============3============-->
<div class="row">
<div class="col-sm-2">
</div>
<div class="col-sm-4">
<p></p>
</div>
<div class="col-sm-6" style="margin-top:5px;">
</div>
</div>
<!--============4============-->
</div>
</div>
      </div>
    </div>
   </div>
   </div>
</div>

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Made By <a href="tel:+23408020597327" title="AlphaTrax">AlphaTrax Software</a> for You &copy; <?php print date('Y') ?></p>
</footer>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/sidebars.js"></script>
<script src="rotescripts/swallowr/pupilsprofile/js/pupilpixuploader.js"></script>
<script src="rotescripts/swallowr/pupilsprofile/js/pupilsprofiletodb.js"></script>
<script src="js/messageschat.js"></script>
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){
   
      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
    });
  });
  
  // Slide in elements on scroll
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
</body>
</html>