<!DOCTYPE html>
<html lang="en">
<head> 
  <title>School Backend-Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--<link rel="icon" href="images/logo_s.jpg" type="image/x-icon">-->
  <meta name="Keywords" content="">
  <meta name="Description" content="App to allow schools to manage their students, log payments, daily progress report etc from a parent - centre viewpoint with ease.">
   <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Bootstrap core CSS -->
<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sidebars.css" rel="stylesheet">
	<!--<link href="../assets/dist/css/offcanvas.css" rel="stylesheet">-->
<script>
/*let getinitags = JSON.parse(sessionStorage.getItem("schweeklymeta"));
			
		if(getinitags == null){
			location.href = "signin.php";
		} else if(getinitags != null){
			console.log("Initialized");
		}else{
			console.log("oops! challenges with getting page");
		}*/
</script>
<style>
</style>
</head>
<body id="myPage" style="padding-top:0;">
<header>
    <div class="px-3 py-2 text-white" style="background-color:#ADE1F550;">
      <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
          <a href="/" class="d-flex align-items-center my-2 my-lg-0 me-lg-auto text-white text-decoration-none">
            <span style="margin:4px;" id=""><img src="../assets/images/templogo.png" alt="" class=""  style="width:32px;vertical-align:-3px;">&nbsp;<label  class="" style="color:#101010;font-weight:600;font-size:1.3em;"> SchWeekly</label></span>
          </a>

<ul class="nav col-12 col-lg-auto my-2 justify-content-center my-md-0 text-small">
      <li>
        <a href="#cdailyreports" class="nav-link active py-3" title="Progress Report" data-bs-toggle="tooltip" data-bs-placement="top">
          <span class="" aria-label="Progress Report"><i class="bi bi-ui-checks-grid text-dark" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li class="nav-item">
        <a href="#movtoattn" class="nav-link py-3" aria-current="page" title="Attendance" data-bs-toggle="tooltip" data-bs-placement="top">
          <span aria-label="Attendance"><i class="bi bi-calendar-check text-dark" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#staffmgr" class="nav-link py-3" title="Manage Teachers" data-bs-toggle="tooltip" data-bs-placement="top">
          <span class="" aria-label="Manage Teachers"><i class="bi bi-plugin text-dark" style="font-size:2em;"></i></span>
        </a>
      </li>
	    <li>
        <a href="#movtopupilmgr" class="nav-link py-3" title="Set pupils Profile" data-bs-toggle="tooltip" data-bs-placement="top">
          <span class="" aria-label="Set pupils Profile"><i class="bi bi-person-vcard text-dark" style="font-size:2em;"></i></span>
        </a>
      </li>
      <li>
        <a href="#movtomessages" class="nav-link py-3" title="Messages" data-bs-toggle="tooltip" data-bs-placement="top">
          <span class="" aria-label="Messages"><i class="bi bi-chat-left-text text-dark" style="font-size:2em;"></i></span>
        </a>
      </li>
    </ul>
	 <!--<div class="dropdown">
      <a href="#" class="d-flex align-items-center justify-content-center p-3 link-dark text-decoration-none dropdown-toggle" id="dropdownUser3" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="../assets/images/templogo.png" alt="mdo" width="24" height="24" class="rounded-circle">
      </a>
      <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser3">
        <li><a class="dropdown-item" href="#">New project...</a></li>
        <li><a class="dropdown-item" href="#">Settings</a></li>
        <li><a class="dropdown-item" href="#">Profile</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="#">Sign out</a></li>
      </ul>
    </div>-->
        </div>
      </div>
    </div>
  </header>

<div class="container py-2" id="cdailyreports">
<div class="row" style="">
<div class="p-2 mb-3 bg-light rounded-3">
<div class="container-fluid py-3">
<h3 class="display-7 fw-bold" style="color:#015393;">Daily Progress Report</h3>
       
<div class="card">
<div class="card-body">
<div class="row m-3">
<div class="col-sm-6 border">
<h5 class="badge bg-dark text-light mt-2">View by</h5>
<div class="row">
  <div class="col-6 col-sm-6">
  <label for="pupiltclass">Pupil Class:</label>
  <select class="form-control" id="pupiltclass">
	<option value="707">---</option>
	<option value="0">Reception 1</option>
	<option value="1">Reception 2</option>
	<option value="2">Nursery 1</option>
	<option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
<div class="col-3 col-sm-3">
<label for="clsarm">Arm:</label>
		    <select class="form-control" id="clsarm">
			<option value="777">---</option>
			<option value="0">A</option>
			<option value="1">B</option>
			<option value="2">C</option>
			<option value="3">D</option>
			<option value="4">E</option>
			<option value="5">F</option>
		  </select>
        </div>
<div class="col-3 col-sm-3">
<label>Submit:</label>
<button type="button" class="btn btn-outline-dark btn-xs" id="dpradmbtn">Submit</button>		    
</div>		
</div>

<div class="my-2">
<p class="spinner-border text-dark" role="status" style="width:16px;height:16px;display:none;" id="busydprlist">
<span class="visually-hidden">Loading...</span>
</p>
</div>
<div class="col-12 col-sm-12">
<label class="badge bg-dark my-2" >Lisitings:</label>
</div> 
<div class="row pb-3 px-2" id="dprbyclasslist"></div>
</div>

<div class="col-sm-6">
<div class="card">
<div class="card-body">
<h5 class="px-2"><span id="classpicked" class=""></span></h5>
<button type="button" class="btn btn-outline-dark btn-sm" id="prevdpr" style="display:none;">Previous</button>
<button type="button" class="btn btn-outline-dark btn-sm" id="nextdpr" style="display:none;">Next</button>

<ul class="list-group list-group-flush" id="dprulisted"style="height:350px; overflow-y:scroll;"></ul>
</div>
</div>
</div>
</div>
</div>   
</div>
</div>
</div>
</div>
</div>

<!--Attendance mgr-->
<div class="container" id="movtoattn">
<div class="row bg-light p-4 mb-4">
      <h3 class="display-7 fw-bold" style="color:#015393;">Attendance Manager</h3>
      <div class="col-md-7">
        <div class="h-100 p-3 rounded-3 border" style="font-size:0.85em;">
          <h5 class="badge bg-dark text-light">view by </h5>
		  <div class="row">
			<div class="col-6 col-sm-6">
			  <label for="">Pupil Class:</label>
			  <select class="form-control" id="arttnclass">
				<option>---</option>
				<option value="0">Reception 1</option>
				<option value="1">Reception 2</option>
				<option value="2">Nursery 1</option>
				<option value="3">Nursery 2</option>
				<option value="4">Basic 1</option>
				<option value="5">Basic 2</option>
				<option value="6">Basic 3</option>
				<option value="7">Basic 4</option>
				<option value="8">Basic 5</option>
				<option value="9">Basic 6</option>
			  </select>
			</div>
			<div class="col-6 col-sm-6">
			<label for="">Arm:</label>
						<select class="form-control" id="arttnarm">
						<option>---</option>
						<option value="0">A</option>
						<option value="1">B</option>
						<option value="2">C</option>
						<option value="3">D</option>
						<option value="4">E</option>
						<option value="5">F</option>
					  </select>
					</div>
		  </div>
		  <div class="row">
		  <div class="col-6 col-md-5">
			<div class="form-group">
			<label for="dater1">from</label>
			<input type="date" class="form-control" id="dater1">
		  </div>
		  </div>
		  <div class="col-6 col-md-5">
			<div class="form-group">
			<label for="dater2">end</label>
			<input type="date" class="form-control" id="dater2">
		  </div>
		  </div>
		  <div class="col-md-2 my-2">
			<div class="form-group">
			<label for="">submit</label>
		<button class="btn btn-outline-dark btn-sm" type="button" id="attndancesbmit">submit</button>
		  </div>
		  </div>
		  </div>
		  
		  <div class="row">
		   <div class="my-2">
			<p class="spinner-border text-dark" role="status" style="width:16px;height:16px;display:none;" id="busydattnlist">
		    <span class="visually-hidden">Loading...</span>
			</p>
		</div>
		  <div class="col-12 col-md-12">
		   <h5 class="badge bg-dark text-light">class: <span id="attnclasslbl"></span></h5>
		  <div class="list-group" id="listattendancebyclass"></div>
		  </div>
		  </div>
		  
        </div>
      </div>
	  
      <div class="col-md-5">
	  <div class="card">
	  <div class="card-body">
        <div class="h-100 p-1 bg-light rounded-3"> 
		<div class="row m-1">
		<div class="col-md-10">
		<div id="" style="font-size:0.8em;font-weight:700;">
		<span>View attendance for </span><label id="subattnlabel" style="color:#880e4f"></label>
		</div>
		</div>
		<div class="col-md-2">
		<span class="spinner-border text-dark" role="status" style="width:16px;height:16px;display:none;" id="busydattnmeta">
		    <span class="visually-hidden">Loading...</span>
			</span>
		</div>
		<div class="col-md-12">
	<div class='card my-2'>
		<div class='card-body' id=''>
			<div class="list-group" id="attndncmeta"></div>
		</div>
	</div>
		  </div>
		  </div>
          <p></p>
        </div>
		</div>
		</div>
      </div>
  </div>
</div>
<!--attendance mgr ends-->

<!--Teacher mgr-->   
<div class="container" id="staffmgr">   
<div class="row bg-light p-4 mb-4">
      <div class="container-fluid mt-3">
       <h3 class="display-7 fw-bold" style="color:#015393;">Teacher Manager</h3>	
<div class="row" id="staffdatainput">
    <div class="col-sm-4">
      <h3>Basic Info</h3>
	  <div class="form-group">
  <label for="stafTitle">Title:</label>
  <select class="form-control" id="stafTitle">
	<option value="0">Mr.</option>
	<option value="1">Mrs.</option>
    <option value="2">Miss</option>
  </select>
</div>
  <div class="form-group">
  <label for="jobDescrtn">Job Designation:</label>
  <select class="form-control" id="jobDescrtn">
    <option value="0">Teacher</option>
	<option value="1">Ast.Teacher</option>
    <option value="2">Admin</option>
  </select>
</div>
     <div class="form-group">
    <label for="stafsurName">Surname:</label>
    <input type="text" class="form-control" id="stafsurName">
  </div>
   <div class="form-group">
    <label for="staffName">Firstname:</label>
    <input type="text" class="form-control" id="staffName">
  </div>
   <div class="form-group">
    <label for="stafPwd">Create Password:</label>
    <input type="text" class="form-control" id="stafPwd" maxlength="8">
  </div>
  <!-- <div class="form-group">
    <label for="stafoName">Othername:</label>
    <input type="text" class="form-control" id="stafoName">
  </div>

   <div class="form-group">
    <label for="stafPix">Add Picture:</label>
    <input type="file" class="form-control" id="stafPix">
  </div>-->
</div>
   <div class="col-sm-4">
      <h3>Education</h3>
	   <div class="form-group">
  <label for="stafQualifc">Qualification:</label>
  <select class="form-control" id="stafQualifc">
    <option value="0">SSCE</option>
	<option value="1">L.Diploma</option>
    <option value="2">H.Diploma</option>
	<option value="3">Degree</option>
	<option value="4">Masters</option>
	<option value="5">Doctorate</option>
  </select>
</div>

<hr>
 <div class="form-group" id="exonmakeadminselClassTaught">
  <label for="selClassTaught">Class Taught:</label>
  <select class="form-control" id="selClassTaught">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>

<div class="form-group" id="exonmakeadminclassalias1">
  <label for="classalias1" title="">Class Arm:</label>
  <select class="form-control" id="classalias1">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>

<div class="form-group" style="margin-top:5px;">
	<p>
	<span class="text-danger" style="font-size:0.75em;display:none;" id="makeadminflash">you will be making this staff an admin</span>
      <label>
        <input type="checkbox" id="upgradetoadmin"/>
        <span for="upgradetoadmin">Make Admin </span>
      </label>
    </p>
  </div>

<div class="d-grid gap-2">
<button type="button" class="btn btn-dark mt-2" id="poststaffscontent" style="">Submit</button>
</div>
</div>

<div class="col-sm-4">
<h3  class="visually-hidden">View</h3>
<button type="button" class="btn btn-outline-dark btn-sm mb-2" id="stafflisting">view all</button>
<table class="table table-sm table-bordered" style="max-height:450px;overflow-y:scroll;">
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">names</th>
            <th scope="col">edit</th>
            <th scope="col">suspend</th>
          </tr>
          </thead>
          <tbody id="mypreviewlist">
		  <tr>
            <td scope="col" colspan='4'>
		<div class="spinner-border text-dark" role="status" style="width:1rem;height:1rem;display:none" id="busystafflisting">
          <span class="visually-hidden">Loading...</span>
        </div>
			</td>
          </tr>
		  </tbody>
        </table>
		</div>
</div>
<p id="staffeditop"></p>
<hr>
<div class="card mt-2" style="display:none;" id="staffdatainputedit">
<div class="card-body">
<div class="row">
<div class="col-sm-4">
<h3><span class="text-danger" style="cursor:pointer;" id="backtostaffentry"><i class="bi bi-arrow-left-square" style="vertical-align:baseline;"></i> Edit Mode</span></h3>
  <div class="form-group">
  <label for="jobDescrtnedt">Job Designation: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="jodesigin"></span>
  <span for="" onclick="getSentFieldData(jobDescrtnedt.id);">
  <i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
  <select class="form-control" id="jobDescrtnedt">
    <option value="">--</option>
    <option value="0">Teacher</option>
	<option value="1">Ast.Teacher</option>
    <option value="2">Admin</option>
  </select>
</div>
  
  <div class="form-group">
  <label for="stafQualifcedt">Qualification: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="urqualific"></span>
  <span for="" onclick="getSentFieldData(stafQualifcedt.id);">
  <i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
  <select class="form-control" id="stafQualifcedt">
    <option value="">--</option>
    <option value="0">SSCE</option>
	<option value="1">L.Diploma</option>
    <option value="2">H.Diploma</option>
	<option value="3">Degree</option>
	<option value="4">Masters</option>
	<option value="5">Doctorate</option>
  </select>
</div>
   <!--<div class="form-group">
    <label for="stafPwd">Create Password:</label>
    <input type="text" class="form-control" id="stafPwd" maxlength="8">
  </div>-->
</div>
   <div class="col-sm-4">
      <h3>Bio</h3>
   <div class="form-group">
    <label for="stafsurNamedt">Surname: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="ursname"></span>
    <span for="" onclick="getSentFieldData(stafsurNamedt.id);">
	<i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
    <input type="text" class="form-control" id="stafsurNamedt">
  </div>
   <div class="form-group">
    <label for="staffNamedt">Firstname: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="urfname"></span>
  <span for="" onclick="getSentFieldData(staffNamedt.id);"><i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
    <input type="text" class="form-control" id="staffNamedt">
  </div>
</div>
<div class="col-sm-4">
      <h3>Class</h3>
 <div class="form-group">
  <label for="selClassTaughtedt">Class Taught: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="urclasstut"></span>
  <span for="" onclick="getSentFieldData(selClassTaughtedt.id);"><i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
  <select class="form-control" id="selClassTaughtedt">
    <option value="">--</option>
	<option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>

<div class="form-group">
  <label for="classalias1edt" title="">Class Arm: 
  <span style="font-size:0.8em;font-weight:500;color:#007dff;" id="urclassarm"></span>
  <span for="" onclick="getSentFieldData(classalias1edt.id);"><i class="bi bi-box-arrow-in-up-right"></i>
  </span>
  </label>
  <select class="form-control" id="classalias1edt">
    <option value="">--</option>
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!--Teacher mgr ends-->

<!--Pupil mgr -->
<div class="container" id="movtopupilmgr">      
<div class="row bg-light mb-4 py-3">
<div class="col-sm-12">
      <div class="container-fluid py-2">
        <h3 class="display-7 fw-bold" style="color:#015393;">Pupil Manager</h3>
        <p class="col-md-8 fs-4"></p>
		<nav>
          <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-basicinfo-tab" data-bs-toggle="tab" data-bs-target="#basicInfo" type="button" role="tab" aria-controls="nav-admin" aria-selected="false">Basic Info</button>			
            <button class="nav-link" id="nav-viewpupils-tab" data-bs-toggle="tab" data-bs-target="#viewpupils" type="button" role="tab" aria-controls="viewpupils" aria-selected="true">Pupils Profile</button>
          </div>
        </nav>
		<div class="tab-content" id="nav-tabContent">
<div class="tab-pane fade active show" id="basicInfo" role="tabpanel" aria-labelledby="basicInfo">
 <div class="row">
 
    <div class="col-sm-4">
      <h3>Pupils-Details</h3>
    <div class="form-group">
    <label>Pupil's Name:</label>
    <input type="text" class="form-control" id="pupilsName0" placeholder="Surname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName1" placeholder="Firstname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName2" placeholder="Middlename" style="margin:4px 0px;">
  </div>
  
   <!--
   <div id="uploadmsg">Ok</div>
   <form action="" enctype="multipart/form-data" method="post" name="pupilpixtured" id="pupilpixture">
  <div class="form-group">
    <label for="pupilsPix">Upload picture:</label>
    <input type="file" class="form-control" id="pupilsPix">
	<input type="button" class="btn btn-primary btn-xs" id="pupilimgbtn" onclick="determImgCatgox(pupilpixture.id)" value="upload">
  </div>
  </form>-->
<div class="form-group">
  <label for="selgender">Gender:</label>
  <select class="form-control" id="selgender">
    <option value="0">Female</option>
    <option value="1">Male</option>
  </select>
</div>
</div>
  
    <div class="col-sm-4">
	<h3>Other-Details</h3>
     
 <div class="form-group">
  <label for="selPresntclass">Class:</label>
  <select class="form-control" id="selPresntclass">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
 <div class="form-group">
  <label for="classalias2" data-toggle="tooltip" title="Edit in settings">Class Arm: <i class="fa fa-info-circle" style="color:#101010;" title=""></i></label>
  <select class="form-control" id="classalias2">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>
<hr>
<div class="d-grid gap-2">
<button type="button" class="btn btn-dark mt-2" id="postpupilscontent" style="">Submit</button>
</div>
    </div>
	
	<div class="col-sm-4">
	<!~--///-->
	</div>
  </div>
  </div>
	
		  
	<div class="tab-pane fade" id="viewpupils" role="tabpanel" aria-labelledby="viewpupils">
    <div class="row">
	
    <div class="col-sm-6">
	<p class="fw-bold">Find Pupil</p>
	<hr>
	<div class="row">
  <div class="col-6 col-sm-6">
  <label for="ppilclass">Pupil Class:</label>
  <select class="form-control" id="ppilclass">
	<option>---</option>
	<option value="0">Reception 1</option>
	<option value="1">Reception 2</option>
	<option value="2">Nursery 1</option>
	<option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
<div class="col-3 col-sm-3">
<label for="clsarmppl">Arm:</label>
		    <select class="form-control" id="clsarmppl">
			<option>---</option>
			<option value="0">A</option>
			<option value="1">B</option>
			<option value="2">C</option>
			<option value="3">D</option>
			<option value="4">E</option>
			<option value="5">F</option>
		  </select>
        </div>
			
<div class="col-3 col-sm-3">
<label>Submit:</label>
<button type="button" class="btn btn-outline-dark btn-xs" id="pupilfinderadm_btn" style="">Submit</button>		    
</div>

<!--<div class="card" style="border:1px solid teal;background-color:#fff; border-radius:5px;">
<div class="card-body">

</div>
</div>-->	
</div>
<div class="my-2">
<p class="spinner-border text-dark" role="status" style="width:16px;height:16px;display:none;" id="busypplfinderlist">
<span class="visually-hidden">Loading...</span>
</p>
</div>
<div class="list-group my-2" id="holdfoundclass"></div>	
	</div>
	
	<div class="col-sm-6">
	<p></p>
	
	<div class="row">
      <!--
	  <hr>
	  <div class="col-sm-6">
    <div class="form-group">
    <input type="text" class="form-control" id="pupilsName0edt" placeholder="Surname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName1edt" placeholder="Firstname" style="margin:4px 0px;">
	<input type="text" class="form-control" id="pupilsName2edt" placeholder="Middlename" style="margin:4px 0px;">
  </div>
  
 
   <div id="uploadmsg">Ok</div>
   <form action="" enctype="multipart/form-data" method="post" name="pupilpixtured" id="pupilpixture">
  <div class="form-group">
    <label for="pupilsPix">Upload picture:</label>
    <input type="file" class="form-control" id="pupilsPix">
	<input type="button" class="btn btn-primary btn-xs" id="pupilimgbtn" onclick="determImgCatgox(pupilpixture.id)" value="upload">
  </div>
  </form>
<div class="form-group">
  <label for="selgender">Gender:</label>
  <select class="form-control" id="selgender">
    <option value="0">Female</option>
    <option value="1">Male</option>
  </select>
</div>-->
</div>
  
   
 <!--<div class="col-sm-6">     
 <div class="form-group">
  <label for="selPresntclassedit">Class:</label>
  <select class="form-control" id="selPresntclassedit">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
 <div class="form-group">
  <label for="classalias2edit" data-toggle="tooltip" title="Edit in settings">Class Arm: <i class="fa fa-info-circle" style="color:#101010;" title=""></i></label>
  <select class="form-control" id="classalias2edit">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>
<hr>
<div class="d-grid gap-2">
<button type="button" class="btn btn-dark mt-2" id="postpupilscontentedit" style="">Submit</button>
</div>
    </div>-->
  </div>
	</div>
	</div>
          </div>
        </div>
    </div>
   </div>
</div>
<!--Pupil mgr ends-->

<!--Messages mgr -->
<div class="container py-1" id="movtomessages"> 
<div class="row mb-4 bg-light">
<div class="col-sm-12">
<div class="container-fluid py-2">
        <h3 class="display-7 fw-bold" style="color:#015393;">Communication</h3>
<p class="col-md-8 fs-4"></p>
<div class="card" style="">
<div class="card-body">
<div class="row" style="padding:5px;">
<div class="col-sm-6" style="border-radius:0px 10px 10px 0px;padding:5px;">
<!--Chat Pond -->
<div class="row m-2">
<div class="col-sm-6">
<h6 class="border-bottom pb-2 mb-0 badge bg-dark">Recent Messages <span class=" badge bg-warning text-dark" id="msgbuble"></span></h6>
</div>
<div class="col-sm-6">
<button type="button" class="btn btn-outline-danger bt-sm float-end mt-1" id="adminmsgbtn" name="adminmsgbtn" style="font-size:0.7em;" title="admin">load messages</button>

<!--<button type="button" class="btn btn-outline-danger bt-sm float-end mt-1" id="tchersmsgbtn" name="tchersmsgbtn" style="font-size:0.7em;" title="tcher">teacher</button>-->
</div>
</div>
<div class="my-1 bg-body rounded shadow-sm px-2 alert-info" style="max-height:350px;overflow-y:auto;">
  <div class="text-muted pt-3" id="msgboardview"></div>
 </div>
   <!-- Messager modal -->
<div class="modal fade" id="replymodal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="enrol" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="">
        <h5 class="modal-title" id="staticBackdropLiveLabel" style="font-weight:bold;">Reply</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

		<form method="post" id="messagebox" name="replymessagebox">
		<div class="form-group">
		<div id="" class="form-text float-end" id="">
			  <span style='float:right;font-size:0.65rem;color:#015393;'>
			   <input readonly type='text' name='limreplychars' id='limreplychars' size='2' value='200' style='border:none;text-align:center;background-color:transparent;color:#015393;'>characters left.
			  </span>
			</div>
		  <textarea class="form-control" rows="3" id="messagerscweekly" name="msagerscweekly" style="" title="Reply to message"></textarea>
		</div>
		<div class="form-group">
		<button type="button" class="btn btn-outline-dark bt-sm float-end mt-1" id="messagerybtn" name="messagerybtn" style="font-size:0.7em;" title="send">send</button>
		</div>
		</form>
      </div>
      <div class="modal-footer" style=""><span id="replyresponse" style="font-size:0.75em;"></span></div>
    </div>
  </div>
</div>
<!--end messager modal-->
<!--Chat Pond ends-->
</div>

<div class="col-sm-6">
<div class="card bg-light">
<div class="card-body">
<h6 class="border-bottom pb-2 mb-0 badge bg-dark">Send Homework / Comments</h6>
<form id="hwrkmessagebox" name="hwrkmessagebox">
 <div class="row my-3">     
 <div class="col-sm-6 form-group">
  <label for="selPresntclasshwrk">Class:</label>
  <select class="form-control" id="selPresntclasshwrk">
    <option value="0">Reception 1</option>
    <option value="1">Reception 2</option>
    <option value="2">Nursery 1</option>
    <option value="3">Nursery 2</option>
	<option value="4">Basic 1</option>
	<option value="5">Basic 2</option>
	<option value="6">Basic 3</option>
	<option value="7">Basic 4</option>
	<option value="8">Basic 5</option>
	<option value="9">Basic 6</option>
  </select>
</div>
 <div class="col-sm-6 form-group">
  <label for="classaliashwrk" data-toggle="tooltip" title="Edit in settings">Class Arm: <i class="fa fa-info-circle" style="color:#101010;" title=""></i></label>
  <select class="form-control" id="classaliashwrk">
    <option value="0">A</option>
    <option value="1">B</option>
    <option value="2">C</option>
    <option value="3">D</option>
    <option value="4">E</option>
	<option value="5">F</option>
  </select>
</div>
</div>

<div class="form-group">
 <div id="" class="form-text" id="">
 <!--<span id="responsehwrk" style="display:none;">sent</span>-->
	  <span style='float:right;font-size:0.65rem;color:#015393;'>
	   <input readonly type='text' name='limhwrkchars' id='limhwrkchars' size='2' value='200' style='border:none;text-align:center;background-color:transparent;color:#015393;'>characters left.
	  </span>
	</div>
  <textarea class="form-control" rows="3" id="hmworkmessagr" name="hmworkmessagr" style="" title="Homework"></textarea>
</div>
<div class="form-group">
<button type="button" class="btn btn-outline-dark bt-sm float-end mt-1" id="hwrkmessagerybtn" name="hwrkmessagerybtn" style="font-size:0.7em;" title="send">send <span class="spinner-border text-dark" role="status" style="width:12px;height:12px;display:none;" id="responsehwrk">
<span class="visually-hidden">Loading...</span>
</span>
</button>
</div>
</form>
</div>
</div>
</div>
</div>
<div class="row" style="margin-top:5px;">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!--<script></script>-->
   <!--Messages mgr ends-->

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class=""><i class="bi bi-arrow-up-circle-fill text-dark" style="font-size:2em;"></i></span>
  </a>
  <p style="font-size:0.7em;" class="text-muted">Made By <a href="tel:+23408020597327" class="text-decoration-none" title="AlphaTrax">AlphaTrax Software</a> for You &copy; <?php print date('Y') ?></p>
</footer>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/sidebars.js"></script>
<script src="js/teacherentry.js"></script>
<script src="../assets/scripts/pupilsprofile/js/pupilsprofiletodb.js"></script>
<script src="js/app.js"></script>
<!--<script src="../assets/dist/js/offcanvas.js"></script>-->

<!--<script></script>-->
<script>
/*
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){
   
      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
    });
  });
  
  // Slide in elements on scroll
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})*/
</script>
</body>
</html>