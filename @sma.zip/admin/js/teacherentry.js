let upgradetoadminchk = document.getElementById("upgradetoadmin");
upgradetoadminchk.addEventListener("change",handlemakeAdmin,false);

function handlemakeAdmin(){ 
	
	let gt_StaffClasTot  = document.getElementById("exonmakeadminselClassTaught");
	let gt_classarm      = document.getElementById("exonmakeadminclassalias1");	
	//handle admin Checkbox
		if(upgradetoadminchk.checked){
			
			console.log("checked");
			document.getElementById("makeadminflash").style.display = "block";
			gt_classarm.style.display = "none";
			gt_StaffClasTot.style.display = "none";
			
		}else if(!upgradetoadminchk.checked){
			
			console.log("unchecked");
			document.getElementById("makeadminflash").style.display = "none";
			gt_classarm.style.display = "block";
			gt_StaffClasTot.style.display = "block";
		}
}

var gtrcentpupilsbatch = document.getElementById("poststaffscontent");
gtrcentpupilsbatch.onclick = pushstaffsDetails;
var gtStaftype;
var istchrpryorsec;
function pushstaffsDetails(){
	
	var gtStaffTitle    = document.getElementById("stafTitle").value;
	var gtStaffJobDescrtn = document.getElementById("jobDescrtn").value;
	var gtStaffSurname  = document.getElementById("stafsurName").value;
	var gtStaffFname    = document.getElementById("staffName").value;
	var gtStaffQualifc  = document.getElementById("stafQualifc").value;
	var gtStaffClasTot  = document.getElementById("selClassTaught").value;
	var gtclassarm      = document.getElementById("classalias1").value;
	var gtStaffAsgndPwd = document.getElementById("stafPwd").value;
	    gtStaftype      = 2;
	let gthschuid       = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id          = gthschuid[0][0].schuid;

	
		
if(gtStaffTitle == "" || gtStaffJobDescrtn == "" || gtStaffSurname == "" || gtStaffFname == "" || gtStaffQualifc == "" || gtStaffAsgndPwd == "" || gtStaffClasTot == "" || gtclassarm == ""){
		alert("All fields required!");
		return false;
	}
	else{
		
		/////////////
		//get teacher type
	if(gtStaffClasTot >= 0 && gtStaffClasTot <= 9){
			
		istchrpryorsec = 0; //primary school teacher
		
						
		}else if(gtStaffClasTot >= 10 && gtStaffClasTot <= 15){
			
			istchrpryorsec = 1; //secondary school teacher
		}	
		
		
	if(upgradetoadminchk.checked){
			
			//console.log("choecked");
			gtStaffClasTot = 55;//127 
			gtclassarm = 44;//127 
			gtStaftype = 1;
						
		}		
		/////////////////////
		
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
	
	console.log(xhttp.responseText);
	loadResults();
	alert(xhttp.responseText);
					
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/staffmgr/staffmgrlauncher.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send(
"send_staff_title="+gtStaffTitle+
"&send_staff_jdescrtn="+gtStaffJobDescrtn+
"&send_staff_surname="+gtStaffSurname+
"&send_stf_type="+gtStaftype+
"&send_staff_fname="+gtStaffFname+
"&send_staff_qualifc="+gtStaffQualifc+
"&send_staff_clastot="+gtStaffClasTot+
"&send_tcher_type="+istchrpryorsec+
"&send_clas_arm="+gtclassarm+
"&send_staff_pwd="+gtStaffAsgndPwd+
"&send_sch_uid="+sch_id
);
}
}


function pullItemstotablelist(){
	
	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id = gthschuid[0][0].schuid;


	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				sessionStorage.setItem("Usermetaload",xhttp.responseText)
				//document.getElementById("").innerHTML = xhttp.responseText;
  	}
	};
	
	 /* Using POST */
xhttp.open("POST","../assets/scripts/staffmgr/pullitems.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_sch_uid="+sch_id);
}

//document.addEventListener("DOMContentLoaded",function (){
	
	//clear producid in store
	//sessionStorage.removeItem("PRODUCT_ID");
	//sessionStorage.removeItem("itemproductuid");
	//pullProductstotablelist();
	//setTimeout(loadProducttotable,2000);
	//loadResults();
	
//},false);



let viewlisting = document.getElementById("stafflisting");
viewlisting.addEventListener("click",function(){
	//console.log("kilode");
	let metaloadinstore = sessionStorage.getItem("Usermetaload");
	
	if(metaloadinstore == null){
		
		loadResults();
		
	}else if(metaloadinstore !== null){
		
		setTimeout(loadItemstotable,2000);

	}
	
},false);



function loadResults(){
	
	pullItemstotablelist();//may need to be removed
	document.getElementById("busystafflisting").style.display = "block";
	setTimeout(loadItemstotable,2000);
	
}

function loadItemstotable(){
	
	//document.getElementById("busystafflisting").style.display = "block";
	
	let metaloadinstore = sessionStorage.getItem("Usermetaload");
	let ty = JSON.parse(metaloadinstore);
	
	let prevtbl = document.getElementById("mypreviewlist");
	let t = "";
	//console.log(ty.length);
	//console.log(ty[0].prdctname);
	for(var i = 0; i < ty.length; i++)
	{
		//console.log(ty[i].prdctname);
		let sn = i+1;
		let mem_names = ty[i].staffsurname +" "+ ty[i].stafffname
		t +="<tr><th scope='row'>"+sn+"</th><td><span style='font-size:0.8em;' id='"+ty[i].staffrefnumbr+"'>"+mem_names+"</span></td>  <td><button type='button' class='btn btn-outline-primary btn-sm' onclick='initEditing("+i+");' style='font-size:0.65em;'>edit <i class='bi bi-pencil-square'></i></button></td><td><button type='button' class='btn btn-outline-primary btn-sm' onclick='statusSuspended("+i+");' style='font-size:0.65em;'>suspend <i class='bi bi-shield-lock'></i></button></td></tr>";
		
	}
	prevtbl.innerHTML = t;
	//sessionStorage.removeItem("Usermetaload");
	
}



var arryjobdsig = ["Teacher","Ast. Teacher","Admin","--"];
var arryqualifc = ["SSCE","L.Diploma","H.Diploma","Degree","Masters","Doctorate"];
var arryclstut  = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
var arryclsarm  = ["A","B","C","D","E","F","--"];

function initEditing(id){
	
	//console.log(id);
	
	document.getElementById("staffdatainputedit").style.display = "block";
	scrolltoView();
	
	let metaloadinstore = sessionStorage.getItem("Usermetaload");
	let ty = JSON.parse(metaloadinstore);
	
	//console.log(ty[id].classarm);
	//console.log(ty[id].jobdesignation);
	
	if(arryclsarm[ty[id].classarm] == undefined){
		
		ty[id].classarm = 6;
		
	}
	
	if(arryjobdsig[ty[id].jobdesignation] == undefined){
		
		ty[id].jobdesignation = 3;
	}
	
	//console.log(ty[id].classarm);
	//console.log(ty[id].jobdesignation);
	
		document.getElementById("urqualific").innerHTML   = arryqualifc[ty[id].staffqualfy];
		document.getElementById("jodesigin").innerHTML    = arryjobdsig [ty[id].jobdesignation];
		document.getElementById("ursname").innerHTML      = ty[id].staffsurname;
		document.getElementById("urfname").innerHTML      = ty[id].stafffname;
		document.getElementById("urclasstut").innerHTML   = arryclstut[ty[id].classtut];
		document.getElementById("urclassarm").innerHTML   = arryclsarm[ty[id].classarm];
		
	    sessionStorage.setItem("TcherRef_id",ty[id].staffrefnumbr);
	    //sessionStorage.setItem("itemproductuid",ty[id].prdctid);
		
}


function statusSuspended(id){
	
	let metaloadinstore = sessionStorage.getItem("Usermetaload");
	let ty = JSON.parse(metaloadinstore);
		
	//console.log(ty[id].staffrefnumbr);
	
	////////////////////////////////////
	
	let member_id = ty[id].staffrefnumbr;
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//alert(xhttp.responseText);
			
	        alert(xhttp.responseText);
			loadResults();

	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/staffmgr/statusSuspended.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_membr_id="+member_id);
}




//HANDLE SAVE ICON - & DISABLEd FIELDS
function getSentFieldData(gtId){
		
	//alert(gtId);	
	//console.log(gtId);
		
	let gtitem = document.getElementById(gtId).value;
	
	//console.log(gtitem);
	
	if(gtId != undefined && gtitem  != ""){
		
		sendtoProfileProcessor(gtId,gtitem);
		//document.getElementById(gtId).disabled = true;
		
	}else{
		
		alert("you have not made any edit?");	
	}

}


function sendtoProfileProcessor(itemtype,itemEditd){
	
	let tcher_id = sessionStorage.getItem("TcherRef_id");
	//console.log(productid);//return false;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			
			console.log(xhttp.responseText);			
	        alert(xhttp.responseText);
			loadResults();

	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/staffmgr/profileprocessor.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_itemEdited=" +itemEditd +"&send_itemType=" +itemtype+"&send_prdctid="+tcher_id);
}

let backtostaffmode = document.getElementById("backtostaffentry");

backtostaffmode.onclick = function(){
	
	document.getElementById("staffdatainputedit").style.display = "none";
}


function scrolltoView(){
	 
let movtostaffeditview = document.getElementById("staffeditop");
movtostaffeditview.scrollIntoView();

}

