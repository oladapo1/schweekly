//refactor chkLoad_ifempty function to a single file and pass argument to parameter

var getSigneeLoad = document.getElementById("signee_id");
//alert("ok");

getSigneeLoad.onclick = chkLoad_ifempty;

function chkLoad_ifempty(){

var gtSigneeFName = document.getElementById("seSchoolnameId").value;
var gtSigneeLName = document.getElementById("schownercountry").value;
var gtSigneeEmail = document.getElementById("seEmailId").value;
var gtSigneeTel = document.getElementById("seTelefId").value;
var gtSigneePwd = document.getElementById("seSchoolpwd").value;

//alert(gtSigneeEmail+gtSigneePwd+gtSigneeTel+gtSigneeLName);
//if(gtSigneeEmail == "" || gtSigneePwd == "" || gtSigneeTel == "" || gtSigneeDispName == "")
if(gtSigneeFName == ""){
	
	alert("All fields are required");
	document.getElementById("seSchoolnameId").focus();
	return false;
	
	}else{
		
		muv_signee_Up(gtSigneeFName,gtSigneeLName,gtSigneeEmail,gtSigneeTel,gtSigneePwd);
		//alert(gtSigneeEmail+gtSigneePwd+gtSigneeTel+gtSigneeDispName);
	
	}

}

function muv_signee_Up(schlname,countryname,emailr,telf,passkeyr){
	
	//alert(emailr+passkeyr+telf+dispname);
	
	//var send_sg_email,send_sg_pwd,send_sg_tel,send_sg_dname;
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			
			if(xhttp.responseText){
				//alert("sent :)");
				alert(xhttp.responseText);
				location.reload();
				//document.getElementById("comment_load").value="";
				//document.getElementById("comment_load").focus();
			}else{
				location.reload(); // remember to clear modal fields after submission
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/signup_proced.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_sg_schname=" +schlname +"&send_sg_ctryname=" +countryname  +"&send_sg_email=" +emailr +"&send_sg_tel=" +telf + "&send_sg_pwd=" +passkeyr);
	
}





