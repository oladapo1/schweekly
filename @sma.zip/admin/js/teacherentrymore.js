let submitorder_btn = document.getElementById("poststaffscontent");
submitorder_btn.addEventListener("click",function(){
	
	let productfrm_name = document.getElementById("newproductentryfrm");
	sendnewProductdatatodb(productfrm_name.name);
	
},false);
function sendnewProductdatatodb(frm){
	
	let form = document.forms.namedItem(frm);
	
	let gtproductemail  = document.getElementById("officemail").value;
	if(ValidateEmail(gtproductemail) === false){
				  return false;
		}
	
	
	oDatax = new FormData(form);	

	var oReqx = new XMLHttpRequest();
	oReqx.open("POST", "../scripts/productentry.php", true);
	oReqx.onload = function(oEvent) {
    if (oReqx.readyState == 4 && oReqx.status == 200){
     console.log(oReqx.responseText); 
	 //alert(oReqx.responseText);//oOutput.innerHTML = oReqx.responseText;
	 let resp_len = oReqx.responseText;
	 if(resp_len.length < 9){
		 
		 alert("Error-seek support");
		  
	 }else if(resp_len.length == 9){
		 
		 sessionStorage.setItem("itemproductuid",resp_len);
		 alert("new product created, remember to add product image");
		//setTimeout(loadProducttotable,2000);
		loadResults();
		 
	 }
	  //clearInvoiceuidlbl();
    } else {
      console.log("Error " + oReqx.status + " occurred when trying to upload your file.<br>");//oOutput.innerHTML = "Error " + oReqx.status + " occurred when trying to upload your file.<br>";
    }
  };

		oReqx.send(oDatax);
} //send the filled frm to server


		function ValidateEmail(inputText){
		var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		if(inputText.match(mailformat))
		{
		return true;
		}
		else
		{
		alert("Ensure all fields are correct, check email address!");
		document.getElementById("officemail").focus();
		document.getElementById("officemail").style.border = "1px solid red";
		//document.form1.text1.focus();
		return false;
		}
		}

/* image mgr*/
let getm_prodsubmitbtn=document.getElementById("prdctpix");

getm_prodsubmitbtn.addEventListener("click",function(){
	
	let productpicturefrm_name = document.getElementById("owaprofilepixnew");
	determImg_Catgo(productpicturefrm_name.name)
	
	},false);
	
	
function determImg_Catgo(e){
	//check if image is selected
	let fileinputvalue = document.getElementById("prdoctpixl")
	if(fileinputvalue.files.length == 0){
	alert("No image selected for this item");
	//event.preventDefault();
	 return false;
	}else{	
	passImgCatgotoHandler(e);
	}
}	


let get_edit_imagebtn = document.getElementById("edititempixbtn");

get_edit_imagebtn.addEventListener("click",function(){
	
	let productpicturefrm_name = document.getElementById("owaprofilepix");
	determImgCatgo(productpicturefrm_name.name)
	
	},false);
	
function determImgCatgo(e){

	let fileinputvalue = document.getElementById("pixl")
	if(fileinputvalue.files.length == 0){
	alert("No image selected for edit");
	 return false;
	}else{	
	passImgCatgotoHandler(e);
	}
}
	
	
	
function passImgCatgotoHandler(filepix){
	//console.log(filepix);return false;
let form = document.forms.namedItem(filepix);

	let productuid = JSON.parse(sessionStorage.getItem("itemproductuid"));
	productuid = productuid;
	
	if(productuid == null){
		
		alert("Kindly edit or fill product form before uploading product image");
		return false;
	}

	let pixfiletoupload;
	
	if(filepix == "owaprofilepixedit"){
		
		pixfiletoupload = "myeditedpixle";
		
	}else if(filepix == "owaprofilepixnew"){
		
		pixfiletoupload = "myproductpixle";
		
	}
	
	
	let folderToUpload = "../assets/dist/images/products";
	
	  oData = new FormData(form);

	  oData.append("UploadDir", folderToUpload);
	  oData.append("ImagefromFileInput", pixfiletoupload);
	  oData.append("Whoeditnpix", productuid);
	  var oReq = new XMLHttpRequest();
	  oReq.open("POST", "../scripts/profilepixuploadr.php", true);
	  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
     console.log(oReq.responseText);
	 sessionStorage.removeItem("itemproductuid");
	 alert(oReq.responseText);//oOutput.innerHTML = oReq.responseText;
	 //pullProductstotablelist();
	 loadResults();
	// setTimeout(loadProducttotable,2000);
    } else {
      console.log("Error " + oReq.status + " occurred when trying to upload your file.<br>");
    }
  };

  oReq.send(oData);
}

/* pull product uid and product names to populate select list */

function pullProductstotablelist(){
	
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				sessionStorage.setItem("Productmetaload",xhttp.responseText)
				//document.getElementById("").innerHTML = xhttp.responseText;
  	}
	};
	
	 /* Using POST */
xhttp.open("POST","../scripts/pullproducts.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send();
}

document.addEventListener("DOMContentLoaded",function (){
	
	//clear producid in store
	sessionStorage.removeItem("PRODUCT_ID");
	sessionStorage.removeItem("itemproductuid");
	//pullProductstotablelist();
	//setTimeout(loadProducttotable,2000);
	loadResults();
	
},false);


function loadResults(){
	
	pullProductstotablelist();
	setTimeout(loadProducttotable,2000);
	
}

function loadProducttotable(){
	
	let metaloadinstore = sessionStorage.getItem("Productmetaload");
	let ty = JSON.parse(metaloadinstore);
	
	let prevtbl = document.getElementById("mypreviewlist");
	let t = "";
	//console.log(ty.length);
	//console.log(ty[0].prdctname);
	for(var i = 0; i < ty.length; i++)
	{
		//console.log(ty[i].prdctname);
		let sn = i+1;
		t +="<tr><th scope='row'>"+sn+"</th><td><a href='#' class='alert-link' target='_self' onclick='followLink("+ty[i].prdctid+");'>"+ty[i].prdctname+"</a></td>  <td><button type='button' class='btn btn-outline-primary btn-sm' onclick='initEditing("+i+");'>edit</button></td><td><button type='button' class='btn btn-outline-primary btn-sm' onclick='productDeleter("+i+");'>delete</button></td></tr>";
		
	}
	prevtbl.innerHTML = t;
	//sessionStorage.removeItem("Productmetaload");
	
}


function followLink(id){
	
	url = "../index.html?pinned=";
	location.href = url+id;
	
}

function initEditing(id){
	
	//console.log(id);
	let metaloadinstore = sessionStorage.getItem("Productmetaload");
	let ty = JSON.parse(metaloadinstore);
	
		document.getElementById("productname").innerHTML = ty[id].prdctname;
		document.getElementById("pdctprice").innerHTML = ty[id].prdctprice;
		document.getElementById("pymnturl").innerHTML  = ty[id].paymenturl;
		document.getElementById("uraboutpharma").innerHTML = ty[id].prdctdesc;
		document.getElementById("urphone").innerHTML   = ty[id].ofctelf;
		document.getElementById("uremail").innerHTML   = ty[id].ofcemail;
		document.getElementById("uraddrs").innerHTML   = ty[id].ofcaddr;
		//document.getElementById("urlogo").innerHTML    = ty[id].prdctimg;
	//console.log(ty[id].prdctid);
	sessionStorage.setItem("PRODUCT_ID",ty[id].prdctid);
	sessionStorage.setItem("itemproductuid",ty[id].prdctid);
		
}

//ENABLE FIELD - EDIT ICON
function enableFileds(sentid){

	let enabletextboxField = document.getElementById(sentid);
	enabletextboxField.disabled = false;
	//enabletextboxField.value="";
	enabletextboxField.focus();
	
}


//HANDLE SAVE ICON - & DISABLEd FIELDS
function getSentFieldData(gtId){
		
	let gtitem = document.getElementById(gtId).value;
	//alert(gtId+" - "+gtitem);
	if(gtId != undefined && gtitem  != ""){
		//mysnackbarFunctionu("edit processing"); // at the frontend, the message is overlapped by xthhp response below
		//alert("edit processing");	
		sendtoProfileProcessor(gtId,gtitem);
		document.getElementById(gtId).disabled = true;
	}else{
		//mysnackbarFunctionu("do you mean to edit?");
		alert("you have not made any edit?");	
	}

}


function sendtoProfileProcessor(itemtype,itemEditd){
	let productid = sessionStorage.getItem("PRODUCT_ID");
	//console.log(productid);//return false;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//alert(xhttp.responseText);
			
	        alert(xhttp.responseText);
			loadResults();

	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","../scripts/profileprocessor.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_itemEdited=" +itemEditd +"&send_itemType=" +itemtype+"&send_prdctid="+productid);
}

function productDeleter(id){
	
	let metaloadinstore = sessionStorage.getItem("Productmetaload");
	let ty = JSON.parse(metaloadinstore);
		
	//console.log(ty[id].prdctid);
	
	////////////////////////////////////
	
	let productid = ty[id].prdctid;
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//alert(xhttp.responseText);
			
	        alert(xhttp.responseText);
			loadResults();

	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","../scripts/productdeleter.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_prdctid="+productid);
}