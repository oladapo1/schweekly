//Daily Progress Report
document.addEventListener("DOMContentLoaded",function(){
	
	let tickr_out = 0;
	console.log(tickr_out);
	sessionStorage.setItem("tickr_out",tickr_out);
	//pull neccessary loads
	adminmembrLabel();
	
},false);

//[[{"schuid":"ae46f54463e402e22467f5b8bf2ec3993015418a","verifystatus":"1"}],1]

let dpr_admbtn = document.getElementById("dpradmbtn");

dpr_admbtn.addEventListener("click",pullDPRClasscalled,false);

	function pullDPRClasscalled(){
			
	let classelctor = document.getElementById("pupiltclass");
	let armselector = document.getElementById("clsarm");

	if(classelctor.value == 707 || armselector.value == 777){
		
		alert("Make a selection");
		return false;
	}


	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id = gthschuid[0][0].schuid;//admin section
	
	//console.log(classelctor.value); return false;
	//console.log(sch_id); return false;
	document.getElementById("busydprlist").style.display = "block";


		/* create xhr object */
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200){  
					
				console.log(xhttp.responseText);	
				
				let initresp = JSON.parse(xhttp.responseText);
				
				if(initresp[1] == -1){
					let resptext = "This class has no entries yet";
					let resplbl  = document.getElementById("dprbyclasslist");
					document.getElementById("busydprlist").style.display = "none";
					console.log(resptext);
					resplbl.innerHTML = resptext;
					setTimeout(function(){
						resplbl.innerHTML = "";
					},3000);
					return false;
				}
				
				if(initresp[0] == 0){
				
					//console.log("User not found");
					let resptext = "User not found";
					let resplbl  = document.getElementById("dprbyclasslist");
					document.getElementById("busydprlist").style.display = "none";
					console.log(resptext);
					resplbl.innerHTML = resptext;
					setTimeout(function(){
						resplbl.innerHTML = "";
					},3000);
					

				}else{
								
					sessionStorage.setItem("schweeklymeta",xhttp.responseText);
					document.getElementById("busydprlist").style.display = "none";
					adminviewDailyprogress();
					
					metaTapepupil(classelctor.value,armselector.value);
					 
					//////////////////// 
					sessionStorage.setItem("Classpicked",classelctor.value);
					sessionStorage.setItem("Armpicked",armselector.value);
					////////////////////

				}	

			}
		};
		
		 /* Using POST */
		 
	xhttp.open("POST","../assets/scripts/app/admin/adminglobnxt.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("snd_schid="+sch_id+"&snd_class="+classelctor.value+"&snd_classarm="+armselector.value);
	}

var classarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
var classarmarray = ["A","B","C","D","E","F"];


function metaTapepupil(classtut,classarm){
	
	//let classarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
	//let classarmarray = ["A","B","C","D","E","F"];
	
	let pplclass    = classtut;
	let classarmtut = classarm;
	
	document.getElementById("classpicked").innerHTML = "<p style='font-weight:700;font-size:0.7em;'>Class: "+classarray[pplclass]+" "+classarmarray[classarmtut]+"</p>";
	}


function adminviewDailyprogress(){
let txt = "";
//console.log("dom ");
let classarry = JSON.parse(sessionStorage.getItem("schweeklymeta"));
let classarrylen = classarry[1].length;
//let sweekcounter = sessionStorage.getItem("Countr");

for(i = 0; i < classarrylen;i++){
	let initials = classarry[1][i].pupilsfname.substring(0,1).toUpperCase();
	let names    = classarry[1][i].pupilssurname +"&nbsp;.&nbsp;"+ initials;	
	let pplref   = classarry[1][i].pupilrefnumbr;
	
	//let firstpupilonlist = document.getElementById("pupilnames");
	//firstpupilonlist.innerHTML = names;
	
	txt += "<div class='col-3 col-sm-3'style=''><div class='thumbnail' style='padding:5px;'><img src='images/' alt='' class='img-rounded puplimg' style=''><div class='caption'><h6 style='font-size:0.6em;'>"+names+"</h6><button class='btn btn-outline-dark btn-xs' id='"+pplref+"' value='' style='font-size:0.7em;' onclick='getQueues(this);'>view</button></div></div></div>";
	
}

//console.log("dom "+names);
//let updatedlabel = Number(sweekcounter)+1;
document.getElementById("dprbyclasslist").innerHTML = txt;
//document.getElementById("currclasssize").innerHTML = updatedlabel +"/"+classarrylen;
	  
}

//var tickr_out = 0;

function getQueues(val){

//console.log(val.id); return false;
let ftxt = "";

let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
let sch_id = gthschuid[0][0].schuid;//admin section
let pupil_id = val.id;
//let sch_id   = "AO1-7774442019";//chkstafftype[0][0].schuid; //AO1-7774442019

let classpckd = sessionStorage.getItem("Classpicked");
let clarmpckd = sessionStorage.getItem("Armpicked");
//console.log(classpckd +"--"+clarmpckd);

/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
								
			let initresp = JSON.parse(xhttp.responseText);
			//console.log(initresp.length);return false;
			
			if(initresp[0] == -1 || initresp[0] == 0){
				let resptext = "This pupil has no reports yet";
				let resplbl  = document.getElementById("classpicked");
				//document.getElementById("classpicked").style.display = "none";
				console.log(resptext);
				resplbl.innerHTML = resptext;
				setTimeout(function(){
					resplbl.innerHTML = "";
				},3000);
				return false;
			}else{
							
				sessionStorage.setItem("dprpupillisted",xhttp.responseText);
				let initval = sessionStorage.getItem("tickr_out");
				fillSummaryondpr(initval);

			}
			
  	}
	};
	
	 /* Using POST */ 
	 
xhttp.open("POST","../assets/scripts/app/pupildprlist.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_pupilid="+pupil_id+"&snd_schid="+sch_id+"&snd_class="+classpckd+"&snd_clarm="+clarmpckd);
}


var dprlabels = ["Attendance","Temperament/Mood","Learning","Nap/Rest period","Toileting","State of health","Recreation","Appearance","Home Work","Meals"];

let dpritems = ["I was early to school","I cried when I was dropped","I was late for assembly","I was late to school","I was absent from school","I was quiet","I was happy","I was active","I was moody","I was sleepy","I was friendly","I was unhappy","I wasm curious","I was stubborn","I cried a lot today","I took part in today's activities","I was not interested in todays activities","I enjoyed my number work","I enjoyed my letter work","I enjoyed rhymes","I enjoyed Audio-Visual aid, TV programmes","I slept for a short time","I slept today","I did not sleep at all","I slept for a long time","I wet myself","I did not wet myself","I used the toilet with some help","I used the toilet myself","My diapers were changed","I was well","I vomitted","I was feverish","I had slight headache","I had stomache ache","I was at the sick bay","I had a cold","I was stooling","My temperature was a bit high","I played outdoor","I played indoors","I played with my friends","I was rough at play","I did not play","I played alone","My hair was tidy","My hair was untidy today","I was roughly dressed","I was neatly dressed","I did not wear the correct uniform to school","I did not wear my socks","I did my homework","I did not do my home work","My home work was neatly done","My home work was rough","I did not bring my home work","I ate all my food","I ate a little of my food","I ate none of my food","I did not like my food","I wanted to eat the school food"];


let prevr = document.getElementById("prevdpr");
let nexvr = document.getElementById("nextdpr");
//var tickr_out = 0;

prevr.addEventListener("click",function(){
	
	let tickr_out = Number(sessionStorage.getItem("tickr_out"));
	tickr_out--;
	
	if(tickr_out < 0){
		
		tickr_out = 0;
		
	}
		
		fillSummaryondpr(tickr_out);
	
	
},false);

nexvr.addEventListener("click",function(){
	
	let tickr_out = Number(sessionStorage.getItem("tickr_out"));
	tickr_out++;

	fillSummaryondpr(tickr_out);
	
},false);


function fillSummaryondpr(tickr){
let ftxt = "";
//turnOnPrevNxt();

let dpr_rl = JSON.parse(sessionStorage.getItem("dprpupillisted"));
let dprlen = dpr_rl.length;

		function dprul(tic,dpr_len){
			
			////////////////////////////
			
			let o = tic;

			let arrdpr = [];
			arrdpr[0] = dpr_rl[o].attendance;
			arrdpr[1] = dpr_rl[o].temperament;
			arrdpr[2] = dpr_rl[o].learning;
			arrdpr[3] = dpr_rl[o].naprest;
			arrdpr[4] = dpr_rl[o].toileting;
			arrdpr[5] = dpr_rl[o].healthstatus;
			arrdpr[6] = dpr_rl[o].recreation;
			arrdpr[7] = dpr_rl[o].appearance;
			arrdpr[8] = dpr_rl[o].homework;
			arrdpr[9] = dpr_rl[o].meals;


			/////////////////////////////
			
			for (tic = 0; tic < dpr_len; tic++){
						
				//console.log(tic +"koh");
			
				for(j = 0; j < dprlabels.length;j++){
				
				let d = arrdpr[j];
				let dpr_items = dpritems[d];
				
				ftxt += "<li class='list-group-item' style='font-size:0.95em;'><p style='font-weight:700;font-size:0.7em;color:#880e4f;margin-bottom:-4px;'>"+dprlabels[j]+"</p>"+dpr_items+"</li>";
				
				}
				
				break;
			}
		}

		
	if(dprlen > tickr){
	
	//sessionStorage.setItem("tickr_out",0);	
	turnOnPrevNxt();
	
		}
		
	if(dprlen == 1){
	   
	//sessionStorage.setItem("tickr_out",0);  
	turnOffPrevNxt();
	
		}
		
    if(tickr < dprlen){
		
	//turnOnPrevNxt();	
	  dprul(tickr,dprlen);
		
	}
	

  if(tickr == dprlen){
	tickr = dprlen-1;
	//sessionStorage.setItem("tickr_out",tickr);
	dprul(tickr,dprlen);
  }

sessionStorage.setItem("tickr_out",tickr); 
let uldispsummry = document.getElementById("dprulisted");
uldispsummry.innerHTML = ftxt;
}


function turnOffPrevNxt(){
	
	document.getElementById("prevdpr").style.display = "none";
	document.getElementById("nextdpr").style.display = "none";	
}

function turnOnPrevNxt(){
	
	document.getElementById("prevdpr").style.display = "inline-block";
	document.getElementById("nextdpr").style.display = "inline-block";	
}


//Attendance Manager
// listattendancebyclass  attndancesection

let atnnrqstbtn = document.getElementById("attndancesbmit");
atnnrqstbtn.addEventListener("click",collectAttnerqst,false);

var clsarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6","JSS 1","JSS 2","JSS 3","SSS 1","SSS 2","SSS 3"];
var armarray = ["A","B","C","D","E","F"];
//var arractivebubble = [];

function collectAttnerqst(){

	let atnclass  = document.getElementById("arttnclass");
	let atnclsarm = document.getElementById("arttnarm");
	let atndate1  = document.getElementById("dater1");
	let atndate2  = document.getElementById("dater2");
	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id = gthschuid[0][0].schuid;
	//let stfid     = 111809259;//chkstafftype[0][0].staffrefnumbr;
	
	

	document.getElementById("busydattnlist").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			////////////////////////////////	
			//console.log(xhttp.responseText);
			let initresp = JSON.parse(xhttp.responseText);
			//console.log(initresp.length);return false;
			let lbl = document.getElementById("listattendancebyclass");
			if(initresp[0] == -1){
				lbl.innerHTML = "This teacher has no pupils to view";
				setTimeout(function(){
					lbl.innerHTML = "";
				},5000);
				location.reload();
				return false;
			}else if(initresp[0] !== -1){
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				
				sessionStorage.setItem("schwklyattendance",xhttp.responseText);
				document.getElementById("busydattnlist").style.display = "none";
				//adminviewDailyprogress();
				let attnd = JSON.parse(sessionStorage.getItem("schwklyattendance"));
				
				//console.log(attnd.length);
				
				let atnlen = attnd.length;
				let txt = "";
				
				for(i = 0; i < atnlen; i++){
					
					let ab = attnd[i].absentees;
					let pr = attnd[i].presentees;
					let dte = attnd[i].entrydate;
					
					let keepabs = ab.split(",");
					//arractivebubble = keepabs;
					let absntys = JSON.stringify(keepabs);
					let attntype1 = 0;
					
					//let insta = JSON.parse(absntys);
					//console.log(keepabs +" ABSENTS "+absntys+"--"+insta);
					//console.log(keepabs +" ABSENTS "+absntys);
					//sessionStorage.setItem("Absenteesnames",absntys);
					let absnt = keepabs.length;
					if(ab == 0){		

						absnt = 0;
						
					}
					
					/*for(j = 0;j < absnt; j++){
						//console.log(j);
						//console.log(absnt+"absent");
					}*/
								
					const keeppr = pr.split(",");
					let prsnty = JSON.stringify(keeppr);
					let prt = keeppr.length;
					let attntype2 = 1;
					if(pr == 0){
						
						prt = 0;
						
					}			
															
					/*for(k = 0;k < prt; k++){
						//console.log(k);
						//console.log(prt +"present");
					}*/
				
				txt += "<a href='#' class=\list-group-item list-group-item-action d-flex gap-3 py-3\ aria-current='true'><div class='d-flex gap-2 w-100 justify-content-between'> <div><h6 class='mb-0 badge bg-light text-dark'><span style='font-size:0.9em;'>Date : </span>"+dte+"</h6><p class='mb-0 opacity-75'>"+prt +"present"+"-&amp;-"+absnt+"absent, total attendance = "+(prt+absnt)+"<button type='button' class='btn btn-outline-warning btn-sm' onclick='pullallpupilAttendancebyclass("+absntys+','+attntype1+")'>absents</button> | <button type='button' class='btn btn-outline-warning btn-sm' onclick='pullallpupilAttendancebyclass("+prsnty+','+attntype2+")'>presents</button></p></div><small class='opacity-50 text-nowrap'>now</small></div></a>";
				
				}
			
				//console.log(attnd[2].presentees);
				//console.log(attnd[2].absentees);
				
				//metaTapepupil(classelctor.value,armselector.value);
				
			document.getElementById("attnclasslbl").innerHTML = clsarray[atnclass.value] +"-"+armarray[atnclsarm.value];
				document.getElementById("listattendancebyclass").innerHTML = txt;
				
			}else{
				
				//location.reload();
			}		
  	}
	};
	
	 /* Using POST */

xhttp.open("POST","../assets/scripts/app/attnadminrqst.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_schid="+sch_id+"&snd_class="+atnclass.value+"&snd_classarm="+atnclsarm.value+"&snd_dte1="+atndate1.value+"&snd_dte2="+atndate2.value);	
}


function pullallpupilAttendancebyclass(val,attntype){
	
	event.preventDefault();
	
	let arractive = JSON.stringify(val);
	//console.log(arractive);
	//console.log(val.length); return false;
	let attendancetype;
	if(attntype == 0){
		
		attendancetype = "Absentee(s)";
		
	}else if(attntype == 1){
		
		attendancetype = "Presence";
		
	}
	
	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id = gthschuid[0][0].schuid;
	//let sch_id = "AO1-7774442019";
	//console.log(attntype); //return false;
	document.getElementById("busydattnmeta").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				
				console.log(xhttp.responseText);
				document.getElementById("busydattnmeta").style.display = "none";

				let attndetails = document.getElementById("attndncmeta");
				attndetails.innerHTML = xhttp.responseText;
				
				document.getElementById("subattnlabel").innerHTML = attendancetype;
								
				}else{
				
				//location.reload();
			}		
  	}
	};
	
	 /* Using POST */

xhttp.open("POST","../assets/scripts/app/allpupilattendancetoview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("gt_sch_id="+sch_id+"&collated_array="+arractive);	
}

//pupil mgr

var pupilfdinderbtn = document.getElementById("pupilfinderadm_btn");
pupilfdinderbtn.addEventListener("click",findPupilindb,false);

function findPupilindb(){
//console.log("hy");
let classelctor = document.getElementById("ppilclass");
let armselector = document.getElementById("clsarmppl");
let gthschuid   = JSON.parse(sessionStorage.getItem("schweeklymeta"));
let sch_id      = gthschuid[0][0].schuid;
let stfid       = gthschuid[0][0].staffrefnumbr;

let txt = "";

document.getElementById("busypplfinderlist").style.display = "block";
//console.log("hys");

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
	
			sessionStorage.setItem("pupilforedit",xhttp.responseText);
			document.getElementById("busypplfinderlist").style.display = "none";
			
			//listPupilforedit();
		/////////////////////

		let pupiload = JSON.parse(sessionStorage.getItem("pupilforedit"));
		let pply = pupiload.length;
		//console.log(pply);
		   for(i = 0; i < pply; i++){
			   
				let namespupl = pupiload[i].pupilssurname +" "+ pupiload[i].pupilsfname;
				let pplref    = pupiload[i].pupilrefnumbr;
				console.log(namespupl);
				txt += "<a href='#' class='list-group-item list-group-item-action d-flex gap-3 py-3' aria-current='true'><img src='../assets/images/bluepic.png' alt='pupilpic' width='32' height='32' class='rounded-circle flex-shrink-0'><div class='d-flex gap-2 w-100 justify-content-between'><div><h6 class='mb-0'>"+namespupl+"</h6><p class='mb-0 opacity-75'></p></div><button class='btn btn-outline-primary btn-sm opacity-45 text-nowrap' id='"+pplref+"'>view more</button></div></a>";	
					}

		///////////////////////			
				document.getElementById("holdfoundclass").innerHTML = txt;		
				
				//metaTapepupil(classelctor.value,armselector.value);
				
  	}else{
		
		//console.log("oopf");
	}  

	//console.log("hooy");
};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/findpupilforedit.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_admin_id="+stfid+"&snd_class="+classelctor.value+"&snd_classarm="+armselector.value+"&snd_schid="+sch_id);
}


//THIS FUNCTION MAY BE REQUIRED IN A LATER FEATURE OR ALTOGETHER REMOVED
function listPupilforedit(){
let txt = "";

let pupiload = JSON.parse(sessionStorage.getItem("pupilforedit"));
let pply = pupiload[1].length;

for(i = 0; i < pply; i++){
				let namespupl = pupiload[1][i].pupilssurname +" "+ pupiload[1][i].pupilsfname;
				let pplref    = pupiload[1][i].pupilrefnumbr;
				txt += "<a href='#' class='list-group-item list-group-item-action d-flex gap-3 py-3' aria-current='true'><img src='' alt='' width='32' height='32' class='rounded-circle flex-shrink-0'><div class='d-flex gap-2 w-100 justify-content-between'><div><h6 class='mb-0'>"+namespupl+"</h6><p class='mb-0 opacity-75'></p></div><button class='btn btn-outline-primary btn-sm opacity-50 text-nowrap' id='"+pplref+"'>view more</button></div></a>";
				
			}

document.getElementById("holdfoundclass").innerHTML = txt;	  
}

//Communication
let hwrkbtn = document.getElementById("hwrkmessagerybtn");
hwrkbtn.addEventListener("click",sendHomework,false);

function sendHomework(){
		
	let hwrktxt   = document.getElementById("hmworkmessagr");
	let hwkclass  = document.getElementById("selPresntclasshwrk");
	let hwkclarm  = document.getElementById("classaliashwrk");
	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id = gthschuid[0][0].schuid;
	let stfuid = gthschuid[0][0].staffrefnumbr;
	//let sch_id = "AO1-7774442019";
		
		if(hwrktxt.value == ""){
			alert("Message body empty");
			return false;
		}
		
	document.getElementById("responsehwrk").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				
				console.log(xhttp.responseText);
				document.getElementById("responsehwrk").style.display = "none";
				hwrkbtn.innerHTML = "Homework sent";
				setTimeout(function(){location.reload()},3000);
				
				//document.getElementById("subattnlabel").innerHTML = attendancetype;
								
				}else{
				
				console.log("See support : Homework");
				//location.reload();
			}		
  	}
	};
	
	 /* Using POST */

xhttp.open("POST","../assets/scripts/app/sendtodayhomework.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("gt_sch_id="+sch_id+"&stf_id="+stfuid+"&send_hwrkbdy="+hwrktxt.value+"&snd_clas="+hwkclass.value+"&snd_carm="+hwkclarm.value);
}

/* limit char-word */ 
//replymsgs-chars limit
let limitrplymsg = document.getElementById("messagerscweekly");
limitrplymsg.addEventListener("keydown",function(){
	
	let txtarea    = document.getElementById("messagerscweekly");
	let limitchars = document.getElementById("limreplychars");
	let limnumbr   = 200;
	limitText(txtarea,limitchars,limnumbr);
	
},false);

//homework-chars limit
let limithwrkmsg = document.getElementById("hmworkmessagr");
limithwrkmsg.addEventListener("keydown",function(){
	
	let txtarea    = document.getElementById("hmworkmessagr");
	let limitchars = document.getElementById("limhwrkchars");
	let limnumbr   = 200;
	limitText(txtarea,limitchars,limnumbr);
	
},false);

function limitText(limitField, limitCount, limitNum) {
	//console.log(limitField.value);
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}


let replymessagerybtn = document.getElementById("messagerybtn");
replymessagerybtn.addEventListener("click",msgReplybysch,false);

function msgReplybysch(){
	
	
	//document.getElementById("messagerscweekly").focus();
	
	let rplybody    = document.getElementById("messagerscweekly");
	let msgauthor   = sessionStorage.getItem("ReplyMsgPupilID");//836998111;
	let msgbcastid  = sessionStorage.getItem("ReplyMsguID");//439699597;
	let gthschuid   = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id      = gthschuid[0][0].schuid;
	let stfrplying  = gthschuid[0][0].staffrefnumbr;	
	
	//console.log(msgauthor);
	//console.log(msgbcastid); return false;
	
	
		if(rplybody.value == ""){
			alert("Message body empty");
			return false;
		}
		
	//document.getElementById("responsehwrk").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				
				console.log(xhttp.responseText);
				//document.getElementById("responsehwrk").style.display = "none";
				//hwrkbtn.innerHTML = "sent";
				//setTimeout(location.reload(),2000);
				
				document.getElementById("replyresponse").innerHTML = xhttp.responseText+", kindly exit view";
								
				}else{
				
				//location.reload();
			}		
  	}
	};
	
	 /* Using POST */

xhttp.open("POST","../assets/scripts/app/replymessagebysch.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("gt_sch_id="+sch_id+"&snd_authrid="+msgauthor+"&snd_bcstid="+msgbcastid+"&snd_rplybdy="+rplybody.value+"&snd_wureply="+stfrplying);
}


let admnbtn = document.getElementById("adminmsgbtn");
admnbtn.addEventListener("click",function(){
	
	let t = 1;
	
	loadMsgs(t);
	
},false);

//let tchrbtn = document.getElementById("tchersmsgbtn");
//tchrbtn.addEventListener("click",function(){let t = 0;loadMsgs(t);},false);


var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

var mnth = ["January","February","March","April","May","June","July","August","September","October","November","December"];

/*Swedish yellow - #FFCB05
		Swedish blue - #015393*/
		
function loadMsgs(utype){
	
	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id    = gthschuid[0][0].schuid;
	let stfruid   = gthschuid[0][0].staffrefnumbr;
	//console.log(stfruid);
	//let pplclass = 0;
	//let clssarm  = 3;
	//let txt = "";
	
	//document.getElementById("responsehwrk").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				
				//console.log(xhttp.responseText);return false;
				//////////////////////
			//let initresp = JSON.parse(xhttp.responseText);
			//console.log(initresp.length);return false;
			//let lbl = document.getElementById("msgboardview");
			if(xhttp.responseText){
				document.getElementById("msgboardview").innerHTML = xhttp.responseText;
					//todo						
				sessionStorage.setItem("Messageload",xhttp.responseText);
												
				}else{
					
				alert("See support : message");
				console.log("See support : message"); 
			}		
			
			//document.getElementById("msgboardview").innerHTML = txt;
		}
	};
	
	 /* Using POST */

xhttp.open("POST","../assets/scripts/app/pullmessagefromparents.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("gt_sch_id="+sch_id+"&snd_utype="+utype+"&snd_stfrid="+stfruid);
	
}

/*
function scrolltoView(){
	console.log("lsgh");
let movtoview = document.getElementById("messagebox");
movtoview.scrollIntoView();

}*/

function keepreplymeta(pplid,msgid){
	
	//document.getElementById("messagebox").scrollIntoView();
	event.preventDefault();
	console.log(pplid.id+"-"+msgid);
	//scrolltoView();
	let p = pplid.id;
	let m = msgid;
	sessionStorage.setItem("ReplyMsgPupilID",p);
	sessionStorage.setItem("ReplyMsguID",m);
}

//logout
var gtlogoutrequest = document.getElementById("adminlogoutbtn");

gtlogoutrequest.addEventListener("click",function(){logmeOutnow();},false);

var keyItemsinsessionstore = ["Armpicked","Classpicked","Countr","dprpupillisted","Messageload","pupilforedit","schweeklymeta","schwklyattendance","tickr_out","Usermetaload"];

//remember to put an indicator for the redirection progress on logout

function logmeOutnow(){

	document.getElementById("resplogout").style.display = "inline-block";
	
	for(j = 0; j < keyItemsinsessionstore.length; j++){
		
		var itemsn = keyItemsinsessionstore[j];
		
		sessionStorage.removeItem(itemsn);
	} 
	
	//document.getElementById("resplogout").style.display = "none";
	setTimeout(syouLater,2000);
}

function syouLater(){
	
	location.href = "../signin.php";
	//location.href = "../scripts/clearsessionout_m.php";
}

function adminmembrLabel(){
	
	//console.log("Names here");
	
	let gthdetails = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id  = gthdetails[0][0].schuid;
	let stfruid = gthdetails[0][0].staffrefnumbr;
	let sname   = gthdetails[0][0].staffsurname;
	let fname   = gthdetails[0][0].stafffname;
	let classt  = clsarray[gthdetails[0][0].classtut];
	let clarm   = armarray[gthdetails[0][0].classarm];
	let names;
	let classdtls;
	let namelabel  = document.getElementById("adminmembrlbl");

	if(sname == undefined || fname == undefined || classt == undefined || clarm == undefined){
		
		names = sch_id.substring(15,0)+"........"; 
		//len = 40
		namelabel.innerHTML = "Hello, "+names;
		
	}else{
		
		names = sname +" "+ fname;
	    classdtls = classt +" "+ clarm;
        namelabel.innerHTML = "Hello, "+names +"-"+classdtls;		
	}
		
}