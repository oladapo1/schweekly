<!DOCTYPE html>
<html lang="en">
<head> 
  <title>School Backend-PData</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="images/logo_s.jpg" type="image/x-icon">
  <meta name="Keywords" content="">
  <meta name="Description" content="App to allow schools to manage their students, log payments, daily progress report etc from a parent - centre viewpoint with ease.">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/jquery.cycle.all.js"></script> 
  <script src="js/angular.js"></script>
	<script src="js/angular-route.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/sidenavjs.js"></script>
<link rel="stylesheet" href="css/dskstyles.css"/>
<link rel="stylesheet" href="css/sidenavcentrecss.css"/>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60" ng-app="myApp">

<!--SideNav-->

<div id="mySidenav" class="sidenav" style="background-color:#015393;">
  <p href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="cursor:pointer;color:#fff;">&times;</p>
  <div style="height:0.052em;background-color:lightblue;width:80%;margin:10px auto;"></div>
  
  <a href="#pupilsprofile" title="Set pupils Profile"><img src="images/login.png" alt="pupilsprof"> Pupils Profile </a>
  <a href="#staffmgr" title="Manage Teachers"><img src="images/staffmgr.png" alt="staffmgre"> Teacher Profile</a>
  <a href="#cdailyreports" title=" Progress Report"><img src="images/deffre.png" alt="deferers"> Daily Progress Report</a>
  
  <!--<a href="#setbatches" title="All comments"><img src="images/suggestioncomp.png" alt="setbatch"> Comments</a>-->
  <a href="#uplodmedia" title="My School Media"><img src="images/uploaddoc.png" alt="updocs"> Media</a>
</div>

<!-- Use any element to open the sidenav -->
<!--<span onclick="openNav()">open</span>-->
<span style="font-size:20px;cursor:pointer;padding-left:20px;" onclick="openNav()" class="sidenavstarts">&#9776;</span><span class="" style="margin-left:1250px;" title="school engine"><img src="images/logo_s.jpg" alt="" class="" style="width:24px;"></span>
<div style="background-color:#FFCB05;padding:1px;">
<span style="margin-top:35px;position:fixed;left:1100px;background-color:#fff;padding:5px;border-radius:15px;" title="hi, am Dapo : your digital assistant" class="pull-right"><a href="#" target="_blank"><i class="fa fa-fw fa-linkedin-square" style="font-size:20px;" title="Dapo : Linkedin"></i></a>
    <a href="#" target="_blank"><i class="fa fa-fw fa-whatsapp" style="font-size:20px;" title="Dapo : WhatsApp"></i></a>
     <a href="#" target="_blank"><i class="fa fa-fw fa-twitter-square" style="font-size:20px;" title="Dapo : Twitter"></i></a> &nbsp;<img src="images/mypix.jpg" alt="assistant" class="img-circle" style="margin-right:10px;border:4px solid lightblue;"></span>
	 </div>
<!--SideNavEnds-->

<!-- Container (Mainview Section) -->
<div class="container-fluid bg-grey" id="mview">
<!--<p>Happy</p>-->
  <div class="row" id="in1mview">
  <div class="col-sm-2">
  </div>
     <div class="col-sm-8" id="in2mview" ng-view>
      
    </div>
	<div class="col-sm-2">
  </div>
  </div>
</div>
<br>

<script>
var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/schoolmnu", {
        templateUrl : "c/schoolmenu.php"
		
    })
	.when("/schoolprofilr", {
        templateUrl : "c/schoolprofiler.php"
    })
    .when("/pupilsprofile", {
        templateUrl : "c/pupilsprofile.php"
        
    })
   
    .when("/updpaymnents", {
        templateUrl : "c/updtpaymnents.php"
    })
    .when("/mgtermactivities", {
        templateUrl : "c/cctermmgr.php"
    })
    
     .when("/setbatches", {
        templateUrl : "c/csetbatches.php"
    })
    
     .when("/staffmgr", {
        templateUrl : "c/staffmangr.php"
    })
     .when("/uplodmedia", {
        templateUrl : "c/cuplodmedias.php"
    })
    
	.when("/policies", {
        templateUrl : "c/policiesbay.php"
    })
	
    .when("/announmnts", {
        templateUrl : "c/cannounmnts.php"
    })

	.when("/vapprasals", {
        templateUrl : "c/cvapprasals.php"
    })
	.when("/updcocode", {
        templateUrl : "c/cupdcocode.php"
    })
	.when("/hairstyleoftweek", {
        templateUrl : "c/hairstylesodwgrids.php"
    })
    .when("/cdailyreports",{
        templateUrl : "c/ccdailyprogreport.php"
    });
})
</script>


<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p>Made By <a href="tel:+23408020597327" title="AlphaTrax">AlphaTrax Software</a> for You &copy; <?php print date('Y') ?></p>
</footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Prevent default anchor click behavior
    event.preventDefault();

    // Store hash
    var hash = this.hash;

    // Using jQuery's animate() method to add smooth page scroll
    // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 900, function(){
   
      // Add hash (#) to URL when done scrolling (default click behavior)
      window.location.hash = hash;
    });
  });
  
  // Slide in elements on scroll
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>
</body>
</html>