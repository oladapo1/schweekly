//refactor chkloginLoad_ifempty function to a single file and pass argument to parameter

var getLoginLoad = document.getElementById("login_owabtnid");

getLoginLoad.onclick = chkloginLoad_ifempty;

function chkloginLoad_ifempty(){

var gtLoginPasskey = document.getElementById("login_owapwd").value;
var gtLoginUname = document.getElementById("login_owaun").value;
//var gtRemme = document.getElementById("rem_me_owa").value;

if(gtLoginUname == "" || gtLoginPasskey == ""){
	
	alert("All fields are required");
	document.getElementById("login_owaun").focus();
	return false;
	
	}else{
		
		muv_login_Up(gtLoginUname,gtLoginPasskey);
		//alert(gtLoginUname + " -- " + gtLoginPasskey);
	
	}

}

function muv_login_Up(owaUname,owaPasskeyr){
	
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			
			//if(xhttp.responseText==='OK'){
				if(xhttp.responseText){
				//alert("sent :)");
				//alert(xhttp.responseText);
				document.getElementById('verifynow').innerHTML = xhttp.responseText;
				//location.href="getstarted.php";
				//location.href="indexcentrePData.php";
				//location.reload();
				//document.getElementById("comment_load").value="";
				//document.getElementById("comment_load").focus();
			}else{
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/login_komaalo.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +owaUname + "&send_lg_Pwd=" +owaPasskeyr);
}





