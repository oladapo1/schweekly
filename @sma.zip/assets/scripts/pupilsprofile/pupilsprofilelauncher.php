<?php
/* todo */
/* check for Pupil SUID / School SURN and session to activate the function herein */

//session_start();
//$chkSchSURNFieldinsession = $_SESSION["universealvar"];

require_once('pupilsproftodb.php');

//require_once('');

class PupilProfileToDBLauncher{
	/* constructor */
	function __construct($pupilsurnamep,$pupilfnamep,$pupilmnamep,$pupilgenderp,$pupilpresntclassp,$pupilclsarm,$pupil_sch){
		 
		/* call constructor in pupilsproftodb */
	new SendAllPupilProfilevalues($pupilsurnamep,$pupilfnamep,$pupilmnamep,$pupilgenderp,$pupilpresntclassp,$pupilclsarm,$pupil_sch);
	}
	}
	
	/* todo */
	/* rem to Sanitize and validate */
$pupilsurname    = $_POST['send_pupil_sname'];
$pupilfname      = $_POST['send_pupil_fname'];
$pupilmname      = $_POST['send_pupil_mname'];
$pupilgender     = $_POST['send_pupil_gender'];
$ppilpresntclass = $_POST['send_pupil_prsntclass'];
$pupilclsarm     = $_POST['send_pupil_arm'];
$pupilsch        = $_POST['send_schuid'];


//print_r($_POST);

new PupilProfileToDBLauncher($pupilsurname,$pupilfname,$pupilmname,$pupilgender,$ppilpresntclass,$pupilclsarm,$pupilsch);