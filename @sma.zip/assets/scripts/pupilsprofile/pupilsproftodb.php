<?php
require_once('../common/randcodegennr.php');
class SendAllPupilProfilevalues{
	/* contructor */
	
	
	private $pupilsurnamep;
	private $pupilfnamep;
	private $pupilmnamep;
	private $pupilgenderp;
	private $pupilpresntclassp;
	private $clsarm;
	private $pupilRFN;
	private $schSURN;
	
	/* contructor */
	function __construct($pupilsurnamep,$pupilfnamep,$pupilmnamep,$pupilgenderp,$pupilpresntclassp,$pupilclsarm,$pupil_sch){
		
	$this->pupilsurnamep     = $pupilsurnamep;
	$this->pupilfnamep       = $pupilfnamep;
	$this->pupilmnamep       = $pupilmnamep;
	$this->pupilgenderp      = $pupilgenderp;
	$this->pupilpresntclassp = $pupilpresntclassp;
	$this->clsarm            = $pupilclsarm;
	$this->schSURN           = $pupil_sch;
	
		//call function now to insert values
	$this->sendAllPupilProfilevaluesNow();
	}
	
	function sendAllPupilProfilevaluesNow(){
	
	include("../conect/connection.php");
	
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		
		$newUID = new Randomuiidgen; //generate unique ID for schuid
		//echo $this->pupilpresntclassp; die();
		
		if($this->pupilpresntclassp >= 0 && $this->pupilpresntclassp <= 9){
			
		$this->pupilRFN = "PRF".$newUID->createUID();
		
		}else if($this->pupilpresntclassp >= 10 && $this->pupilpresntclassp <= 15){
			
		$this->pupilRFN = "SRF".$newUID->createUID();
		
		}
		
		
if(!empty($this->schSURN)){
				
		$query = "INSERT INTO pupilsprofile (schuid,pupilrefnumbr,pupilssurname,pupilsfname,pupilsmname,gender,presentclass,classalias,entrydate) VALUES ('$this->schSURN','$this->pupilRFN','$this->pupilsurnamep','$this->pupilfnamep','$this->pupilmnamep','$this->pupilgenderp','$this->pupilpresntclassp','$this->clsarm','$mklogdindatetime')";
		
				if ($conn->query($query) === TRUE) {
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
}
}