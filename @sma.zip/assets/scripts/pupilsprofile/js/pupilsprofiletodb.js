var gtrcentpupilsbatch = document.getElementById("postpupilscontent");
gtrcentpupilsbatch.onclick = pushpupilsDetails;

function pushpupilsDetails(){
	
	var gtPupilsurname = document.getElementById("pupilsName0").value;
	var gtPupilsfname  = document.getElementById("pupilsName1").value;
	var gtPupilsmname  = document.getElementById("pupilsName2").value;
	var gtPupilsgender = document.getElementById("selgender").value;
	//var gtPupilsPrsntClass = document.getElementById("selPresntclass").value;	
	//var gtPplclassarm      = document.getElementById("classalias2").value;

	let gthschuid = JSON.parse(sessionStorage.getItem("schweeklymeta"));
	let sch_id    = gthschuid[0][0].schuid;
	let gtPupilsPrsntClass = gthschuid[0][0].classtut;
	let gtPplclassarm      = gthschuid[0][0].classarm;
	
	//console.log(gtPplclassarm+"-"+gtPupilsPrsntClass); return false;
	
	if(gtPupilsurname == "" && gtPupilsfname == ""){
		alert("All fields required!");
		return false;
	}
	else{
		
		//alert(gtPupilsurname+" "+gtPupilsEmail);
	
		//gtrcentschoolbatch.innerHTML = "<i class='fa fa-circle-o-notch fa-spin'></i>";
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
	
			alert(xhttp.responseText);
					
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/pupilsprofile/pupilsprofilelauncher.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send(
"send_pupil_sname="+gtPupilsurname+
"&send_pupil_fname="+gtPupilsfname+
"&send_pupil_mname="+gtPupilsmname+
"&send_pupil_gender="+gtPupilsgender+
"&send_pupil_prsntclass="+gtPupilsPrsntClass+
"&send_pupil_arm="+gtPplclassarm+
"&send_schuid="+sch_id
);
}
}