function determImgCatgox(e){
	//alert(e+" +ok");
	passImgCatgotoHandler(e);
}

function passImgCatgotoHandler(filepix){
	//alert(filepix +" from profile pixle");
var form = document.forms.namedItem(filepix);
form.addEventListener('click', function(ev) {
	
	//alert(filepix);
	//alert(ev);
  //var file = this.files[0];
  //var fd = new FormData(form);
  //fd.append("pupilsPix", file);
 var oOutput = document.getElementById("uploadmsg"),
      oData = new FormData(form);
	//alert(oData);
  oData.append("UploadDir", folderToUpload);
  oData.append("Category", pupilsPix);
//alert(oData);
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/pupilpixuploader.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;
	  
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br \/>";
    }
  };
  oReq.send(oData);
  ev.preventDefault();
}, false);
}