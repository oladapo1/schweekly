<?php
function sendVotedArticles(){
$gtdelgateid = $_POST["memberid"];
$gtvideoid = $_POST["sndvotedvideo"];
$updtr = 1;
include("connection.php");
if(!empty($gtdelgateid) || !empty($gtvideoid)){
				
		////////////////////////////////////////////
	
		$query = "INSERT INTO yzonevideos (videoid,delegateid) VALUES ('$gtvideoid','$gtdelgateid')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "Added";
					 
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////	
	}
	else{
		print"No  rights";
	}	
}
sendVotedArticles();