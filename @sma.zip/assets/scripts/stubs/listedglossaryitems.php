<?php
/* $getglossid = $_POST['send_glossid'];
print $getglossid; */

function processGlossaryreqItems(){
		
$getglossid = $_POST['send_glossid'];

include "connection.php";
   
 $sql =<<<EOF
      SELECT ID,TRADENAME,GENRICNAME,CATEGORY,TCATEGORY,COUNSELN from GLOSSARYTBL WHERE ID = '$getglossid';
EOF;

$ret = $db->query($sql);
  while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
	 $getID = $row['ID'];
	 $getTname = $row['TRADENAME'];
	 $getGname = $row['GENRICNAME'];
	 $getGcatefory= $row['CATEGORY'];
	 $getThrepCategory = $row['TCATEGORY'];
	 $getCounsln = $row['COUNSELN'];
	 
    /*  echo $row['ID'];
	 echo $row['TRADENAME'];
	 echo","; */
	echo"
	<div class='scrollbar' id='glossaryscustom'>
	  <div class='well well-sm force-overflow' style='height:200px;border-bottom:none;'>
	
	  <small style='font-size:0.65em;background-color:#fff;padding:3px;'>Trade name:</small><br>
	  <span id='trdname' class='' style='font-size:0.8em;'> $getTname</span><br>
	  
	  <small style='font-size:0.65em;background-color:#fff;padding:3px;'>Generic name:</small><br>
	  <span id='genrname' class='' style='font-size:0.8em;'> $getGname</span><br>
	  
	  <small style='font-size:0.65em;background-color:#fff;padding:3px;'>General Category:</small><br>
	  <span id='gencat' class='' style='font-size:0.8em;'>$getGcatefory</span><br>
	  
	  <small style='font-size:0.65em;background-color:#fff;padding:3px;'>Therapeutic Category:</small><br>
	  <span id='thpticcat' class='' style='font-size:0.8em;'>$getThrepCategory </span><br>
	  
	  <small style='font-size:0.65em;background-color:#fff;padding:3px;'>Counseling Advise:</small><br>
	  <span id='counsadv' style='font-size:0.8em;text-align:justify;'>$getCounsln</span>
	  
  </div>
</div>  
	 ";
	 
	 
  }

}

processGlossaryreqItems();