<?php
class AnswerMgr{
	
	private $ansd_Item;
	//private $item_quest;
	private $questn_Type;
	private $dev_sentid;
	
	
	function __construct($anws_Item,$quest_Type,$webdev_id){
		
		$this->ansd_Item   = $anws_Item;
		//$this->item_quest  = $quest_Item;
		$this->questn_Type = $quest_Type;
		$this->dev_sentid  = $webdev_id;
		self::chckAttemptstatus();
		
	}
		
	function chckAttemptstatus(){
	
	include("conect/connection.php");
	$sstatus = 1;$ostatus = 0;$alreadyattmped = 1; $canntprocnow =-1;
	$sqlchkschuid = "SELECT * from returndanswer WHERE userid = '{$this->dev_sentid}' AND attmptstatus = '1'  AND questype  ='{$this->questn_Type}'";

	$resultgtdata = $conn->query($sqlchkschuid);

	if ($resultgtdata->num_rows > 0) {

	   while($rowrchkr = $resultgtdata->fetch_assoc()) {
		
		$gtstatus = $rowrchkr["attmptstatus"];
		
				if($gtstatus == $sstatus){
					
					echo $alreadyattmped; //already attempted question
				}
	   }
	   }else{
		
		self::processAnswers(); //now initialize a new instance for answerload entry
		//echo $canntprocnow;
	}
		$conn->close();
	
	}


		//returndanswer-userid		questype	questansnload	attmptstatus	
	function processAnswers(){
			
		include("conect/connection.php");
			//$userprofileinitgood = 14;
			$attemptstate = 1;$successfuldone = 8;
		$query = "INSERT INTO returndanswer (userid,questype,questansnload,attmptstatus) VALUES ('$this->dev_sentid','$this->questn_Type','$this->ansd_Item','$attemptstate')";
				if ($conn->query($query) === TRUE) {					 	
						//echo $userprofileinitgood;
						echo $successfuldone;//"Newload successfully ";

				}else {
				echo "Error: " . $query . "<br>" . $conn->error;
			}

			$conn->close();
	}
}

	$ans_Item  = $_POST['send_ansqload'];
	//$questItem = $_POST['send_qstn'];
	$questType = $_POST["send_qtype"];
	$webdevid  = $_POST["send_devid"];
	
	$profileSchools = new AnswerMgr($ans_Item,$questType,$webdevid);
//print_r($_POST);


