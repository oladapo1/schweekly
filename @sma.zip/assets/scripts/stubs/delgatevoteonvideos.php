<?php
function pullVideosstoview(){
 include "connection.php";
 $checksendrid = $_POST['memberid']; // do a full check
if(!empty($checksendrid)){
  //////////////////////
	// Attempt select query execution
	$sql = "SELECT videonamed,videotitle,vidcreated,videoid FROM videomgr";
		if($result =  $conn->query($sql)){
				if($result->num_rows > 0){
					while($row = $result->fetch_assoc()){
					 //$gtvidtitle   =  $row['videonamed'];
					 $gtvidtitle   =  $row['videotitle'];
					 $gtvidcreatd  =  $row['vidcreated'];
					 $gtvidid      =  $row['videoid'];
					 ///////////////////////
						$sqlartclchk = "SELECT videoid FROM yesbavideopool WHERE videoid = $gtvidid AND delegateid = $checksendrid";
							if($result2 =  $conn->query($sqlartclchk)){
								if($result2->num_rows > 0){
						
								//echo"Already voted";
								continue;
							}
						}						
					 //////////////////////
					 echo "
					 <tr id='td$gtvidid'>
					<td>$gtvidcreatd</td>
					<td style='font-weight:600;'>$gtvidtitle</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;' onclick='alert($gtvidid);'>Watch</button>
					</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;' id='$gtvidid' onclick='hideremoveItemfromList(this.id);sendVideovotedfor(this.id);'>Vote</button>
					</td>
				  </tr>
					 ";
					 }	
				} else{
					echo "<p>No matches found</p>";
				}
			} else{
				echo "ERROR: Could not able to execute $sql. " . $conn->error;
			}  
  
  
  /////////////////////
}else{
	echo "Admin rights absent";
}	
// close connection
$conn->close();

}
pullVideosstoview();