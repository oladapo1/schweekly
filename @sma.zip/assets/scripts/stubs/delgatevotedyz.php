<?php
function sendVotedArticles(){
$gtdelgateid = $_POST["memberid"];
$gtarticleid = $_POST["sndvotedarticle"];
$updtr = 1;
include("connection.php");
if(!empty($gtdelgateid) || !empty($gtarticleid)){
				
		////////////////////////////////////////////
	
		$query = "INSERT INTO yzonearticles (articleid,delegateid) VALUES ('$gtarticleid','$gtdelgateid')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "Added";
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////	
	}
	else{
		print"No  rights";
	}	
}
sendVotedArticles();