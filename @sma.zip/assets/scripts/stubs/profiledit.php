<?php
class ProfileMgr{
	
	private $editd_Item;
	private $edt_ItemType;
	private $gtsch_sentid;
	private $item_Field;
	
	function __construct($editd_Item,$editd_ItemType,$gtsch_sentid){
		
		$this->editd_Item     = $editd_Item;
		$this->edt_ItemType   = $editd_ItemType;
		$this->gtsch_sentid   = $gtsch_sentid;
		self::processUserProfile();
	}
	
		
	function processUserProfile(){
			
			include("conect/connection.php");
			
			if(!empty($this->gtsch_sentid)){
				//////////////////////////////////////
						
			switch($this->edt_ItemType){
				case ($this->edt_ItemType == "fir_name");
				$this->item_Field = "firstname";
				break;
				case ($this->edt_ItemType == "lastname");
				$this->item_Field = "lastname";
				break;
				case ($this->edt_ItemType == "");
				$this->item_Field = "genderx";
				break;
				case ($this->edt_ItemType == "telf1");
				$this->item_Field = "telf";
				break;
				case ($this->edt_ItemType == "mememail");
				$this->item_Field = "email";
				break;
				case ($this->edt_ItemType == "mygendrsubmitoken");
				//case ($this->edt_ItemType == "gfmale");
				$this->item_Field = "genderx";
				break;
				case ($this->edt_ItemType == "mycontryubmitoken");
				$this->item_Field = "country";
				break;
				default:
				print"Voops - Contact admin";
			 }
			
			/* date_default_timezone_set("Africa/Lagos");
			$mklogdindatetime = date("Y-m-d h:i:s",time()); */
			
			$sql = "UPDATE webdevprofile set $this->item_Field = '$this->editd_Item'  WHERE useruid = '$this->gtsch_sentid'"; 
				
			if ($conn->query($sql) === TRUE) {
				echo "Profile updated successfully";
			} else {
				echo "Error updating record: " . $conn->error;
			}
				
				//////////////////////////////////////
				//$gtmembersendingxid = $this->gtsch_sentid;
				//initialize member profile uid
				//new NewmemberInitprofile($send_schid);
			}else{
				//echo "No member Id given";
				die("No Id given");
			}


			$conn->close();
	}
}

	
	$editdItem     = $_POST['send_itemEdited'];  // values of element edited
	$editdItemType = $_POST['send_itemType'];	//id names of the elements
	$gtschsentid   = $_POST["send_schid"];     //gtmembersendingxid

	$profileSchools = new ProfileMgr($editdItem,$editdItemType,$gtschsentid);
//print_r($_POST);


