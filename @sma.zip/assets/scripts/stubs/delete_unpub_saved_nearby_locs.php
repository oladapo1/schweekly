<?php
function locationtoUnpublish(){
$sent_membr_ids  = $_POST["sent_membr_ids"];
$sent_itm_ids  = $_POST["sentitem_id"];

include("connection.php");

$sql=<<<EOF
  UPDATE nearbyloc set optncount = '1' WHERE locsavduid = $sent_itm_ids AND membrid = $sent_membr_ids;
EOF;

	if ($conn->query($sql) === TRUE) {
			echo "Action effected successfully";
		} else {
			echo "Error updating record: " . $conn->error;
		}
$conn->close();
}
locationtoUnpublish();