<?php
 include "connection.php";
 $termer = $_POST['send_delgatenamechar'];
// Escape user inputs for security
 $term = mysqli_real_escape_string($conn, $termer);
 
if(isset($term)){
    // Attempt select query execution
    $sql = "SELECT * FROM user_signupmgr WHERE fname LIKE '" . $term . "%' || lname LIKE '" . $term . "%'";
    //$sql = "SELECT * FROM signup WHERE firstname LIKE '%".$term."%'"; 
    //$sql = "SELECT * FROM signup WHERE firstname LIKE '". $term . "%'";
    if($result =  $conn->query($sql)){
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
				$gtdelgteid  =  $row['memberid'];
    echo "<tr>";
     //echo "<td>". $row['memberid'] ."</td>";
	 echo "<td>". "<img src='images/profileimages/$row[photo]' style='width:32px;'>" ."</td>";
	 echo "<td>". $row['emailofpharm'] ."</td>";
     echo "<td>". $row['fname']."</td>";
     echo "<td>".$row['lname'] ."</td>";
	 echo "<td><a href='#' class='btn btn-warning btn-sm' role='button' onclick='addDelgates($gtdelgteid),pullDelgatestoview();'>Add</a></td>";
	 echo "</tr>";
                //echo "<p>" . $row['firstname'] . "</p>";
            }
            
        } else{
            echo "<p>No matches found</p>";
        }
    } else{
        echo "ERROR: Could not able to execute $sql. " . $conn->error;
    }
} else{
	print "Sorry!Enter someone's name..up there in the searchbar?";
} 
 
// close connection
$conn->close();