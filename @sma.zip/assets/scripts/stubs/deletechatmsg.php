<?php
function bookMarkmgr(){
	
	$gtmembersid  = $_POST["send_myid"];
    $gtmsgidtodel = $_POST["send_delchatid"];
	
	include "connection.php";
  
	if(!empty($gtmembersid) && !empty($gtmsgidtodel)){
	
	$sql = "UPDATE chatmgr set deletstatus = 1, deltdated = CURRENT_TIMESTAMP WHERE chatid = $gtmsgidtodel AND memberid = $gtmembersid"; 
		
	if ($conn->query($sql) === TRUE) {
		echo "Field updated successfully";
	} else {
		echo "Error updating record: " . $conn->error;
	}
	
}else{
	
		die("No details supplied");
	}
	
$conn->close();
}

bookMarkmgr();