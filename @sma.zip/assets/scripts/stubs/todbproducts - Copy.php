<?php
include "connection.php";
if (isset($_POST['send_shpid'])){
$eproducts = $_POST['send_prodct'];
$pricing = $_POST['send_price'];
$qtties = $_POST['send_qty'];
$shpidvalue = $_POST['send_shpid'];
$shpnamed = $_POST['send_shpname'];
//echo $eproducts."---".$pricing."---".$qtties."--".$shpidvalue;
	
   $sql =<<<EOF
      INSERT INTO PRODUCTSTBL (PRODUCTS,PRICE,QTY,SHOPUID,SHOPNAME,DATEDITEM) VALUES ('$eproducts','$pricing','$qtties','$shpidvalue','$shpnamed',CURRENT_TIMESTAMP);

EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Products Created";
   }
  }
   
include "closedb.php";

header("Refresh:1; eproducts.php");
   
?>