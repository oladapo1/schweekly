<?php		
function suspendDelegatedfromlist(){
		
include('connection.php');
$suspend = 1;
 $checksendrid = $_POST['send_membrid'];
	if(!empty($checksendrid)){
	$delegtodel = $_POST['send_delgateID'];
	$gtsuspendstate = $_POST['suspendstate'];
	if(!empty($delegtodel) || !empty($gtsuspendstate)){
		//////////////////
	$sql = "UPDATE yesbadelegatestbl SET suspendstatus = $gtsuspendstate WHERE delgateid = $delegtodel";

				if ($conn->query($sql) === TRUE) {
					echo " Update successful";
				} else {
					echo "Error updating record: " . $conn->error;
				}
	//////////////////
}else{echo"Member delegate id missing";}
	}else{
		echo "Admin rights required";
	}
	
$conn->close();	
}
suspendDelegatedfromlist();