<?php
function sendPodcastAdded(){
$gtdelgateid = $_POST["memberid"];
$gtaudioid = $_POST["sndvotedpodc"];
$updtr = 1;
include("connection.php");
if(!empty($gtdelgateid) || !empty($gtaudioid)){
				
		////////////////////////////////////////////
	
		$query = "INSERT INTO yzonepodcasts (podcastid,delegateid) VALUES ('$gtaudioid','$gtdelgateid')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "Added";
				 
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////	
	}
	else{
		print"No  rights";
	}	
}
sendPodcastAdded();