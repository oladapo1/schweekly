<?php		
function deleteDelegatedfromlist(){
		
include('connection.php');
 $checksendrid = $_POST['send_membrid'];
	if(!empty($checksendrid)){
	$delegtodel = $_POST['send_delgateID'];
	if(!empty($delegtodel)){
		// sql to delete a record
	$sql = "DELETE FROM yesbadelegatestbl WHERE delgateid = $delegtodel";

	if ($conn->query($sql) === TRUE) {
		echo "Delegate removed successfully";
	} else {
		echo "Error deleting: " . $conn->error;
	}
}else{echo"Member delegate id missing";}
	}else{
		echo "Admin rights required";
	}
	
$conn->close();	
}
deleteDelegatedfromlist();