<?php
function sendVotedArticles(){
$gtdelgateid = $_POST["memberid"];
$gtarticleid = $_POST["sndvotedarticle"];
$updtr = 1;
include("connection.php");
if(!empty($gtdelgateid) || !empty($gtarticleid)){
				
		////////////////////////////////////////////
	
		$query = "INSERT INTO yesbaarticlepool (articleid,delegateid) VALUES ('$gtarticleid','$gtdelgateid')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "Voted";
					
			//////////////Update Article count by delegate in Article tbl/////////////////
			$sql = "UPDATE yesbaarticles SET delgtvotecount = delgtvotecount+$updtr WHERE featarticleid = $gtarticleid";

				if ($conn->query($sql) === TRUE) {
					echo " - update successful";
				} else {
					echo "Error updating record: " . $conn->error;
				}
		//////////////Update Article count by delegate in Article tbl ends/////////////////
					 
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////	
	}
	else{
		print"No  rights";
	}	
}
sendVotedArticles();