<?php
function sendVotedArticles(){
$gtdelgateid = $_POST["memberid"];
$gtaudioid = $_POST["sndvotedpodc"];
$updtr = 1;
include("connection.php");
if(!empty($gtdelgateid) || !empty($gtaudioid)){
				
		////////////////////////////////////////////
	
		$query = "INSERT INTO yesbapodcpool (podcstid,delegateid) VALUES ('$gtaudioid','$gtdelgateid')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "Voted";
					
			//////////////Update Article count by delegate in Article tbl/////////////////
			$sql = "UPDATE podcastmgr SET delgtvotecount = delgtvotecount+$updtr WHERE audioid = $gtaudioid";

				if ($conn->query($sql) === TRUE) {
					echo " - update successful";
				} else {
					echo "Error updating record: " . $conn->error;
				}
		//////////////Update Article count by delegate in Article tbl ends/////////////////
					 
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////	
	}
	else{
		print"No  rights";
	}	
}
sendVotedArticles();