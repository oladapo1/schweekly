<?php
class Pinnedlogo{
//C:\wamp\www\captitude\assets\dist\images\logo		"../images/logo";
private $getUploadtoDir; 
private $getImgfile;
private $gtuserid;
private $imgname;

function __construct($dpixfolder,$fileinptd,$imgnamed,$membruide){
		
		$this->getUploadtoDir = $dpixfolder;
		$this->getImgfile     = $fileinptd;
		$this->imgname        = $imgnamed;
		$this->gtuserid       = $membruide;
		$this->pushprofilePicture();
	
	}

function pushprofilePicture(){
$target_dir = "$this->getUploadtoDir/";
$target_file = $target_dir . basename($_FILES[$this->getImgfile]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
/* if(isset($this->gtuserid)){
    $check = getimagesize($_FILES[$this->getImgfile]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
} */
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES[$this->getImgfile]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES[$this->getImgfile]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES[$this->getImgfile]["name"]). " has been uploaded.";
		$this->updatememberprofilePicture($_FILES[$this->getImgfile]["name"],$this->gtuserid);//pass image name and agentID to updater function
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

}

function updatememberprofilePicture($pixname,$gtuserid){
	//this module does not take into consideration -  most recent update field
	include("conect/connection.php");
	if(isset($gtuserid)){

	$sql = "UPDATE webdevprofile set picture = '{$pixname}' WHERE useruid = '$gtuserid'"; 
		
			if ($conn->query($sql) === TRUE) {
				echo "Picture name updated successfully";
				} else {
				echo "Error updating record: " . $conn->error;
			}

			$conn->close();
		}
	} 

}

/* print_r($_POST);
//print "imagname : ".$imgname;
print_r($_FILES); */

$dirc     = $_REQUEST['UploadDir'];
$fileinpt = $_REQUEST['ImagefromFileInput'];
$filename = $_FILES[$fileinpt]["name"];
$membruid = $_REQUEST['Whoeditnpix'];

new Pinnedlogo($dirc,$fileinpt,$filename,$membruid);