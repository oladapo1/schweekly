<?php
/* $disptched = $_POST['send_dispatchtype'];
$telifone = $_POST['send_telf'];
$ordernowload = $_POST['send_oload'];
$summtotals = $_POST['send_sumdtotal'];
 */
//print "from PHP ".$disptched."--".$telifone."--".$ordernowload."--".$summtotals;

	/* check what form submitted  of volunteer */	
function processorder(){
	include "connection.php";
	
$disptched = $_POST['send_dispatchtype'];
$telifone = $_POST['send_telf'];
$ordernowload = $_POST['send_oload'];
$summtotals = $_POST['send_sumdtotal'];

		
	//if(isset($_POST['orderNowsubmit'])){
					
			$sql =<<<EOF
      INSERT INTO ORDERNOWTBL (DISPATCHTYPE,TELFONE,ORDERLOAD,ORDERTOTALS,ORDERDATE) VALUES ('$disptched','$telifone','$ordernowload','$summtotals',CURRENT_TIMESTAMP);

EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Order Now Details Created";
   }

						
	  include "closedb.php";  
	
//}
}
processorder();
   //header("Refresh:3; URL=../index.php");  
?>