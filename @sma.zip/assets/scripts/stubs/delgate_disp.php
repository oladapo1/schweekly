<?php
function pullDelegatestoview(){
 include "connection.php";
 $checksendrid = $_POST['send_membrid'];
 $suspend   = 1;
 $unsuspend = 0;
if(!empty($checksendrid)){
 $sqlgtalldelgte = "SELECT delgateid,suspendstatus FROM yesbadelegatestbl";
  //WHERE delgateid = $gtmembrtobedelgateid";
	$resultchk = $conn->query($sqlgtalldelgte);

	if ($resultchk->num_rows > 0) {
		while($rowdelgt = $resultchk->fetch_assoc()){
			$gteachdelegateid = $rowdelgt["delgateid"];
			$gtsuspndstatus = $rowdelgt["suspendstatus"];
			///////////////////////////////////////////////////////////////////
			//echo $gteachdelegateid."<br>";
			
					// Attempt select query execution
					$sql = "SELECT fname,lname,photo,memberid,emailofpharm FROM user_signupmgr WHERE memberid = $gteachdelegateid";
					if($result =  $conn->query($sql)){
						if($result->num_rows > 0){
							while($row = $result->fetch_assoc()){
								$gtdelgteid  =  $row['memberid'];
					 echo "<tr>";
					 //echo "<td>". $row['memberid'] ."</td>";
					 echo "<td>". "<img src='images/profileimages/$row[photo]' style='width:32px;'>" ."</td>";
					 echo "<td>". $row['emailofpharm'] ."</td>";
					 echo "<td>". $row['fname']."</td>";
					 echo "<td>".$row['lname'] ."</td>";
					 echo "<td><a href='#' class='btn btn-danger btn-sm' role='button' onclick='delDelgates($gtdelgteid)' title='Delete'>&times;</a></td>";
					 if($gtsuspndstatus == 1){
					 echo "<td><a href='#' class='btn btn-dark btn-sm' role='button' onclick='suspendDel($gtdelgteid,$unsuspend)' title='Unsuspend'>&plus;</a></td>";
					 }else if($gtsuspndstatus == 0){
						echo "<td><a href='#' class='btn btn-success btn-sm' role='button' onclick='suspendDel($gtdelgteid,$suspend)' title='Suspend'>&minus;</a></td>"; 
					 }else{
						 echo "Unknown status";
					 }
					 echo "</tr>";
						 }	
						} else{
							echo "<p>No matches found</p>";
						}
					} else{
						echo "ERROR: Could not able to execute $sql. " . $conn->error;
					}
		}
	}else{
		echo "no results";
	}  
}else{
	echo "Admin rights absent";
}	
// close connection
$conn->close();

}
pullDelegatestoview();