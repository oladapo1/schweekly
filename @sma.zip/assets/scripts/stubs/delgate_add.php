<?php
function addNewDelegate(){
	include "connection.php";
	$gtmembrtobedelgateid = $_POST["send_delgateID"];
	
	$sqlcheckifexistdelgte = "SELECT delgateid FROM yesbadelegatestbl WHERE delgateid = $gtmembrtobedelgateid";
	$result = $conn->query($sqlcheckifexistdelgte);

	if ($result->num_rows > 0) {

	echo "Already added";
	
	}else{
	$sql = "INSERT INTO yesbadelegatestbl (delgateid)VALUES ('$gtmembrtobedelgateid')";

		if ($conn->query($sql) === TRUE) {
			echo "Delegate added successfully";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
}
		$conn->close();
}

addNewDelegate();