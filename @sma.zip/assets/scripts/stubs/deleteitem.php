<?php
$itemID = $_GET["send_itemID"];
$shopID = $_GET["send_shopUId"];
//echo $itemID."--".$shopID;
include "connection.php";
 
$sql=<<<EOF
 DELETE from PRODUCTSTBL WHERE ID = $itemID AND SHOPUID = $shopID ;
EOF;

$ret = $db->exec($sql);
if(!$ret){

echo $db->lastErrorMsg();

} else {

echo $db->changes()," Record deleted successfully\n"; 

} 

//echo "<a href='../index.php'>Click to go back</a>";
include "closedb.php";


	