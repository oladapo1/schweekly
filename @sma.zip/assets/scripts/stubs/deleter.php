<script>
	/* var getPara;
	var sndPara;
	var rcvPara; */
function areuSure(getPara,shpid){
		//alert(getPara +"ok "+shpid);
		//sndPara = getPara;
		//var cnf = confirm('Are u sure you want to delete this ?');
				
		//cnf ? fYeas(getPara,shpid):fNot(); //using ternary or conditional operatos	
		
		fYeas(getPara,shpid);
	}
	
function fYeas(rcvPara,rcvshopid){
		
	//var pid = rcvPara;
	alert(rcvshopid+' Am deleting now ' +rcvPara);
		
var xmhttp = new XMLHttpRequest();
xmhttp.onreadystatechange = function() {
	
    if (this.readyState == 4 && this.status == 200) {
		
	 alert(xmhttp.responseText);
		       //document.getElementById('demo').innerHTML = x;		
    }

};
/* xmhttp.open('GET','delete.php?idp='+pid, true);
xmhttp.send(); */

	 /* Using POST */
		 
	xmhttp.open("POST","scripts/delete.php",true);
	xmhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmhttp.send("send_itemID="+rcvPara+"&send_shopUId="+rcvshopid);

}
	
	function fNot(){
		
		alert('Am not deleting oo');
		
	}
	
	</script>