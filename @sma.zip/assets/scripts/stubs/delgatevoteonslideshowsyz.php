<?php
function pullSlisdeArticlestoview(){
 include "connection.php";
 $checksendrid = $_POST['memberid']; // do a full check
if(!empty($checksendrid)){
  //////////////////////
	// Attempt select query execution
	$sql = "SELECT DISTINCT projtid,maintitle FROM yesbaslidearticle";
		if($result =  $conn->query($sql)){
				if($result->num_rows > 0){
					while($row = $result->fetch_assoc()){
					 $gtartcletitle  =  $row['maintitle'];
					 $gtartclid      =  $row['projtid'];
					 ///////////////////////
						$sqlartclchk = "SELECT slidershowid FROM yzonesldeshow WHERE slidershowid = $gtartclid AND delegateid = $checksendrid";
							if($result2 =  $conn->query($sqlartclchk)){
								if($result2->num_rows > 0){
						
								//echo"Already voted";
								continue;
							}
						}						
					 //////////////////////
					 echo "
					 <tr id='td$gtartclid'>
					<td></td>
					<td style='font-weight:600;'>$gtartcletitle</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;'>View</button>
					</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;' id='$gtartclid' onclick='hideremoveItemfromList(this.id);sendSlideArticlevotedfor(this.id);'>Add</button>
					</td>
				  </tr>
					 ";
					 }	
				} else{
					echo "<p>None found</p>";
				}
			} else{
				echo "ERROR: Could not able to execute $sql. " . $conn->error;
			}  
  
  
  /////////////////////
}else{
	echo "Admin rights absent";
}	
// close connection
$conn->close();

}
pullSlisdeArticlestoview();