<?php

$contactNames = $_POST['send_contcnames'];
$contactPhones = $_POST['send_telfone'];
$contactEmail = $_POST['send_email'];
$contactRequest = $_POST['contacttxtarea'];

//print $contactNames." - ".$contactRequest;

include "connection.php";

/* $quickaske = $_POST['quickAskload'];
$quickphone = $_POST['qaPhonenum']; */
						
	 $sql =<<<EOF
      INSERT INTO CONTACTTBL (VISTRSNAME,PHONE,EMAIL,VREQUEST,TIMESENT) VALUES ('$contactNames','$contactPhones','$contactEmail','$contactRequest',CURRENT_TIMESTAMP);

EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Contact Us details sent";
   }
   
   