<?php
function pullPodcaststoview(){
 include "connection.php";
 $checksendrid = $_POST['memberid']; // do a full check
if(!empty($checksendrid)){
  //////////////////////
	// Attempt select query execution
	$sql = "SELECT audionamed,podcreated,audioid FROM podcastmgr";
		if($result =  $conn->query($sql)){
				if($result->num_rows > 0){
					while($row = $result->fetch_assoc()){
					 $gtaudiotitle  =  $row['audionamed'];
					 $gtaudiocreatd  =  $row['podcreated'];
					 $gtaudioid      =  $row['audioid'];
					 ///////////////////////
						$sqlartclchk = "SELECT podcastid FROM yzonepodcasts WHERE podcastid = $gtaudioid AND delegateid = $checksendrid";
							if($result2 =  $conn->query($sqlartclchk)){
								if($result2->num_rows > 0){
						
								//echo"Already voted";
								continue;
							}
						}						
					 //////////////////////
					 echo "
					 <tr id='td$gtaudioid'>
					<td>$gtaudiocreatd</td>
					<td style='font-weight:600;'>$gtaudiotitle</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;'>Listen</button>
					</td>
					<td>
					<button type='button' class='btn btn-outline-primary btn-sm' style='font-size:0.7em;' id='$gtaudioid' onclick='hideremoveItemfromList(this.id);sendPodcastvotedfor(this.id);'>Add</button>
					</td>
				  </tr>
					 ";
					 }	
				} else{
					echo "<p>No matches found</p>";
				}
			} else{
				echo "ERROR: Could not able to execute $sql. " . $conn->error;
			}  
  
  
  /////////////////////
}else{
	echo "Admin rights absent";
}	
// close connection
$conn->close();

}
pullPodcaststoview();