<?php 
include "connection.php";

if(isset($_POST['updsubmit'])){
	$ptid = $_POST['upptid'];
	$pdt = $_POST['updproducts'];
	$prci = $_POST['updprice'];
	$pqty = $_POST['updqty'];
	$redirectshopuid = $_POST['shopuidinurl'];

	 $sql ="UPDATE PRODUCTSTBL set PRODUCTS = '$pdt',PRICE = '$prci',QTY = '$pqty' WHERE ID='$ptid'"; 
	
	$ret = $db->exec($sql); 
	if(!$ret){ 
	  echo $db->lastErrorMsg(); 
	  } else { 
	  echo $db->changes(),"Record updated successfully\n"; 
	  } 
}
 $db->close(); 
 header("Refresh:2; URL=eproducts.php?shopId=$redirectshopuid");
 ?>