<?php
//require_once('../dailyprogreporttodb.php');
require_once('dailyprogreportchanelr.php');
require_once('dprupdater.php');
require_once('dprinsertertodb.php');

class CollateTodayDailyProgressReport{
	//private $pupilrefnumbr;
	private $getday;
	private $dpr_attndance;
	private $dpr_tmprament;
	private $dpr_learning;
	private $dpr_naprest;
	private $dpr_toileting;
	private $dpr_hlthstatus;
	private $dpr_recreation;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_meals;
	//private $dpr_otherdate;
	private $dpr_schid;
	private $dpr_pplref;
	private $dpr_class;
	private $dpr_classarm;
	
	function __construct($dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$dpr_sch_id,$dpr_pplrefid,$dpr_curclass,$dpr_cur_arm){
		
		date_default_timezone_set("Africa/Lagos");
		//$getday = date("Y-m-d h:i:s",time());
		
		$getday = date("Y-m-d");
		//echo $dpr_otherdate."--".$getday;die();
		
		$this->getday         = $getday;		
		$this->dpr_attndance  = $dpr_attndance;
		$this->dpr_tmprament  = $dpr_temperament;
		$this->dpr_learning   = $dpr_learning;
		$this->dpr_naprest    = $dpr_naprest;
		$this->dpr_toileting  = $dpr_toileting;
		$this->dpr_hlthstatus = $dpr_hlthstatus;
		$this->dpr_recreation = $dpr_recreation;
		$this->dpr_appearance = $dpr_appearance;
		$this->dpr_hwork      = $dpr_hwork;
		$this->dpr_meals      = $dpr_meals;
		$this->dpr_schid      = $dpr_sch_id;
		$this->pupilrefnumbr  = $dpr_pplrefid;
		$this->dpr_class      = $dpr_curclass;
		$this->dpr_classarm   = $dpr_cur_arm;
		
		$this->checkIfIsdirtyposted();
		//new ChannelDataAppropraitely();
		/* new DailyProgressReporttodb($dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals); */
		
		//print $this->dpr_otherdate . $this->dpr_meals;
		//print $this->dpr_otherdate; //schuid
	}
	
	function checkIfIsdirtyposted(){
		include("../conect/connection.php");
		
		$query = "SELECT pupilrefnumbr,dateposted,isdirtyposteddpr FROM puipildailyprogresrport WHERE pupilrefnumbr ='{$this->pupilrefnumbr}' AND dateposted ='{$this->getday}'";
		$result = $conn->query($query);

		if ($result->num_rows > 0) {
			// output data of each row
			//while($row = $result->fetch_assoc()) {
			if($row = $result->fetch_assoc()) {
			
				$cifdirty = $row["isdirtyposteddpr"];
				$dateposted = $row["dateposted"];
				//echo $dateposted."--".$this->getday; die();
				//if($cifdirty==1){
				if($dateposted == $this->getday){
					//echo"oxop";
					//if dirty call updater() when date is today, it must be dirty at insertion
					new DailyProgressReportupdatertodb($this->pupilrefnumbr,$this->getday,$this->dpr_attndance,$this->dpr_tmprament,$this->dpr_learning,$this->dpr_naprest,$this->dpr_toileting,$this->dpr_hlthstatus,$this->dpr_recreation,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_meals,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
				}
				elseif($dateposted !== $this->getday){//may need to make this only an else block not an elseif
					new DailyProgressReporttodb($this->pupilrefnumbr,$this->getday,$this->dpr_attndance,$this->dpr_tmprament,$this->dpr_learning,$this->dpr_naprest,$this->dpr_toileting,$this->dpr_hlthstatus,$this->dpr_recreation,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_meals,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
				}
				else{
					echo"your report already posted for the day!";
				}
			}
		} 
		else {
			new DailyProgressReporttodb($this->pupilrefnumbr,$this->getday,$this->dpr_attndance,$this->dpr_tmprament,$this->dpr_learning,$this->dpr_naprest,$this->dpr_toileting,$this->dpr_hlthstatus,$this->dpr_recreation,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_meals,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
			//echo "0 results";
		}
		$conn->close();
	}
}


//print_r($_POST);


		$dpr1 = $_POST['send_dpr_attndance'];
		$dpr2 = $_POST['send_dpr_temperamnet'];
		$dpr3 = $_POST['send_dpr_learning'];
		$dpr4 = $_POST['send_dpr_naprest'];
		$dpr5 = $_POST['send_dpr_toileting'];
		$dpr6 = $_POST['send_dpr_hlthstatus'];
		$dpr7 = $_POST['send_dpr_recreation'];
		$dpr8 = $_POST['send_dpr_appearance'];
		$dpr9 = $_POST['send_dpr_hwork'];
		$dpr10 = $_POST['send_dpr_meals'];
		$dpr11 = $_POST['send_dpr_schuid'];
		$dpr12 = $_POST['send_dpr_pplref'];
		$dpr13 = $_POST['send_dpr_class'];
		$dpr14 = $_POST['send_dpr_clsarm'];
		
		$objDPRColatter = new CollateTodayDailyProgressReport($dpr1,$dpr2,$dpr3,$dpr4,$dpr5,$dpr6,$dpr7,$dpr8,$dpr9,$dpr10,$dpr11,$dpr12,$dpr13,$dpr14);