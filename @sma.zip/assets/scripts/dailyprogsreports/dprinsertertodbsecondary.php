<?php
class DailyProgressReporttodb{
	//wrap in a function or includes
	
	private $dpr_otherdate;
	
	function __construct($pupilrefnumbr,$dpr_otherdate,$dpr_attn,$dpr_ovac,$dpr_impul,$dpr_copr,$dpr_anx,$dpr_wtdr,$dpr_appearance,$dpr_hwork,$dpr_nonag,$dpr_aggrsv,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		date_default_timezone_set("Africa/Lagos");
		$getday = date("Y-m-d");
		
		$this->isdirtydprposting = 1;
		if($dpr_otherdate==""){
			$this->dpr_otherdate = $getday;
		}else{
			$this->dpr_otherdate = $dpr_otherdate;
			//print $this->dpr_otherdate." other date";
			}
			
		//call pushDailyProgtodb function
		$this->pushDailyProgtodb($pupilrefnumbr,$this->dpr_otherdate,$dpr_attn,$dpr_ovac,$dpr_impul,$dpr_copr,$dpr_anx,$dpr_wtdr,$dpr_appearance,$dpr_hwork,$dpr_nonag,$dpr_aggrsv,$this->isdirtydprposting,$dpr_schid,$dpr_curclas,$dpr_curarm);
		
	}
	
	function pushDailyProgtodb($pupilrefnumber,$dprother_date,$dpr_attn,$dpr_oactive,$dpr_impulse,$dpr_coopr,$dpr_anxios,$dpr_wtdraw,$dpr_appearance,$dpr_hwork,$dpr_nonaggr,$dpr_aggresve,$isdirtydprposting,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		include("../conect/connection.php");
		////////////////////////////////////////////
		date_default_timezone_set("Africa/Lagos");
		$actualdatetime = date("Y-m-d h:i:s",time());
		$query = "INSERT INTO dailyprogresrportsecsch (pupilrefnumbr,dateposted,attentiveness,overactivity,impulsiveness,cooperative,anxiety,withdrawal,appearance,homework,nonaggressive,aggressive,isdirtyposteddpr,schuid,curclass,curclassarm,datedtimed) VALUES ('$pupilrefnumber','$dprother_date','$dpr_attn','$dpr_oactive','$dpr_impulse','$dpr_coopr','$dpr_anxios','$dpr_wtdraw','$dpr_appearance','$dpr_hwork','$dpr_nonaggr','$dpr_aggresve','$isdirtydprposting','$dpr_schid','$dpr_curclas','$dpr_curarm','$actualdatetime')";
				
				if ($conn->query($query) === TRUE) {
					echo "details sent successfully";
					 //header('Refresh: 1; URL = ../../../#.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
	}
		/////////////////////////////////////////////
}