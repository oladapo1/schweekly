<?php
class DailyProgressReportupdatertodb{
	
	private $puprefnumbr;
	private $dpr_attndance;
	private $dpr_temperament;
	private $dpr_learning;
	private $dpr_naprest;
	private $dpr_toileting;
	private $dpr_hlthstatus;
	private $dpr_recreation;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_meals;
	private $dpr_otherdate;
	private $getdatex;
	private $dpr_schid;
	private $dpr_pplref;
	private $dpr_class;
	private $dpr_classarm;
	//private $isdirtydprposting;
	
	function __construct($pupilrefnumbr,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		
		//echo $dpr_otherdate;
		//rem to wrap in a function for reuse
		//$getday = date('Y-m-d');
		//$this->getdate = $getday;
		date_default_timezone_set("Africa/Lagos");
		//$getday = date("Y-m-d h:i:s",time());
		
		$getday = date("Y-m-d");
		$this->getdatex = $getday;
		
		$this->puprefnumbr     = $pupilrefnumbr;
		$this->dpr_attndance   = $dpr_attndance;
		$this->dpr_temperament = $dpr_temperament;
		$this->dpr_learning    = $dpr_learning;
		$this->dpr_naprest     = $dpr_naprest;
		$this->dpr_toileting   = $dpr_toileting;
		$this->dpr_hlthstatus  = $dpr_hlthstatus;
		$this->dpr_recreation  = $dpr_recreation;
		$this->dpr_appearance  = $dpr_appearance;
		$this->dpr_hwork       = $dpr_hwork;
		$this->dpr_meals       = $dpr_meals;
		$this->dpr_schid       = $dpr_schid;
		$this->dpr_class       = $dpr_curclas;
		$this->dpr_classarm    = $dpr_curarm;
		
		//$this->isdirtydprposting = 1;
		
		if($dpr_otherdate==""){
			$this->dpr_otherdate=$getday;
		}
		else{
			$this->dpr_otherdate=$dpr_otherdate;
			}
			
			$this->updateDailyprogressreport();
	}
	
	function updateDailyprogressreport(){
		
		include("../conect/connection.php");
		
	if($this->dpr_otherdate == $this->getdatex){
	$query = "UPDATE puipildailyprogresrport SET attendance='{$this->dpr_attndance}',temperament='{$this->dpr_temperament}',learning='{$this->dpr_learning}',naprest='{$this->dpr_naprest}',toileting='{$this->dpr_toileting}',healthstatus='{$this->dpr_hlthstatus}',recreation='{$this->dpr_recreation}',appearance='{$this->dpr_appearance}',homework='{$this->dpr_hwork}',meals='{$this->dpr_meals}',schuid='{$this->dpr_schid}',curclass='{$this->dpr_class}',curclassarm='{$this->dpr_classarm}' WHERE pupilrefnumbr = '$this->puprefnumbr' AND dateposted='$this->getdatex'";
	
				if ($conn->query($query) === TRUE) {
					
					echo "your details updated successfully";
				}
				
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
				}
	
			$conn->close();
	}else{
		//return to inserter funtion
		echo "oops! daily progress for today only";
	}

}
		/////////////////////////////////////////////
}