<?php
class DailyProgressReporttodb{
	/* contructor */
	/* function __contruct(){
		
		
	} */
	
	//puipildailyprogresrport
	
	function getAllSchoolProfilevalues(){
		include("../../common/connectiondb/connection.php");
		if(!empty($this->newschoolname) || !empty($this->countryname) || !empty($this->emailo) || !empty($this->pwdo) || !empty($this->telfo)){
				
		////////////////////////////////////////////
		//rem to solidify follow - open/close principle to optimize here
		$this->newUID = $this->createUID(); //generate unique ID for users
		$this->newverifystring  = $this->generateVerifyString();  //generate verifiable string for email verification
		$this->pwdo = password_hash($this->pwdo, PASSWORD_DEFAULT); //hash the password now
		
		
		$query = "INSERT INTO owambesignup (userschoolname,usercountryname,owambe_email,telf,userpwd,signeeUID,verifystring) VALUES ('$this->newschoolname','$this->countryname','$this->emailo','$this->telfo','$this->pwdo','$this->newUID','$this->newverifystring')";
		
				if ($conn->query($query) === TRUE) {
					$passtoVerifyEmail = new VerifyEmaile($this->newverifystring,$this->emailo);
					 //echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
			
			
}
}//class ends



/*-------------------------------*/
	function sendDetlsNow(){
		include("connection.php");
		if(!empty($this->newschoolname) || !empty($this->countryname) || !empty($this->emailo) || !empty($this->pwdo) || !empty($this->telfo)){
				
		////////////////////////////////////////////
		//rem to solidify follow - open/close principle to optimize here
		$this->newUID = $this->createUID(); //generate unique ID for users
		$this->newverifystring  = $this->generateVerifyString();  //generate verifiable string for email verification
		$this->pwdo = password_hash($this->pwdo, PASSWORD_DEFAULT); //hash the password now
		
		
		$query = "INSERT INTO owambesignup (userschoolname,usercountryname,owambe_email,telf,userpwd,signeeUID,verifystring) VALUES ('$this->newschoolname','$this->countryname','$this->emailo','$this->telfo','$this->pwdo','$this->newUID','$this->newverifystring')";
		
				if ($conn->query($query) === TRUE) {
					$passtoVerifyEmail = new VerifyEmaile($this->newverifystring,$this->emailo);
					 //echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
}
			/* ----------------------------- */   
?>