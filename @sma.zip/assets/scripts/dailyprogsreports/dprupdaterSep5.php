<?php
class DailyProgressReportupdatertodb{
	
	private $pupilrefnumbr;
	private $dpr_attndance;
	private $dpr_temperament;
	private $dpr_learning;
	private $dpr_naprest;
	private $dpr_toileting;
	private $dpr_hlthstatus;
	private $dpr_recreation;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_meals;
	private $dpr_otherdate;
	private $getdatex;
	//private $isdirtydprposting;
	
	function __construct($pupilrefnumbr,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$dpr_schid,$dpr_curclas,$dpr_curarm){
		//echo $dpr_otherdate;
		//rem to wrap in a function for reuse
		//$getday = date('Y-m-d');
		//$this->getdate = $getday;
		date_default_timezone_set("Africa/Lagos");
		$getday = date("Y-m-d h:i:s",time());
		$this->getdatex = $getday;
		//$this->isdirtydprposting = 1;
		if($dpr_otherdate==""){
			$this->dpr_otherdate=$getday;
		}
		else{
			$this->dpr_otherdate=$dpr_otherdate;
			}
			
			$this->updateDailyprogressreport($pupilrefnumber,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$dpr_schid,$dpr_curclas,$dpr_curarm);
	}
	
	function updateDailyprogressreport($pupilrefnumber,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$schuide,$clsnum,$classalias){
		//echo $this->getdate;
		
		include("../conect/connection.php");
		
	if($this->dpr_otherdate == $this->getdatex){
	$query = "UPDATE puipildailyprogresrport SET attendance='{$dpr_attndance}',temperament='{$dpr_temperament}',learning='{$dpr_learning}',naprest='{$dpr_naprest}',toileting='{$dpr_toileting}',healthstatus='{$dpr_hlthstatus}',recreation='{$dpr_recreation}',appearance='{$dpr_appearance}',homework='{$dpr_hwork}',meals='{$dpr_meals}',schuid='{$schuide}',curclass='{$clsnum}',curclassarm='{$classalias}' WHERE pupilrefnumbr = '$pupilrefnumber' AND dateposted='$this->getdatex'";
	
				if ($conn->query($query) === TRUE) {
					
					echo "your details updated successfully";
				}
				
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
				}
	
			$conn->close();
	}else{
		//return to inserter funtion
		echo "oops! daily progress for today only";
	}

}
		/////////////////////////////////////////////
}