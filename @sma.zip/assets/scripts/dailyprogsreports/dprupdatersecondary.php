<?php
class DailyProgressReportupdatertodb{
	
	//private $pupilrefnumbr;
	private $dpr_attn;
	private $dpr_oactv;
	private $dpr_impls;
	private $dpr_copr;
	private $dpr_anxi;
	private $dpr_wthd;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_nonaggr;
	private $dpr_aggresv;
	private $dpr_otherdate;
	private $getdatex;
	private $dpr_schid;
	private $dpr_pplref;
	private $dpr_class;
	private $dpr_classarm;
	
	
	function __construct($pupilrefnumbr,$dpr_otherdate,$dpr_attn,$dpr_oactv,$dpr_impuls,$dpr_coopr,$dpr_anxi,$dpr_withd,$dpr_appearance,$dpr_hwork,$dpr_nonaggr,$dpr_aggresv,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		$this->dpr_attn    = $dpr_attn;
		$this->dpr_oactv   = $dpr_oactv;
		$this->dpr_impls   = $dpr_impuls;
		$this->dpr_copr    = $dpr_coopr;
		$this->dpr_anxi    = $dpr_anxi;
		$this->dpr_wthd    = $dpr_withd;
		$this->dpr_appearance = $dpr_appearance;
		$this->dpr_hwork   = $dpr_hwork;
		$this->dpr_nonaggr = $dpr_nonaggr;
		$this->dpr_aggresv = $dpr_aggresv;
		$this->dpr_pplref  = $pupilrefnumbr;
		$this->dpr_schid   = $dpr_schid;
		$this->dpr_class   = $dpr_curclas;
		$this->dpr_classarm = $dpr_curarm;
		
		
		//echo $this->dpr_copr."--".$this->dpr_aggresv; die();
		//rem to wrap in a function for reuse
		//$getday = date('Y-m-d');
		//$this->getdate = $getday;
		date_default_timezone_set("Africa/Lagos");
		$getday = date('Y-m-d');//date("Y-m-d h:i:s",time());
		$this->getdatex = $getday;
		//$this->isdirtydprposting = 1;
		
		if($dpr_otherdate==""){
			$this->dpr_otherdate=$getday;
		}
		else{
			$this->dpr_otherdate=$dpr_otherdate;
			}
			
			$this->updateDailyprogressreport();
	}
	
	function updateDailyprogressreport(){
		
	include("../conect/connection.php");
	
		date_default_timezone_set("Africa/Lagos");
		$actualdatetime = date("Y-m-d h:i:s",time());
		
	if($this->dpr_otherdate == $this->getdatex){
	$query = "UPDATE dailyprogresrportsecsch SET attentiveness='{$this->dpr_attn}',overactivity='{$this->dpr_oactv}',impulsiveness='{$this->dpr_impls}',cooperative='{$this->dpr_copr}',anxiety='{$this->dpr_anxi}',withdrawal='{$this->dpr_wthd}',appearance='{$this->dpr_appearance}',homework='{$this->dpr_hwork}',nonaggressive='{$this->dpr_nonaggr}',aggressive='{$this->dpr_aggresv}',schuid='{$this->dpr_schid}',curclass='{$this->dpr_class}',curclassarm='{$this->dpr_classarm}',datedtimed='{$actualdatetime}' WHERE pupilrefnumbr = '{$this->dpr_pplref}' AND dateposted='$this->getdatex'";
	
				if ($conn->query($query) === TRUE) {
					
					echo "your details updated successfully";
				}
				
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
				}
	
			$conn->close();
	}else{
		//return to inserter function
		echo "oops! daily progress for today only";
	}

}
		/////////////////////////////////////////////
}