<?php

class ManageDailyProgrsRept{
	
	/* function __construct(){
		
	} */
	
	function pushDPReport(){
		//include("../../common/connectiondb/connection.php");
		include("../../common/connectiondb/connection.php");
		
		$sql = "UPDATE dailprogreportattendance SET lastname='Doe' WHERE id=2";
		
		$query = "INSERT INTO dailprogreportattendance (verifystring) VALUES ('$this->newschoolname','$this->countryname','$this->emailo','$this->telfo','$this->pwdo','$this->newUID','$this->newverifystring')";
		
				if ($conn->query($query) === TRUE) {
					$passtoVerifyEmail = new VerifyEmaile($this->newverifystring,$this->emailo);
					 //echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
	}
	
	
}


//dailprogreportattendance
$dprcategory;
$dprcategoryvalue;
$isitnow;
$previoslydated;

objDailyRportage = new ManageDailyProgrsRept();
