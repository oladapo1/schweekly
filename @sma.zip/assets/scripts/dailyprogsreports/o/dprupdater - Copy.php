<?php
class DailyProgressReportupdatertodb{
	
	private $pupilrefnumbr;
	private $dpr_attndance;
	private $dpr_temperament;
	private $dpr_learning;
	private $dpr_naprest;
	private $dpr_toileting;
	private $dpr_hlthstatus;
	private $dpr_recreation;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_meals;
	private $dpr_otherdate;
	//private $isdirtydprposting;
	
	function __construct($pupilrefnumber,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals){
		
		//rem to wrap in a function for reuse
		$getday = date('Y-m-d');
		$this->getdate = $getday;
		//$this->isdirtydprposting = 1;
		if($dpr_otherdate==""){
			$this->dpr_otherdate=$getday;
		}
		else{
			$this->dpr_otherdate=$dpr_otherdate;
			}
			
			$this->updateDailyprogressreport($pupilrefnumber,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals);
	}
	
	function updateDailyprogressreport($pupilrefnumber,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals){
		
		include("../../../../common/connectiondb/connection.php");
	if($dpr_otherdate== $this->getdate){// AND dateposted='$this->getdate'
	$query = "UPDATE puipildailyprogresrport SET attendance='{$dpr_attndance}',temperament='{$dpr_temperament}',learning='{$dpr_learning}',naprest='{$dpr_naprest}',toileting='{$dpr_toileting}',healthstatus='{$dpr_hlthstatus}',recreation='{$dpr_recreation}',appearance='{$dpr_appearance}',homework='{$dpr_hwork}',meals='{$dpr_meals}' WHERE pupilrefnumbr = '$pupilrefnumber'";
	
	
				if ($conn->query($query) === TRUE) {
					
					echo "your details updated successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
				}
	}else{
		echo "edits are only for this very day";
	}

		$conn->close();
		
		/////////////////////////////////////////////
	}
}