<?php
//require_once('dprlogicusdayselapsed.php');
class PullweekDatatoview{

	private $suid; 
	private $datexcpected;
	function __construct(){
	 //echo $this->getPupilUid();
		//$this->gtsendeachDate($datexcpected);
		//echo $this->suid."---".$this->datexcpected;		
	}
	
	function getPupilUid(){
		
		return $this->suid;
		//echo $this->suid;
	}
		
	function setPupilUid($suid){
		
		return $this->suid = $suid;
	}
	
	function getExpectedate(){
		
		return $this->datexcpected;
		//$this->gtsendeachDate($datexcpected);
	}
	
		function setExpectedate($datexcpected){
		
		return $this->datexcpected = $datexcpected;
		
	}
	
	function gtsendeachDate($gtdate){		
		
		$sentdatesarrlength = count($gtdate);
		for($i=0; $i<$sentdatesarrlength; $i++){
			
			//$this->retrvEssentialData($gtdate[$i]);
			
		}

	}
	function retrvEssentialData($adated){
		include("../../../common/connectiondb/connection.php");
		
		$query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$this->suid}' AND dateposted = '{$adated}'"; //rem limit to 5 most recent data
		$result = $conn->query($query);
			
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$jsoncodeup;
				echo "[";
				/* echo "<br>".$row["attendance"],$row["temperament"],$row["learning"],$row["naprest"],$row["toileting"],$row["healthstatus"],$row["recreation"],$row["appearance"],$row["homework"],$row["meals"]; */
				foreach($row  as $k=>$values){
					//$jsoncodeup = $k."=>".$values;
					$jsoncodeup =$values;
				echo json_encode ($jsoncodeup);
				}
				//$jsoncodeup = $row;
				//echo json_encode($jsoncodeup);
			}
			echo"]";
		} else {
			//echo "0 results";
		}
		$conn->close();
				
			}	
}

$gtpuid = $_POST['sendpuid'];
//echo $gtpuid;
$objWeekly = new PullweekDatatoview();
$objWeekly->setPupilUid($gtpuid);
echo $objWeekly->getPupilUid();
//echo $objWeekly->getExpectedate();