<?php
class PullweekDatatoview{
	//2019-12-18
	//2019-12-20
	//2019-12-11
	//2019-12-16
	private $suid; 
	function __construct($datexcpected){
		$this->suid = "GCS-0016";
		//echo"<br>";
		/* echo "in pullweekDatatoview";
		echo"<br>"; */
		/* list($a,$b,$c,$d) = $datexcpected;
		echo $a."/".$b."/".$c."/".$d; */
		//echo"=======<br>=======";
		$this->gtsendeachDate($datexcpected);
		
		//$this->retrvEssentialData($a);
		
		//$this->tretrvEssData();
	}
	
	function gtsendeachDate($gtdate){
		/* echo "in gtsendeachDate";
		echo"<br>"; 
		list($a,$b,$c,$d) = $gtdate; */
		//echo count($gtdate).">>";
		//echo $a."/".$b."/".$c."/".$d;
		
		$sentdatesarrlength = count($gtdate);
		for($i=0; $i<$sentdatesarrlength; $i++){
			
			$this->retrvEssentialData($gtdate[$i]);
		}
		
		//$this->retrvEssentialData($a);
	}
	function retrvEssentialData($adated){
		include("../../../common/connectiondb/connection.php");
		
		$query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$this->suid}' AND dateposted = '{$adated}'"; //rem limit to 5 most recent data
		$result = $conn->query($query);
			
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$jsoncodeup;
				echo "[";
				/* echo "<br>".$row["attendance"],$row["temperament"],$row["learning"],$row["naprest"],$row["toileting"],$row["healthstatus"],$row["recreation"],$row["appearance"],$row["homework"],$row["meals"]; */
				foreach($row  as $k=>$values){
					//$jsoncodeup = $k."=>".$values;
					$jsoncodeup =$values;
				echo json_encode ($jsoncodeup);
				}
				//$jsoncodeup = $row;
				//echo json_encode($jsoncodeup);
			}
			echo"]";
		} else {
			//echo "0 results";
		}
		$conn->close();
				
			}	
}