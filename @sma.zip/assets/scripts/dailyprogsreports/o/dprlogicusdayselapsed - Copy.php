<?php
require_once('dprpullweeklydata.php');
class DayslogicElapsed{
	
	private $presentdayt;
	private $getpresentdaytval;
	private $getpresentdayt;
	private $getweekstartdayval;
	private $thisweekcount = array("Monday","Tuesday","Wednesday","Thursday","Friday");
	private $thisweek = array("Monday"=>"0","Tuesday"=>"1","Wednesday"=>"2","Thursday"=>"3","Friday"=>"4");
	 
	 //test dates
	private $arrdate = array("2019-12-18","2019-12-20","2019-12-11","2019-12-16");
			
	function __construct(){
		$this->getweekstartdayval = $this->thisweek['Monday'];
		self::daysElapsed();
		$this->gtweekDates($this->arrdate);
	}
	
	function daysElapsed(){
		
		$this->getpresentdaytval = date("d");//= 19th
		$this->getpresentdayt = date("l");//= 
		
		//$arrlength = count($this->thisweek);
		//$arrlength = $this->getpresentdayt;
		
		$e = $this->getpresentdayt;
		
		switch($e){
			case 'Monday':
			//echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Monday']);
			break;
			case 'Tuesday':
			//echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Tuesday']);
			break;
			case 'Wednesday':
			//echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Wednesday']);
			break;
			case 'Thursday':
			//echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Thursday']);
			break;
			case 'Friday':
			//echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Friday']);
			break;
			default:
			//echo " not amongst";
		}
		
	/* 	for($x = 0; $x < $arrlength; $x++) {
			echo $x." ".$this->thisweek[$x];
			echo "<br>";
		}
			
 */
 
 // using associative array - Keys and Values
 foreach($this->thisweek as $x => $x_value) {
	/* echo "<br>";
    echo  "Value=" . $x_value," Key=" . $x;
    echo "<br>"; */
}
 
 
		//$this->presentdayt = date("Y-m-d::h.i.s.a");
		//echo"<br>================================<br>";
		$this->presentdayt = date("Y-m-d");
		
		//echo $this->presentdayt."-/".$this->getpresentdaytval."/--".$this->getpresentdayt;
		//echo $this->presentdayt."-".$this->getpresentdayt;
		
		//echo $this->thisweek[0]."---";
		
		
	}
	
	function getDiffelapsedday($gttoday){
		$difdayvalue = $gttoday - $this->getweekstartdayval;
		echo $difdayvalue." days has eloped! since "."<b>".$this->getpresentdayt."</b>";
		//return $difdayvalue;
		$gtdaynumbrdates = $this->getpresentdaytval - $difdayvalue;
		//$builddate = date("Y-m-".$gtdaynumbrdates);
		//$builddate = date("Y-m");
		//echo $builddate;
		echo "<br>";
		for($x = 0; $x <= $difdayvalue; $x++) {
			//echo "==========================\\\=====<br>";
			//echo $x." ".$this->thisweekcount[$x]."/ ".$builddate."-".($gtdaynumbrdates+$x);//ok
			$builddate = date("Y-m-".($gtdaynumbrdates+$x));//ok
			//echo $x." ".$this->thisweekcount[$x]."/ ".$builddate;
			//echo "<br>";
		}
	
		//echo "=============================///==<br>";
	}
	
	function gtweekDates($fdate){
		//echo "in gtweekdates";
		//echo"<br>";
		list($a,$b,$c,$d) = $fdate;
		//echo $a."/".$b."/".$c."/".$d;
		//echo"<br>";
		new PullweekDatatoview($fdate);
	}
}

$objCallFunction = new DayslogicElapsed();