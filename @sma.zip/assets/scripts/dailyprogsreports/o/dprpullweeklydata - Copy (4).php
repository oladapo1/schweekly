<?php
//require_once('dprlogicusdayselapsed.php');
class PullweekDatatoview{

	private $suid; 
	private $datexcpected;
	function __construct($suid,$datexcpected){
		$this->suid = $suid;
	 //echo $this->getPupilUid();
		$this->gtsendeachDate($datexcpected);
		//echo $suid."---".$datexcpected;		
	}
	

	function gtsendeachDate($gtdate){		
	
		//echo $gtdate[0];	
		$sentdatesarrlength = count($gtdate);
		for($i=0; $i<$sentdatesarrlength; $i++){
			//echo $gtdate[$i];	//ok
			$this->retrvEssentialData($gtdate[$i]);
			
		}

	}
	
	//GCS-0014---2019-12-23
	function retrvEssentialData($adated){
		include("../../../common/connectiondb/connection.php");

		$query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$this->suid}' AND dateposted = '{$adated}'";//rem the data returned is based on the days that are supplied - work out priovios days that are off this specific week 
		
		$jd = ",";//comma seperator
		$result = $conn->query($query);
			
		if ($result->num_rows > 0) {
			// output data of each row
$json = '[';		
		while($row = $result->fetch_assoc()){

		//echo $adated;
		
				//ok lets go with the winner, abi!
			
			$json .=  
			
			'"'.$row["attendance"].'"' 
			.$jd. 
			'"'.$row["temperament"].'"'
			.$jd. 
			'"'.$row["learning"].'"'
			.$jd. 
			'"'.$row["naprest"].'"'
			.$jd. 
			'"'.$row["toileting"].'"'
			.$jd. 
			'"'.$row["healthstatus"].'"'
			.$jd. 
			'"'.$row["recreation"].'"'
			.$jd. 
			'"'.$row["appearance"].'"'
			.$jd. 
			'"'.$row["homework"].'"'
			.$jd.
			'"'.$row["meals"].'"'
			.$jd;
			//.']';
			
			}
			
        $json = substr($json, 0, -1);
        $json .= ']';
		echo $json;
		
		} else {
			//echo "0 results";
		}
		$conn->close();
				
			}	
}

/* $gtpuid = $_POST['sendpuid'];
//echo $gtpuid;
$objWeekly = new PullweekDatatoview();
$objWeekly->setPupilUid($gtpuid);
echo $objWeekly->getPupilUid(); */
//echo $objWeekly->getExpectedate();