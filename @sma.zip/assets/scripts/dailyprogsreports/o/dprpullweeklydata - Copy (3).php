<?php
//require_once('dprlogicusdayselapsed.php');
class PullweekDatatoview{

	private $suid; 
	private $datexcpected;
	function __construct($suid,$datexcpected){
		$this->suid = $suid;
	 //echo $this->getPupilUid();
		$this->gtsendeachDate($datexcpected);
		//echo $suid."---".$datexcpected;		
	}
	

	function gtsendeachDate($gtdate){		
	
		//echo $gtdate[0];	
		$sentdatesarrlength = count($gtdate);
		for($i=0; $i<$sentdatesarrlength; $i++){
			//echo $gtdate[$i];	//ok
			$this->retrvEssentialData($gtdate[$i]);
			
		}

	}
	
	//GCS-0014---2019-12-23
	function retrvEssentialData($adated){
		include("../../../common/connectiondb/connection.php");
		
		/* $query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$this->suid}' AND dateposted = '{$adated}'"; *///rem limit to 5 most recent data

$json = '[';
        while ($row = $ret->fetchArray(SQLITE3_ASSOC))
		{
            $json .= '{"ID":"' . $row["ID"] . '","PRODUCTS":"' . $row["PRODUCTS"]. '","PRICE":"' . $row["PRICE"] .'","QTY":' . $row["QTY"].'},';
        }
        // Remove the trailing comma before we add the last bracket. 
        $json = substr($json, 0, -1); // Substring -1 character from the end of the json variable, this will be the trailing comma. 
        $json .= ']';
		
		echo $json;
		
		$query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$this->suid}' AND dateposted = '{$adated}'";//rem the data returned is based on the days that are supplied - work out priovios days that are off this specific week 
		
		$result = $conn->query($query);
			
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$jsoncodeup;
				echo "[";
				/* echo "<br>".$row["attendance"],$row["temperament"],$row["learning"],$row["naprest"],$row["toileting"],$row["healthstatus"],$row["recreation"],$row["appearance"],$row["homework"],$row["meals"]; */
				foreach($row  as $k=>$values){
					//$jsoncodeup = $k."=>".$values;
					$jsoncodeup =$values;
				echo json_encode ($jsoncodeup);
				}
				//$jsoncodeup = $row;
				//echo json_encode($jsoncodeup);
			}
			echo"]";
		} else {
			//echo "0 results";
		}
		$conn->close();
				
			}	
}

/* $gtpuid = $_POST['sendpuid'];
//echo $gtpuid;
$objWeekly = new PullweekDatatoview();
$objWeekly->setPupilUid($gtpuid);
echo $objWeekly->getPupilUid(); */
//echo $objWeekly->getExpectedate();