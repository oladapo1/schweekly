<?php
class DayslogicElapsed{
	
	private $presentdayt;
	private $getpresentdaytval;
	private $getpresentdayt;
	private $getweekstartdayval;
	private $thisweekcount = array("Monday","Tuesday","Wednesday","Thursday","Friday");
	private $thisweek = array("Monday"=>"0","Tuesday"=>"1","Wednesday"=>"2","Thursday"=>"3","Friday"=>"4");
	
	function __construct(){
		$this->getweekstartdayval = $this->thisweek['Monday'];
		//echo $this->getweeksartday;
		self::daysElapsed();
	}
	
	function daysElapsed(){
		
		$this->getpresentdaytval = date("d");//= 19th
		$this->getpresentdayt = date("l");//= 
		
		//$arrlength = count($this->thisweek);
		//$arrlength = $this->getpresentdayt;
		
		$e = $this->getpresentdayt;
		
		switch($e){
			case 'Monday':
			echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Monday']);
			break;
			case 'Tuesday':
			echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Tuesday']);
			break;
			case 'Wednesday':
			echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Wednesday']);
			break;
			case 'Thursday':
			echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Thursday']);
			break;
			case 'Friday':
			echo "Today is ".$this->getpresentdayt."-".$this->getpresentdaytval."<br>";
			$this->getDiffelapsedday($this->thisweek['Friday']);
			break;
			default:
			echo " not amongst";
		}
		
	/* 	for($x = 0; $x < $arrlength; $x++) {
			echo $x." ".$this->thisweek[$x];
			echo "<br>";
		}
			
 */
 
 foreach($this->thisweek as $x => $x_value) {
	echo "<br>";
    echo  "Value=" . $x_value," Key=" . $x;
    echo "<br>";
}
 
 
		//$this->presentdayt = date("Y-m-d::h.i.s.a");
		echo"<br>================================<br>";
		$this->presentdayt = date("Y-m-d");
		
		//echo $this->presentdayt."-/".$this->getpresentdaytval."/--".$this->getpresentdayt;
		//echo $this->presentdayt."-".$this->getpresentdayt;
		
		//echo $this->thisweek[0]."---";
		
		
	}
	
	function getDiffelapsedday($gd){
		
		$difdayvalue = $gd - $this->getweekstartdayval;
		echo $difdayvalue." days has eloped! since "."<b>".$this->getpresentdayt."</b>";
		//return $difdayvalue;
		$gtdaynumbrdates = $this->getpresentdaytval - $difdayvalue;
		//$builddate = date("Y-m-".$gtdaynumbrdates);
		//$builddate = date("Y-m");
		//echo $builddate;
		echo "<br>";
		for($x = 0; $x <= $difdayvalue; $x++) {
			echo "===============================<br>";
			//echo $x." ".$this->thisweekcount[$x]."/ ".$builddate."-".($gtdaynumbrdates+$x);//ok
			$builddate = date("Y-m-".($gtdaynumbrdates+$x));//ok
			echo $x." ".$this->thisweekcount[$x]."/ ".$builddate;
			echo "<br>";
			//echo arsort($this->thisweekcount);
		}
		echo "===============================<br>";
	}
}

$objCallFunction = new DayslogicElapsed();
