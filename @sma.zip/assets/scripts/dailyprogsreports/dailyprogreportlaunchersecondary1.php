<?php
//require_once('../dailyprogreporttodb.php');
//require_once('dailyprogreportchanelr.php');
require_once('dprupdatersecondary.php');
require_once('dprinsertertodbsecondary.php');

class CollateTodayDailyProgressReport{
	private $pupilrefnumbr;
	private $getday;
	private $dpr_attn;
	private $dpr_ovactive;
	private $dpr_impuls;
	private $dpr_coopr;
	private $dpr_anxi;
	private $dpr_withd;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_nonaggr;
	private $dpr_aggresv;
	private $dpr_schid;
	private $dpr_pplref;
	private $dpr_class;
	private $dpr_classarm;
	
	function __construct($dpr_attntion,$dpr_oac,$dpr_impu,$dpr_cpr,$dpr_anx,$dpr_wtd,$dpr_apr,$dpr_hwk,$dpr_nag,$dpr_agg,$dpr_sch_id,$dpr_pplrefid,$dpr_curclass,$dpr_cur_arm){
		
		date_default_timezone_set("Africa/Lagos");
		$getday = date("Y-m-d h:i:s",time());
		$this->getday         = $getday;		
		$this->dpr_attn       = $dpr_attntion;
		$this->dpr_ovactive   = $dpr_oac;
		$this->dpr_impuls     = $dpr_impu;
		$this->dpr_coopr      = $dpr_cpr;
		$this->dpr_anxi       = $dpr_anx;
		$this->dpr_withd      = $dpr_wtd;
		$this->dpr_appearance = $dpr_apr;
		$this->dpr_hwork      = $dpr_hwk;
		$this->dpr_nonaggr    = $dpr_nag;
		$this->dpr_aggresv    = $dpr_agg;
		$this->dpr_schid      = $dpr_sch_id;
		$this->pupilrefnumbr  = $dpr_pplrefid;
		$this->dpr_class      = $dpr_curclass;
		$this->dpr_classarm   = $dpr_cur_arm;
		
		$this->checkIfIsdirtyposted();
		
	}
	
	function checkIfIsdirtyposted(){
		include("../conect/connection.php");
		
		$query = "SELECT pupilrefnumbr,dateposted,isdirtyposteddpr FROM dailyprogresrportsecsch WHERE pupilrefnumbr ='{$this->pupilrefnumbr}'";// AND dateposted='{$this->getday}'";
		$result = $conn->query($query);

		if ($result->num_rows > 0) {
			// output data of each row
			//while($row = $result->fetch_assoc()) {
			if($row = $result->fetch_assoc()) {
			
				$cifdirty = $row["isdirtyposteddpr"];
				$dateposted = $row["dateposted"];
				
				//if($cifdirty==1){
				if($dateposted==$this->getday){
					//if dirty call updater() when date is today, it must be dirty at insertion
					new DailyProgressReportupdatertodb($this->pupilrefnumbr,$this->getday,$this->dpr_attn,$this->dpr_ovactive,$this->dpr_impuls,$this->dpr_coopr,$this->dpr_anxi,$this->dpr_withd,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_nonaggr,$this->dpr_aggresv,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
				}
				elseif($dateposted != $this->getday){//may need to make this only an else block not an elseif
					new DailyProgressReporttodb($this->pupilrefnumbr,$this->getday,$this->dpr_attn,$this->dpr_ovactive,$this->dpr_impuls,$this->dpr_coopr,$this->dpr_anxi,$this->dpr_withd,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_nonaggr,$this->dpr_aggresv,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
				}
				else{
					echo"your report already posted for the day!";
				}
			}
		} 
		else {
			new DailyProgressReporttodb($this->pupilrefnumbr,$this->getday,$this->dpr_attn,$this->dpr_ovactive,$this->dpr_impuls,$this->dpr_coopr,$this->dpr_anxi,$this->dpr_withd,$this->dpr_appearance,$this->dpr_hwork,$this->dpr_nonaggr,$this->dpr_aggresv,$this->dpr_schid,$this->dpr_class,$this->dpr_classarm);
			//echo "0 results";
		}
		$conn->close();
	}
}


//print_r($_POST);


		$dpr1 = $_POST['send_dpr_attntion'];
		$dpr2 = $_POST['send_dpr_ovractive'];
		$dpr3 = $_POST['send_dpr_impulsive'];
		$dpr4 = $_POST['send_dpr_cooprate'];
		$dpr5 = $_POST['send_dpr_anxiety'];
		$dpr6 = $_POST['send_dpr_wthdrawal'];
		$dpr7 = $_POST['send_dpr_appearance'];
		$dpr8 = $_POST['send_dpr_hwork'];
		$dpr9 = $_POST['send_dpr_nonaggrs'];
		$dpr10 = $_POST['send_dpr_aggressive'];
		$dpr11 = $_POST['send_dpr_schuid'];
		$dpr12 = $_POST['send_dpr_pplref'];
		$dpr13 = $_POST['send_dpr_class'];
		$dpr14 = $_POST['send_dpr_clsarm'];
		
		$objDPRColatter = new CollateTodayDailyProgressReport($dpr1,$dpr2,$dpr3,$dpr4,$dpr5,$dpr6,$dpr7,$dpr8,$dpr9,$dpr10,$dpr11,$dpr12,$dpr13,$dpr14);