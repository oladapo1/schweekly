<?php
//require_once('dprupdater.php');
//require_once('dprinsertertodb.php');
class ChannelDataAppropraitely{
	
	private $pupilrefnumbr;
	private $getday;
	
	
	function __construct(){
		$this->pupilrefnumbr = "GCS-0014";
		$this->getday = date('Y-m-d');
		$this->checkIfIsdirtyposted();
		
	}
	
	function checkIfIsdirtyposted(){
		include("../../../../common/connectiondb/connection.php");
		
		$query = "SELECT pupilrefnumbr,dateposted,isdirtyposteddpr FROM puipildailyprogresrport WHERE pupilrefnumbr ='{$this->pupilrefnumbr}' AND dateposted='{$this->getday}'";
		$result = $conn->query($query);

		if ($result->num_rows > 0) {
			// output data of each row
			//while($row = $result->fetch_assoc()) {
			if($row = $result->fetch_assoc()) {
			
				$cifdirty = $row["isdirtyposteddpr"];
				
				if($cifdirty==1){
					//echo"oxop";
					//if dirty call updater() when date is today, it must be dirty at insertion
					//new DailyProgressReportupdatertodb();
				}else{
					//echo"zozo";
					//run insertion any new ops
					//new DailyProgressReporttodb();
				}
			}
		} 
		else {
			
			echo "0 results";
		}
		$conn->close();
	}
	
}