<?php
require_once("../common/randcodegennr.php");

class Attendancetoday{

	private $shcuid;
	private $pplpresent;
	private $ppplabsnt;
	private $stfrefuid;
	private $classnow;
	private $classalrm;
	
	function __construct($gt_schuid,$gt_presnts,$gt_absnts,$gt_stafref,$gt_classref,$gt_classarm){
	
	$this->shcuid     = $gt_schuid;
	$this->pplpresent = $gt_presnts;
	$this->ppplabsnt  = $gt_absnts;
	$this->stfrefuid  = $gt_stafref;
	$this->classnow   = $gt_classref;
	$this->classalrm  = $gt_classarm;
	
	$this->sendDetlsNow();
	
	}
	
	function sendDetlsNow(){
		$signupstatus = 1;
		include("../conect/connection.php");
		
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		
		
		$entryUID = new Randomuiidgen; //generate unique ID for schuid
		$this->entryUID = $entryUID->createUID();
			//do a full insert query alphamembers
$query = "INSERT INTO scwkattendance
 (schuid,staffrefnumbr,pupilclass,pupilarm,presentees,absentees,entrydate,entryid) VALUES ('$this->shcuid','$this->stfrefuid','$this->classnow','$this->classalrm','$this->pplpresent','$this->ppplabsnt','$mklogdindatetime','$this->entryUID')";
				if($conn->query($query) === TRUE) {
						
						echo "your details sent successfully";
						

				}else {
				//echo "Error: " . $query . "<br>" . $conn->error;
				echo "Error-support-required";
				}
		
			//close connection
				$conn->close();		
					
	}

}

//print_r($_POST);

	// check for a token or an acountable registration sender at the login end or from the Owners end

	$gtschuid   = $_POST['send_schuid'];
	$gtpresnts  = $_POST['pupil_prsnt'];
	$gtabsnts   = $_POST['pupil_absnt'];
	$gtstafref  = $_POST['staff_refid'];
	$gtclassref = $_POST['class_refid'];
	$gtclassarm = $_POST['class_arm'];

	$gtrqdVars = new Attendancetoday($gtschuid,$gtpresnts,$gtabsnts,$gtstafref,$gtclassref,$gtclassarm);