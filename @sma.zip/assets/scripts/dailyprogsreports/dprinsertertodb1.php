<?php
class DailyProgressReporttodb{
	//wrap in a function or includes
	/* private $pupilrefnumbr;
	private $dpr_attndance;
	private $dpr_temperament;
	private $dpr_learning;
	private $dpr_naprest;
	private $dpr_toileting;
	private $dpr_hlthstatus;
	private $dpr_recreation;
	private $dpr_appearance;
	private $dpr_hwork;
	private $dpr_meals;
	
	private $isdirtydprposting; */
	private $dpr_otherdate;
	
	function __construct($pupilrefnumbr,$dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		//print"inside inserter";
		//$this->pupilrefnumbr = "GCS-0014";
		//wrap in a function
		//$getday = date('Y-m-d');
		date_default_timezone_set("Africa/Lagos");
		$getday = date("Y-m-d h:i:s",time());
		
		$this->isdirtydprposting = 1;
		if($dpr_otherdate==""){
			$this->dpr_otherdate = $getday;
			//print $this->dpr_otherdate." todays date";
		}else{
			$this->dpr_otherdate = $dpr_otherdate;
			//print $this->dpr_otherdate." other date";
			}
		//call pushDailyProgtodb function
		$this->pushDailyProgtodb($pupilrefnumbr,$this->dpr_otherdate,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$this->isdirtydprposting,$dpr_schid,$dpr_curclas,$dpr_curarm);
		
	}
	//1111521283641455356
	function pushDailyProgtodb($pupilrefnumber,$dprother_date,$dpr_attndance,$dpr_temperament,$dpr_learning,$dpr_naprest,$dpr_toileting,$dpr_hlthstatus,$dpr_recreation,$dpr_appearance,$dpr_hwork,$dpr_meals,$isdirtydprposting,$dpr_schid,$dpr_curclas,$dpr_curarm){
		
		include("../conect/connection.php");
		////////////////////////////////////////////
		
		$query = "INSERT INTO puipildailyprogresrport (pupilrefnumbr,dateposted,attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals,isdirtyposteddpr,schuid,curclass,curclassarm) VALUES ('$pupilrefnumber','$dprother_date','$dpr_attndance','$dpr_temperament','$dpr_learning','$dpr_naprest','$dpr_toileting','$dpr_hlthstatus','$dpr_recreation','$dpr_appearance','$dpr_hwork','$dpr_meals','$isdirtydprposting','$dpr_schid','$dpr_curclas','$dpr_curarm')";
		
		
				if ($conn->query($query) === TRUE) {
					echo "details sent successfully";
					 //header('Refresh: 1; URL = ../../../#.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
	}
		/////////////////////////////////////////////
}