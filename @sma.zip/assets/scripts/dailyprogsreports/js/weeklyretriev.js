function deaSher(){
	//alert("okk");
var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    //var myObj = JSON.parse(this.responseText);
	alert(xhttp.responseText);
    //document.getElementById("getdatedvalues").innerHTML = myObj.name;
  }
};

xhttp.open("POST", "rotescripts/swallowr/dailyprogsreports/scripts/dprlogicusdayselapsed.php", true);
//xhttp.open("POST", "../scripts/dprpullweeklydata.php", true);
/* xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded"); */
xhttp.send();
}