function getQueues(e,id){
	itemsfromdbtoStore(e,id);
}

var thxthr;
function itemsfromdbtoStore(e,puid){

       if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
				//alert(this.responseText);
				
				//console.log(this.responseText);  // workout undefined responses wlse redefine how the response text is retrieved
				
		
			 var gtdprresponse = JSON.parse(this.responseText);

		//			dateposted,attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals
		
		var i,j,k,l,m,n,day1,day2,day3,day3,day4,day5;
		var totaldays =["d1","d2","d3","d4","d5"];
		//var dprdata = ["attendance","temperament","learning","naprest","toileting","healthstatus","recreation","appearance","homework","meals"];
		
	
	
	day1 = [gtdprresponse[0].attendance,gtdprresponse[0].temperament,gtdprresponse[0].learning,gtdprresponse[0].naprest,gtdprresponse[0].toileting,gtdprresponse[0].healthstatus,gtdprresponse[0].recreation,gtdprresponse[0].appearance,gtdprresponse[0].homework,gtdprresponse[0].meals];
	
	day2 = [gtdprresponse[1].attendance,gtdprresponse[1].temperament,gtdprresponse[1].learning,gtdprresponse[1].naprest,gtdprresponse[1].toileting,gtdprresponse[1].healthstatus,gtdprresponse[1].recreation,gtdprresponse[1].appearance,gtdprresponse[1].homework,gtdprresponse[1].meals];
	
	
	day3 = [gtdprresponse[2].attendance,gtdprresponse[2].temperament,gtdprresponse[2].learning,gtdprresponse[2].naprest,gtdprresponse[2].toileting,gtdprresponse[2].healthstatus,gtdprresponse[2].recreation,gtdprresponse[2].appearance,gtdprresponse[2].homework,gtdprresponse[2].meals];
	
	day4 = [gtdprresponse[3].attendance,gtdprresponse[3].temperament,gtdprresponse[3].learning,gtdprresponse[3].naprest,gtdprresponse[3].toileting,gtdprresponse[3].healthstatus,gtdprresponse[3].recreation,gtdprresponse[3].appearance,gtdprresponse[3].homework,gtdprresponse[3].meals];
	
	day5 = [gtdprresponse[4].attendance,gtdprresponse[4].temperament,gtdprresponse[4].learning,gtdprresponse[4].naprest,gtdprresponse[4].toileting,gtdprresponse[4].healthstatus,gtdprresponse[4].recreation,gtdprresponse[4].appearance,gtdprresponse[4].homework,gtdprresponse[4].meals];
	
	
	/*day1 = JSON.stringify(day1);
	day2 = JSON.stringify(day2);
	day3 = JSON.stringify(day3);
	day4 = JSON.stringify(day4);
	day5 = JSON.stringify(day5);*/

	
	
	pfinck3(day1,day2,day3,day4,day5);
		
			/* function removeLastComma(strng){
				var n = strng.lastIndexOf(",");
				var a = strng.substring(0,n)
				return a;
			} */
						
			}
        };

		//xmlhttp.open("POST","rotescripts/swallowr/dailyprogsreports/scripts/dprlogicusdayselapsed.php",true);
		xmlhttp.open("POST","rotescripts/swallowr/dailyprogsreports/scripts/dprpullweeklydata.php",true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded"); 
        xmlhttp.send("sendpuid="+puid);     
}

function pfinck3(day1,day2,day3,day4,day5){
	var myObj, i, j, x = "";
	
	//console.log("day1-"+day1+"-day2-"+day2+"-day3-"+day3+"-day4-"+day4+"-day5-"+day5);
	/*
	var day4 = ["2","12","15","23","26","33","42","48","53","58"];
	var day5 = ["2","12","15","23","26","33","42","48","53","58"];*/
	
	//var day5 = ["2","12","15","23","26","33","42","48","53","58"];
	//var day5 = [];//var day5 = null;

 // work out th coding for situation when that date is not available: an empty returned array does not affect the remaing days array ass tested above in the day5 empty array
 
 /////////////////////////
 dailyproreportObj = {
    //"name":"#SURN",
    //"otherdate":#,
    "dpreports": [
          {"day":"mondays", "data":day1},
         {"day":"tuesdays", "data":day2},
       {"day":"wednesdays", "data":day3},
	    {"day":"thursdays", "data":day4},
          {"day":"fridays", "data":day5}
    ]
 }
 
 
 /////////////////////////
 
 
for (i in dailyproreportObj.dpreports) {

	 var dday = dailyproreportObj.dpreports[i].day;
	 var divindicator = document.getElementsByClassName(dday);

    for (j in dailyproreportObj.dpreports[i].data) {
       
		var daydprvals = dailyproreportObj.dpreports[i].data[j];
		
		divindicator[daydprvals].style.border="3px solid #fff";
    }	
}

}

function dprthursdays(){

	var thr = document.querySelectorAll('.thursdays');
	//var i;
	for(i=0; i<thxthr.length;++i){
		
		var fig = thxthr[i];
		
		thr[fig].style.border="3px solid #fff";	
	}
}