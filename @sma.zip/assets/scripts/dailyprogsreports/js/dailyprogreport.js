var gtBtn = document.getElementById('submitpupildpr');
gtBtn.onclick = puschDailyProgReportValues;

function puschDailyProgReportValues(){

var gtDPR1 = document.getElementById('rpotattendance').value;
var gtDPR2 = document.getElementById('rpottemperamnet').value;
var gtDPR3 = document.getElementById('rpotlearning').value;
var gtDPR4 = document.getElementById('rpotnaprest').value;
var gtDPR5 = document.getElementById('rpottoileting').value;
var gtDPR6 = document.getElementById('rpothlthstatus').value;
var gtDPR7 = document.getElementById('rpotrecreation').value;
var gtDPR8 = document.getElementById('rpotappearance').value;
var gtDPR9 = document.getElementById('rpothwork').value;
var gtDPR10 = document.getElementById('rpotmeals').value;
//var gtradiotherdate = document.getElementById('otherdate').value;
	
let cntr = sessionStorage.getItem("Countr");
sweekcounter = Number(cntr);
let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
//console.log(typeof(sweekcounter));
let pupilschuid  = classarry[1][sweekcounter].schuid;
let pupilref     = classarry[1][sweekcounter].pupilrefnumbr;
let pupilclas    = classarry[1][sweekcounter].presentclass;
let pupilclasarm = classarry[1][sweekcounter].classalias;

//console.log(classarry[1][sweekcounter].pupilssurname+"-"+ pupilref +"-"+pupilclas);	
//return false;
	
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200){  

			alert(xhttp.responseText);
			console.log(xhttp.responseText);
					
  	}
	};
	/* Using POST */ 
xhttp.open("POST","../assets/scripts/dailyprogsreports/dailyprogreportlauncher.php",true);
		xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xhttp.send(
		"send_dpr_attndance="+gtDPR1+
		"&send_dpr_temperamnet="+gtDPR2+
		"&send_dpr_learning="+gtDPR3+
		"&send_dpr_naprest="+gtDPR4+
		"&send_dpr_toileting="+gtDPR5+
		"&send_dpr_hlthstatus="+gtDPR6+
		"&send_dpr_recreation="+gtDPR7+
		"&send_dpr_appearance="+gtDPR8+
		"&send_dpr_hwork="+gtDPR9+
		"&send_dpr_meals="+gtDPR10+
		"&send_dpr_schuid="+pupilschuid+
		"&send_dpr_pplref="+pupilref+
		"&send_dpr_class="+pupilclas+
		"&send_dpr_clsarm="+pupilclasarm
		);
}


var gtsecBtn = document.getElementById('submitsecschdpr');
gtsecBtn.onclick = secDailyProgReportValues;	
	
function secDailyProgReportValues(){

let gtDPR1 = document.getElementById('rpotattentiveness').value;
let gtDPR2 = document.getElementById('rpotoveractivity').value;
let gtDPR3 = document.getElementById('rpotimpulsiveness').value;
let gtDPR4 = document.getElementById('rpotcooperative').value;
let gtDPR5 = document.getElementById('rpotanxiety').value;
let gtDPR6 = document.getElementById('rpotwithdrawal').value;
let gtDPR7 = document.getElementById('rpotappearancesec').value;
let gtDPR8 = document.getElementById('rpothworksec').value;
let gtDPR9 = document.getElementById('rpotnonaggressive').value;
let gtDPR10 = document.getElementById('rpotaggressive').value;
	
let cntr = sessionStorage.getItem("Countr");
sweekcounter = Number(cntr);
let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
//console.log(typeof(sweekcounter));
let pupilschuid  = classarry[1][sweekcounter].schuid;
let pupilref     = classarry[1][sweekcounter].pupilrefnumbr;
let pupilclas    = classarry[1][sweekcounter].presentclass;
let pupilclasarm = classarry[1][sweekcounter].classalias;

//console.log(classarry[1][sweekcounter].pupilssurname+"-"+ pupilref +"-"+pupilclas);	
//return false;
	
	
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200){  

			alert(xhttp.responseText);
			console.log(xhttp.responseText);
					
  	}
	};
	/* Using POST */ 
xhttp.open("POST","../assets/scripts/dailyprogsreports/dailyprogreportlaunchersecondary.php",true);
		xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xhttp.send(
		"send_dpr_attntion="+gtDPR1+
		"&send_dpr_ovractive="+gtDPR2+
		"&send_dpr_impulsive="+gtDPR3+
		"&send_dpr_cooprate="+gtDPR4+
		"&send_dpr_anxiety="+gtDPR5+
		"&send_dpr_wthdrawal="+gtDPR6+
		"&send_dpr_appearance="+gtDPR7+
		"&send_dpr_hwork="+gtDPR8+
		"&send_dpr_nonaggrs="+gtDPR9+
		"&send_dpr_aggressive="+gtDPR10+
		"&send_dpr_schuid="+pupilschuid+
		"&send_dpr_pplref="+pupilref+
		"&send_dpr_class="+pupilclas+
		"&send_dpr_clsarm="+pupilclasarm
		);
	}	