<?php
//require_once('dprlogicusdayselapsed.php');
class PullweekDatatoview{

	private $suid; 
	//private $datexcpected;
	//function __construct($suid,$datexcpected){
		function __construct($suid){
		//$this->suid = $suid;
	 //echo $this->getPupilUid();
		//$this->gtsendeachDate($datexcpected);
		$this->gtsendeachDate($suid);
		//echo $suid."---".$datexcpected;		
	}
	

	function gtsendeachDate($gtsuid){		
	//echo count($gtdate);
		//echo $gtdate[0];	
		//$sentdatesarrlength = count($gtdate);
		/* for($i=0; $i<$sentdatesarrlength; $i++){
			//echo $gtdate[$i];	//ok
			$this->retrvEssentialData($gtdate[$i]);
		} */
		$this->retrvEssentialData($gtsuid);
		
	}
	
	//GCS-0014---2019-12-23
	
	function retrvEssentialData($puid){
		
		include("../../../common/connectiondb/connection.php");

		/* $query = "SELECT attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$puid}'"; */
		
		/* $query = "SELECT * FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$puid}' ORDER BY dateposted DESC LIMIT 3"; */
		
		//$query = "SELECT * FROM  puipildailyprogresrport";
		
		$query = "SELECT dateposted,attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$puid}' ORDER BY dateposted DESC LIMIT 5";
		
		/* $query = "SELECT dateposted,attendance,temperament,learning,naprest,toileting,healthstatus,recreation,appearance,homework,meals FROM  puipildailyprogresrport WHERE pupilrefnumbr = '{$puid}' ORDER BY id DESC LIMIT 3"; */
	
	$jd = ",";//comma seperator
	
	//$gtresults = array();
		$result = $conn->query($query);
		
		if ($result->num_rows > 0) {
	$json = '[';
		while($row = $result->fetch_assoc()){
						
		$json .= json_encode($row,JSON_PRETTY_PRINT).$jd;
			
		 }
		$json = substr($json, 0, -1);
        $json .= ']';
		echo $json;
		} 
		else {
			//echo "0 results";
		}
		$conn->close();
				
			}	
}


$gtpuid = $_POST['sendpuid'];
$objKipup = new PullweekDatatoview($gtpuid);