<?php
class Randomuiidgen{

function createUID(){
		$codeddigito = mt_rand(100000000,999999999);
		//$codeddigitz = mt_rand(128,512);
		return $codeddigito;
	}	
}

/* 
<?php
$result = uniqid();
echo $result;
?>

<?php
$n = 20;
$result = bin2hex(random_bytes($n));
echo $result;
?>


<?php
$str=rand();
$result = md5($str);
echo $result;
?>


<?php
$str=rand();
$result = sha1($str);
echo $result;
?>


<?php
$str = rand();
$result = hash("sha256", $str);
echo $result;
?> */
