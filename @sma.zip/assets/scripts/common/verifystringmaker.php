<?php
class Verifystringgen{
	
function generateVerifyString(){
	
		// Generate verify_string
		$verify_string = '';
		for ($i = 0; $i < 16; $i++){
		$verify_string .= chr(mt_rand(32,126));
		}
		return urlencode($verify_string);

	}
	
}