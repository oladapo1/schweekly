document.addEventListener("DOMContentLoaded",configMgr,false);

function checkInitexist(){
	
		let getactivesession = sessionStorage.getItem("MYACTIVESESSIONVALUE");
	
		if(getactivesession == null){
			location.href = "index.html";
		} else if(getactivesession !== null){
			
			//check if url id has a value-not empty and get url parameters
			const paramString = location.search;
			const searchdParams = new URLSearchParams(paramString);
			 
			let thischurluid = searchdParams.has('webdev');
			if(!thischurluid){
				alert("webdev does not hold any url"); return false;
			}else if(thischurluid){
				
					let thisesuid = searchdParams.get("webdev");
				
					if(getactivesession === thisesuid){ //run comparator  - rem to take it up to server level
						
						console.log("Initialized");
						
					}else{
						alert("url contrast - please login again");
						location.href = "index.html";
					}
			}//todo - write an else if rqd
		}else{
			console.log("oops! challenges with getting page");
		}	
}


//document.addEventListener("DOMContentLoaded",configMgr,false); 
function configMgr(){
			
		//run an initial checker for sessionid and comparator aswell
		checkInitexist();
		
		//loadprofiletoview();
		
}

////////////////////////////////////////////////////////////
let logout_btn = document.getElementById("logoutbtn");

logout_btn.addEventListener("click",function(){
	
	document.getElementById("logoulbl").innerHTML = "logging off";
	
	const keyItemsinsessionstore = ["MYACTIVESESSIONVALUE","loginitemresponses"];


	for(j = 0; j < keyItemsinsessionstore.length; j++){
		var itemsn = keyItemsinsessionstore[j];
		
		sessionStorage.removeItem(itemsn);
	} 
	
	setTimeout(syouLater,2000);	
	
	},false);

function syouLater(){
	//location.href = "index.php";
	location.href = "index.html";
}

///////////////////Profile////////////////////

/* function loadprofiletoview(){
		 let callprofiledata = pullPinvoice();//JSON.parse(sessionStorage.getItem("pinvoices"));
		 
		 if(callprofiledata !== null){
			 let dt = callprofiledata[1];
			 document.getElementById("myprofileliatdisplay").innerHTML = "<div class='card' style=''><div class='card-body'><div class='row'><div class='col-4'> <span class='text-warning' id='' style='padding:5px;font-size:4em;'><i class='bi bi-hexagon-half'></i></span></div><div class='col-8'><h5 class='card-title fw-bold' id=''>" +dt.schname +"</h5><p>"+dt.schaddrs +"</p></div></div><div class='row'><div class='col-4 bg-light'></div><div class='col-8 bg-light'></div></div><div class='row'><div class='col-6 bg-light fw-bold' style='font-size:0.85em;'><i class='bi bi-phone'></i>"+dt.schtelf1+"</div><div class='col-6 bg-light fw-bold' style='font-size:0.85em;'><i class='bi bi-envelope-fill'></i> "+dt.schemail+"</div></div><div class='row mt-2' style='border-top:2px solid #101010;'><div class='col-4 bg-light'><label class='badge bg-info text-dark'>Joined</label><p class='' style='font-size:0.75em;'>"+dt.initdate +"</p></div><div class='col-8 bg-light'><label class='badge bg-info text-dark'>Payment account</label><p class='' style='font-size:0.75em;'>"+dt.payaccount+"</p></div></div></div></div>";
		 }else if(callprofiledata === null){
			 console.log("Profile list not available");
			 return false;
			 
		 }
		
	
} // load to view the membr profile */


function getsentieldData(gtId){
		//alert(gtId);
	let gtitem = document.getElementById(gtId).value;
	//alert(gtitem);return false;
	if(gtitem !== ""){
		profileditMgr(gtitem,gtId);
		
	}else if(gtitem === ""){
		//mysnackbarFunctionu("do you mean to edit?");
		alert(" You have not made any edit, kindly enter some values");
		document.getElementById(gtId).focus();
			return false;
	}
}


let edtprofile = document.getElementById("flexSwitchDispFrm");
edtprofile.onchange = function(){
	
	if(edtprofile.checked){
		document.getElementById("myprofilecontainer").style.display = "block";
	}else{
		document.getElementById("myprofilecontainer").style.display = "none";
	}

}
//Profile HANDLER
function profileditMgr(itemEditd,itemtype){
	
	let mymembershipeid = JSON.parse(sessionStorage.getItem("loginitemresponses"));
	mymembershipeid = mymembershipeid[1];
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			alert(xhttp.responseText);
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","assets/scripts/profiledit.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_itemEdited="+itemEditd +"&send_itemType="+itemtype+"&send_schid="+mymembershipeid);
}

//HANDLE Profilepix UPLOAD
let getm_profilesubmitbtn = document.getElementById("logosavebtn");
let getm_profileformname  = document.getElementById("memberschlogofrm");

//getm_profilesubmitbtn.addEventListener("click",function(){determImgCatgo(getm_profileformname.name)},false);

function determImgCatgo(e){
	//check if image is selected
	let fileinputvalue = document.getElementById("picturlogo")
	if(fileinputvalue.files.length == 0){
	alert("No image selected");
	//event.preventDefault();
	 return false;
	}else{	
	passImgCatgotoHandler(e);
	}
}

function passImgCatgotoHandler(filepix){
var form = document.forms.namedItem(filepix);

	let membrprofile = JSON.parse(sessionStorage.getItem("loginitemresponses"));
	membrprofile = membrprofile[1];

	let folderToUpload;
	let pixfiletoupload = "picturlogo";
	 
	if(filepix === "memberschlogofrm"){
		folderToUpload = "../dist/images/logo";
	}
	else{
		alert("Xoops!");
	}

      oData = new FormData(form);

  oData.append("UploadDir", folderToUpload);
  oData.append("ImagefromFileInput", pixfiletoupload);
  //oData.append("Whoeditnpix", membereditby_mprofile);
  oData.append("Whoeditnpix", membrprofile);
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "assets/scripts/profilepixuploadr.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
     console.log(oReq.responseText); alert(oReq.responseText);//oOutput.innerHTML = oReq.responseText;
    } else {
      console.log("Error " + oReq.status + " occurred when trying to upload your file.<br>");
    }
  };

  oReq.send(oData);
}

/////AssessmentMGR.////////////////

var maprhtml = ["htmlq1","htmlq2","htmlq3","htmlq4","htmlq5","htmlq6","htmlq7","htmlq8","htmlq9","htmlq10"];
var maprcss = ["css1","css2","css3","css4","css5","css6","css7","css8","css9","css10"];
var maprjvs = ["jvs1","jvs2","jvs3","jvs4","jvs5","jvs6","jvs7","jvs8","jvs9","jvs10","jvs11","jvs12","jvs13","jvs14","jvs15"];
var h = 1;
var questn_arr = []; //var arrcss = []; var arrjvs = [];

var anspickd = document.getElementsByClassName("anrvrad");
for (i = 0; i < anspickd.length; i++) {
    anspickd[i].onchange = function(){
		//console.log(questn_arr);
		let val = this.value;	//answer picked
		let str = this.name;//current question groupname
		let c = mapQuestiontype(str);// resolved question number
		questn_arr[c] = val;
		//alert(c);
		//console.log(questn_arr);
		//returnAnswersMgr(val,c,h);//answer,question eg Q7,question type eg CSS

  }
}

let cur_assessmnthtml = document.getElementById("htmlbtn");
let cur_assessmntcss  = document.getElementById("cssbtn");
let cur_assessmntjvs  = document.getElementById("javascripttab");

cur_assessmnthtml.addEventListener("click",function(){
	
	 h = 1;
	 questn_arr = [];//reset  arr	
	assessmentinprogress(h);
	
},false);

cur_assessmntcss.addEventListener("click",function(){
	
	 h = 2;
	 questn_arr = [];//reset  arr	
	assessmentinprogress(h);
	
},false);

cur_assessmntjvs.addEventListener("click",function(){
	
	 h = 3;
	 questn_arr = [];//reset  arr	
	assessmentinprogress(h);
	
},false);


function assessmentinprogress(val){
	
	switch(val){
		
	case 1:
	//HTML
	console.log("working on HTML");
		
	break;
	
	case 2:
	//CSS
	console.log("working on CSS");
	
	break;

	case 3:
	//JavaScript
	console.log("working on Javascript");
	
	break;	
	
	default:

	alert("what are you working on?");
	
	}

}

function mapQuestiontype(val){
	let j;
	let dc = function(mapr){
			for(j = 0;j < mapr.length;j++){
			let b = mapr[j].toString();
			if(val === b){
				//j;//current question
				 //return j;
				break;
				
			}
		}
	};
	
	if(h == 1){
		
		dc(maprhtml);
		
	}else if(h == 2){
		
		dc(maprcss);
		
	}else if(h == 3){
		
		dc(maprjvs);
	}
	//////
	 return j;
	//////
}

let htmlsubmitbtn = document.getElementById("htmlsubmitbtn");
htmlsubmitbtn.addEventListener("click",returnAnswersMgr,false);

let cssubmitbtn = document.getElementById("cssubmitbtn");
cssubmitbtn.addEventListener("click",returnAnswersMgr,false);

let jvsubmitbtn = document.getElementById("jvsubmitbtn");
jvsubmitbtn.addEventListener("click",returnAnswersMgr,false);

////Answer	to	db
function returnAnswersMgr(){
	
	let webdevid = JSON.parse(sessionStorage.getItem("loginitemresponses"));
	webdevid = webdevid[1];
	
	if(webdevid == null){
		
		alert("WebDev not found!");
		return false;
	}
	
	
	////////////////////////
	
	if(h == 1){
		lenq = 10;
	}else if(h == 2){
		lenq = 10;
	}else if(h == 3){
		lenq = 15;
	}
	
	////////////////////////
	let sumcount = 0;
	for(i = 0;i < lenq;i++){
		
		let u = questn_arr[i];
		
		if(questn_arr.length !== lenq){
			alert("All questions must be attempted");
			return false;
		}
		
		if(u == undefined){
			sumcount++;
			alert("You have incomplete questions");
			return false;
		}
		//console.log(typeof(u));
		//console.log(sumcount);
	}
	////////////////////////
	
	//ansnqload = JSON.stringify(questn_arr);
	let ansnqload = questn_arr;
	//console.log(JSON.stringify(questn_arr));
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			if(xhttp.responseText === "1"){
				alert("You already attempted this  Pre-Test");
				return false; 
			}else if(xhttp.responseText === "8"){
				
				alert("You have submitted successfully the  Pre-Test");
				location.reload() ; 
				
			}
			//alert(xhttp.responseText);
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","assets/scripts/returndansproc.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_ansqload="+ansnqload+"&send_qtype="+h+"&send_devid="+webdevid);
}

















