<?php
class AdminMsgs{
	
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $user_type;
	private $gt_stafid;
	private $getinitdata = array();
	private $gtnamesdata = array();
	
	private $days = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	
	private $mnth = array("January","February","March","April","May","June","July","August","September","October","November","December");
	
	private $dprlabels = array("Attendance","Temperament/Mood","Learning","Nap/Rest period","Toileting","State of health","Recreation","Appearance","Home Work","Meals","Attentiveness","Overactivity","Impulsiveness","Cooperative","Anxiety","Withdrawal","Appearance","Home Work","Non-aggressive","Aggressiveness");
	
	private $classarray = array("Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6","JSS 1","JSS 2","JSS 3","SSS 1","SSS 2","SSS 3");
	
	private $classarmarray = array("A","B","C","D","E","F");
	
	function __construct($gt_schid,$user_type,$gt_stafid,$gt_clas,$gt_clas_arm){
		
		$this->sch_u_id  = $gt_schid;
		$this->user_type = $user_type;
		$this->gt_stafid = $gt_stafid;
		$this->gt_clas     = $gt_clas;
		$this->gt_clas_arm = $gt_clas_arm;
				
		if(isset($user_type)){
			
			$this->pullRepliestomsgs();
			
		}else{
			
			echo "No pupil ID ";
		}
	}
	
	
	function pullRepliestomsgs(){
	include("../conect/connection.php");
	$metanotset = "No replies yet";//-1;//use if this code is sent off as
	$sqlpulladmmsg = "SELECT schuid,staffrefnumbr,bcastmsg,msgbcastid,msgauthor,pupilclass,classalias,msgpriority,msgcreated from messagesbygaurdn WHERE schuid = '{$this->sch_u_id}' AND msgauthor = '{$this->user_type}' AND pupilclass = '{$this->gt_clas}' AND classalias = '{$this->gt_clas_arm}' ORDER BY msgcreated DESC LIMIT 7";

			$resultmsgdata = $conn->query($sqlpulladmmsg);
				//$holdvals = [];
				if ($resultmsgdata->num_rows > 0) {
					
					while($rowmsgmeta = $resultmsgdata->fetch_assoc()) {
					
					$gtpupilid = $rowmsgmeta["msgauthor"];
					$gtmsgidid = $rowmsgmeta["msgbcastid"];
					
		///////////////get replies////////////////////
			$sqlgtnames = "SELECT msgrply,msgbcastid,msgauthor,datereply from msgreplies WHERE msgauthor = '{$gtpupilid}' AND msgbcastid = '{$gtmsgidid}'";

			$resultreplydata = $conn->query($sqlgtnames);
				
				$repliesunreachable = 0;
				if ($resultreplydata->num_rows > 0) {
					
					while($rowrepliesmeta = $resultreplydata->fetch_assoc()) {
						
						$replies = $rowrepliesmeta["msgrply"];
						$replydte = date('M-d-Y',strtotime($rowrepliesmeta["datereply"]));
						
						$classreso = $this->classarray[$rowmsgmeta["pupilclass"]];
						$classarm  = $this->classarmarray[$rowmsgmeta["classalias"]];
						$priority  = $this->dprlabels[$rowmsgmeta["msgpriority"]];
						$msgs = $rowmsgmeta["bcastmsg"];
						$msgsdate  = date('M-d-Y',strtotime($rowmsgmeta['msgcreated']));
					
						$holdmsg_id = $rowmsgmeta['msgbcastid'];
					//echo "Message ID: ".$rowmsgmeta["msgbcastid"]."<br>";
					//echo "Pupil ID: ".$rowmsgmeta["msgauthor"]."<br>";	
					echo"<label class='fw-bold opacity-50 badge bg-light' id='' style='color:#015393;'>".$priority."</label><div class='p-2 mx-4 mb-0 small lh-sm border-bottom'><span class='badge bg-light text-info' id=''>reply </span> <span class='text-dark' style='font-size:0.7em;'>".$replydte."<br></span><span id='' style='color:#015393;'>".$replies."</span> <br><small class='text-nowrap text-dark' style='font-size:0.7em;'></small></div><div class='p-2 mx-4 mb-0 small lh-sm border-bottom'><span class='badge bg-light text-secondary'>message</span> <small class='text-nowrap text-dark' style='font-size:0.7em;'>".$msgsdate."</small><br><span id='' style='color:#015393;'>".$msgs."</span></div>";
					}
					}else{
						
						//$this->getinitdata[] = $repliesunreachable;
						
						//echo $repliesunreachable;
					}
					/////////////////////////////////////////////////
					//$this->getinitdata[] = $rowmsgmeta;
					
					}
					//echo json_encode($this->getinitdata);
				}else{
						
			//$this->getinitdata[] = $metanotset;
			echo $metanotset;
		  }
		$conn->close();
	}
	
	
}	

//print_r($_POST);

$gtschid   = $_POST['schuid'];
$usertpe   = $_POST['snd_pupl_id'];
$gtstafid  = $_POST['stfruid'];
$gtclass   = $_POST['snd_class'];
$gtclarm   = $_POST['snd_clarm']; 

new AdminMsgs($gtschid,$usertpe,$gtstafid,$gtclass,$gtclarm);