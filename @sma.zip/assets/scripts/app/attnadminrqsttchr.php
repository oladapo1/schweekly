<?php
class SchweekAttnData{
	
	private $gtadminid;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $gt_dte1;
	private $gt_dte2;
	private $pupilsmeta;

	function __construct($gtadminid,$gtschid,$gtclass,$gtclsarm,$gt_date1,$gt_date2){
		
		$this->gtadminid   = $gtadminid;
		$this->sch_u_id    = $gtschid;
		$this->gt_clas     = $gtclass;
		$this->gt_dte1     = $gt_date1;
		$this->gt_dte2     = $gt_date2;
		$this->gt_clas_arm = $gtclsarm;
				
		if(isset($gtadminid) && isset($gtschid)){
			
		$this->pullAttendanceonadminrqst();
			
		}else{
			
			echo "No valid ID set";
			
		}
	}
	
	function pullAttendanceonadminrqst(){
		
	include("../conect/connection.php");
	
	$getinitdata = array();
	
			///////////////////////// scwkattendance 
	
			$sqlattnmeta = "SELECT schuid,presentees,absentees,entrydate,entryid,status from scwkattendance WHERE entrydate BETWEEN '{$this->gt_dte1}' AND '{$this->gt_dte2}' AND schuid = '{$this->sch_u_id}' AND pupilclass = '{$this->gt_clas}' AND pupilarm = '{$this->gt_clas_arm}' ORDER BY entrydate DESC";
			
			$pupilsnotset = -1;
			
			//$gtdata = [];		
			$pupilattndata = $conn->query($sqlattnmeta);

				if ($pupilattndata->num_rows > 0) {
					while($rowpupl = $pupilattndata->fetch_assoc()) {
						
						//$gtdata[] = $rowpupl;
						$getinitdata[] = $rowpupl;
												
						}
						//$getinitdata[] = $gtdata;
						//echo json_encode($getinitdata);

					}else{

			//echo $pupilsnotset;//there is no pupil data available for display
			$getinitdata[] = $pupilsnotset;
		//echo json_encode($getinitdata);
		  }
			///////////////////////////	
		echo json_encode($getinitdata);
		
		$conn->close();
     }
	 
	
}

//print_r($_POST);

$gtadminid  = $_POST['snd_staff_id'];
$gtschid    = $_POST['snd_schid'];
$gtclass    = $_POST['snd_class'];
$gtclsarm   = $_POST['snd_classarm'];
$gtdate1    = $_POST['snd_dte1'];
$gtdate2    = $_POST['snd_dte2'];

new SchweekAttnData($gtadminid,$gtschid,$gtclass,$gtclsarm,$gtdate1,$gtdate2);