<?php
class Attendancelist{
	
	private $gtarrlist;
	private $sch_u_id;
	
	
	function __construct($gt_array,$gt_schid){
		
		$this->gtarrlist = $gt_array;
		$this->sch_u_id  = $gt_schid;
		
		//echo $this->gtarrlist;
		
		if(isset($this->sch_u_id )){
			
			self::runfLoopd($this->gtarrlist);
			//echo $this->gtarrlist;
			
		}
		
	}


	function runfLoopd($gt_arrlist){

		//$json = str_replace('&quot;','"',$gt_arrlist);
		//$gtsend_activemesgr = json_decode($json,true);
		$gtsend_activemesgr = json_decode($gt_arrlist);
		//var_dump($gtsend_activemesgr); die();
		//print_r($gtsend_activemesgr); die();
		//$gtarray = array("001","002","005");

		/* foreach ($gtarray as $value) {
		echo $value."\n";
		}  */
		
		for($i = 0; $i < count($gtsend_activemesgr);$i++){

			self::runClassattendancebynames($i,$gtsend_activemesgr[$i]);
			
		}
	}

	function runClassattendancebynames($icount,$gtarrval){
		
		//echo $gtarrval ."<br>".$icount;// die();
		
		include("../conect/connection.php");
		$gtdata = [];	
		$sqlpupilmeta = "SELECT schuid,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE pupilrefnumbr = '{$gtarrval}'";
						
		/* echo"
		<div class='card' id=''>
		<div class='card-body'>
		"; */	
							 
		$pupildata = $conn->query($sqlpupilmeta);
	      
		if ($pupildata->num_rows > 0) {
			
			while($rowmyatnn = $pupildata->fetch_assoc()){
							//////////			  
							
					$gtpplfname  = $rowmyatnn["pupilsfname"];
					$gtpplsname  = $rowmyatnn["pupilssurname"];
					$gtpplid     = $rowmyatnn["pupilrefnumbr"];
					    
						//$gtdata[] = $rowmyatnn;
						//echo $gtpplfname."<br>";
						echo"
						<span class='border-top' style='font-size:0.75em;padding:3px;margin:2px;font-weight:600;'>$gtpplsname $gtpplfname</span>
						";

						//echo json_encode($rowmyatnn);
							
		         }
				//echo json_encode($gtdata);
			/* echo"
				</div>
				</div>
			";	 */			
		}else{
		echo "No Result";
	}
	///////

	$conn->close();
	
	} 
}

//print_r($_POST);

$gtarray  = $_POST['collated_array'];
$gtschid  = $_POST['gt_sch_id'];


New Attendancelist($gtarray,$gtschid);
