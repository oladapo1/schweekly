var gtlogoutrequest = document.getElementById("membrlogoutbtn");

gtlogoutrequest.addEventListener("click",function(){logmeOutnow();},false);

var keyItemsinsessionstore = ["fcd","loginitemresponses","mysojinkahinitmeta","input_rouge","inputin_editmode","mydraftitleinitload","authdeciderInput","authinputbymembr","numbersload","metaforcreateaprojct","veritychecked","hasCreateprojectload","NewCreateProjectLoad","uploadstatus"];

//remember to put an indicator for the redirection progress on logout

function logmeOutnow(){

	for(j = 0; j < keyItemsinsessionstore.length; j++){
		var itemsn = keyItemsinsessionstore[j];
		
		sessionStorage.removeItem(itemsn);
	} 
	setTimeout(syouLater,2000);
}

function syouLater(){
	location.href = "index.html";
	//location.href = "../scripts/clearsessionout_m.php";
}