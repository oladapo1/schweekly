document.addEventListener("DOMContentLoaded",function(){
	
initProgramechoice();
	
},false); 

var progrmchosen = null;
function initProgramechoice(){

///////////////////initialize-radio-btn///////////

let acc = document.getElementsByClassName("progchoice");
let i;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        console.log(this.value);
		progrmchosen = this.value;
  }
}
////////////////////////////////////////////////////////////
}
function initiatilizeSessionvaruuid(){

	//////////////Genearate UUID once (recursive function)//////////////
			let guid = function(){
			let s4 = function(){
				return Math.floor((1+Math.random())*0x10000).toString(36);
			}
			//return uid in this format 
			return s4() + s4()+ "-" +s4()+"-"+s4()+"-"+s4()+"-"+ s4() + s4()+ s4();
			}
			return guid();
  }


let memberloginbtn = document.getElementById("enrolsubmitbtn");
memberloginbtn.addEventListener("click",function(){chkloginLoad_ifempty()},false);

function chkloginLoad_ifempty(){

let gtenrolemail = document.getElementById("emailenrol").value;
let gtenrolwa    = document.getElementById("whatsappenrol").value;


if(gtenrolemail == "" || gtenrolwa == "" || progrmchosen == null){
		
		alert("All fields are required to proceed");
		return false;
		
		}else{
			
			if(gtenrolwa.length < 9 || gtenrolwa.length > 11){
				  alert("Phone is 9-to-11 chars");
				  return false;
			  }

			if(ValidateEmail(gtenrolemail) === false){
					alert("You have entered an invalid email address!");
					document.getElementById("emailenrol").focus();
					document.getElementById("emailenrol").style.border = "1px solid red";
					return false;
				}
			
			muv_login_Up(gtenrolemail,gtenrolwa);
	}
}


//validate-email
function ValidateEmail(inputText){
var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	if(inputText.match(mailformat))
		{
		return true;
		}
		else
		{
		return false;
		}
}


function muv_login_Up(membremail,membrwa){
	
	var newloginsession = initiatilizeSessionvaruuid();
	var emailo    = membremail;
	var ernolwa   = membrwa;

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			console.log(xhttp.responseText);
			//return false;
			sessionStorage.setItem("loginitemresponses",xhttp.responseText);
			
			let itemrecieved = extractLoginitems();
			
			if(itemrecieved == -1){
					//remind about activation by email link"; 
					alert("Email exists! check your inbox to continue");
					
				}else if(itemrecieved == 1){
				
					alert("Your details sent successfully");
				}
			}			
				  	
	};


	 /* Using POST */
	 
xhttp.open("POST","assets/scripts/app/enrolanew.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("enrolemail=" +membremail + "&enrolwapp=" +ernolwa+ "&loginmusession=" +newloginsession+"&trainingchosen="+progrmchosen);
}

// what does this function do?
function extractLoginitems(){
	
	if (sessionStorage.getItem("loginitemresponses") === null) {
                        alert("Instance is not set ");
                            }else{
                        let getfirstloginitems = sessionStorage.getItem("loginitemresponses");
						return getfirstloginitems;
                            }
}