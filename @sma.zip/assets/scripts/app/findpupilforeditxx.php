<?php
class PupilEdit{
	
	private $gtadminid;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $pupilsmeta;

	function __construct($gtadminid,$gtschid,$gtclass,$gtclsarm){
		
		$this->gtadminid   = $gtadminid;
		$this->sch_u_id    = $gtschid;
		$this->gt_clas     = $gtclass;
		$this->gt_clas_arm = $gtclsarm;
				
		if(isset($gtadminid)){
			
		$this->chckStfPrescencexist();
			
		}else{
			
			echo "No Staff ID ";
			
		}
	}
	
	function chckStfPrescencexist(){
		
	include("../conect/connection.php");
	
	$stfuidwrong = 0;// incorrect
	
	$sqlchkstfuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname,catype,isloginsuspended from staffprofile WHERE staffrefnumbr = '{$this->gtadminid}'";

	$resultgtdata = $conn->query($sqlchkstfuid);
	
	$getinitdata = array();
	
	if ($resultgtdata->num_rows > 0) {

	   while($rowschmeta = $resultgtdata->fetch_assoc()) {
		
		$gtschuid   = $rowschmeta["schuid"];
		$stfsname   = $rowschmeta["staffsurname"];
		$stfname    = $rowschmeta["stafffname"];
		$gtclstut   = $rowschmeta["classtut"];
		$gtclsarm   = $rowschmeta["classarm"];
		$gtcatype   = $rowschmeta["catype"];
		$stafrefid  = $rowschmeta["staffrefnumbr"];
		$suspndstat = $rowschmeta["isloginsuspended"];
				
		if($gtcatype == 1){
			
			$getinitdata[] = array($rowschmeta);
			
		}
			/////////////////////////
								
			$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND presentclass = '{$this->gt_clas}' AND classalias = '{$this->gt_clas_arm}'";
			
			$pupilsnotsetforthisclass = -1;
			
			$gtdata = [];		
			$pupildata = $conn->query($sqlpupilmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
					$gtdata[] = $rowpupl;
					//$gtpplfname  = $rowpupl["pupilsfname"];
					//$gtpplsname  = $rowpupl["pupilssurname"];
					//$gtpplid     = $rowpupl["pupilrefnumbr"];
						
	/* echo "<a href='#' class='list-group-item list-group-item-action d-flex gap-3 py-3' aria-current='true'>
    <img src='' alt='' width='32' height='32' class='rounded-circle flex-shrink-0'><div class='d-flex gap-2 w-100 justify-content-between'><div><h6 class='mb-0'>$gtpplsname $gtpplfname</h6>
        <p class='mb-0 opacity-75'>Some placeholder content in a paragraph.</p>
      </div><small class='opacity-50 text-nowrap'>now</small></div></a>"; */
								
						}
						$getinitdata[] = $gtdata;
						//echo json_encode($getinitdata);

					}else{

			$getinitdata[] = $pupilsnotsetforthisclass;
		//echo json_encode($getinitdata);
		  }
			///////////////////////////				
     }
			echo json_encode($getinitdata);	
	}else{
		
		$getinitdata[] = $stfuidwrong;
		echo json_encode($getinitdata);
	}
	
	$conn->close();
	}
}	

//print_r($_POST);

$gtadminid  = $_POST['snd_admin_id'];
$gtschid    = $_POST['snd_schid'];
$gtclass    = $_POST['snd_class'];
$gtclsarm   = $_POST['snd_classarm'];

new PupilEdit($gtadminid,$gtschid,$gtclass,$gtclsarm);