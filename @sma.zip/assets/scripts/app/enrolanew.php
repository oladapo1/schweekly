<?php
require_once('../auth/chkemailStatus.php');
require_once("../common/randcodegennr.php");
require_once("init_profile.php");

class ProceedToSignOps{

	private $usrmail;
	private $telfo;
	private $sessn;
	private $speclzn;

	
	function __construct($gt_email,$gt_wappnum,$gt_sessn,$gt_training){
	
	$this->usrmail = trim($gt_email);
	$this->telfo   = trim($gt_wappnum);
	$this->sessn   = $gt_sessn;
	$this->speclzn = $gt_training;
	
	}
		
	function checkEmailStatus(){
		$signupstatus = -1;
		$ChkStatus = new SignChkStatusNew($this->usrmail);
		$gtStatus = $ChkStatus->SignChkStatusNow();
		if(isset($gtStatus) && $gtStatus == true){
			
			$this->sendDetlsNow();
			//echo "Email does not even exists, can create new account!";
		}else{
			
			echo $signupstatus;
			//print"Email exists!";
		}
	}
	
	function sendDetlsNow(){
		$signupstatus = 1;
		include("../conect/connection.php");
		
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time()); // datetime('now')
		if(!empty($this->usrmail) || !empty($this->telfo)){
		$newUID = new Randomuiidgen; //generate unique ID for schuid
		$this->newUID = $newUID->createUID();
			//do a full insert query alphamembers
						$query = "INSERT INTO newenrols (email,telf,spectraining,timestmpd,alphamembrid,sessionid) VALUES ('$this->usrmail','$this->telfo','$this->speclzn','$mklogdindatetime','$this->newUID','$this->sessn')";
				if($conn->query($query) === TRUE) {
						//echo "your details sent successfully";
						echo $signupstatus;
						self::initProfile($this->newUID);

				}else {
				//echo "Error: " . $query . "<br>" . $conn->error;
				echo "Error-support-required";
				}
			//full insert query ends
			}else{
				print"please complete all fileds";
			}
						
			//close connection
				$conn->close();		
					
	}
	
	function initProfile($useruid){
		
		$init_profile = new NewmemberInitprofile($useruid);
		$setprofile = $init_profile->initProfileifNew();
	}
	

}

	// check for a token or an acountable registration sender at the login end or from the Owners end

	$gtemail   = $_POST['enrolemail'];
	$gtwappnum = $_POST['enrolwapp'];
	$gtsessn   = $_POST['loginmusession'];
	$gtraining = $_POST['trainingchosen'];

	$gtrqdVars = new ProceedToSignOps($gtemail,$gtwappnum,$gtsessn,$gtraining);
	$gtrqdVars->checkEmailStatus();