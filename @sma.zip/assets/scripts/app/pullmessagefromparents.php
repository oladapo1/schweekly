<?php
class AdminMsgs{
	
	private $sch_u_id;
	//private $gt_clas;
	//private $gt_clas_arm;
	private $user_type;
	private $gt_stafid;
	private $getinitdata = array();
	private $gtnamesdata = array();
	
	private $days = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	
	private $mnth = array("January","February","March","April","May","June","July","August","September","October","November","December");
	
	private $dprlabels = array("Attendance","Temperament/Mood","Learning","Nap/Rest period","Toileting","State of health","Recreation","Appearance","Home Work","Meals","Attentiveness","Overactivity","Impulsiveness","Cooperative","Anxiety","Withdrawal","Appearance","Home Work","Non-aggressive","Aggressiveness");
	
	private $classarray = array("Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6","JSS 1","JSS 2","JSS 3","SSS 1","SSS 2","SSS 3");
	
	private $classarmarray = array("A","B","C","D","E","F");
	
	function __construct($gt_schid,$user_type,$gt_stafid){
		
		$this->sch_u_id  = $gt_schid;
		$this->user_type = $user_type;
		$this->gt_stafid = $gt_stafid;
		//$this->gt_clas     = $gt_clas;
		//$this->gt_clas_arm = $gt_clas_arm;
				
		if(isset($user_type) && $user_type == 1){
						
		$this->pullAdminmsgs();
			
		}else{
			echo "No ID ";
		}
	}
	
	
	function pullAdminmsgs(){
	include("../conect/connection.php");
	$metanotset = "No messages yet";//-1;//use if this code is sent off as
	$sqlpulladmmsg = "SELECT * from messagesbygaurdn WHERE schuid = '{$this->sch_u_id}' AND exclusiveto = '{$this->user_type}' OR exclusiveto = 2 ORDER BY msgcreated DESC LIMIT 7";

			$resultmsgdata = $conn->query($sqlpulladmmsg);
				//$holdvals = [];
				if ($resultmsgdata->num_rows > 0) {
					
					while($rowadmmeta = $resultmsgdata->fetch_assoc()) {
					
					$gtpupilid = $rowadmmeta["msgauthor"];
					
		///////////////get pupil names////////////////////
			$sqlgtnames = "SELECT pupilrefnumbr,pupilssurname,pupilsfname,photoinformal from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND pupilrefnumbr = '{$gtpupilid}'";

			$resultnamesdata = $conn->query($sqlgtnames);
				
				$pupilnamesunreachable = 0;
				if ($resultnamesdata->num_rows > 0) {
					
					while($rownamesmeta = $resultnamesdata->fetch_assoc()) {
						
						$gtpupilsname = $rownamesmeta["pupilssurname"];
						$gtpupilfname = $rownamesmeta["pupilsfname"];
						//msgauthor
						$classreso = $this->classarray[$rowadmmeta["pupilclass"]];
						$classarm  = $this->classarmarray[$rowadmmeta["classalias"]];
						$priority  = $this->dprlabels[$rowadmmeta["msgpriority"]];
						$msgs = $rowadmmeta["bcastmsg"];
						$msgsdate  = date('M-d-Y',strtotime($rowadmmeta['msgcreated']));
						
						$holdmsg_id = $rowadmmeta['msgbcastid'];
				
					//echo "Pupil ID: ".$rowadmmeta["msgauthor"]."<br>";	
					echo"<div class'card'><div class'card-body'><label class='fw-bold opacity-50 badge bg-light' id='' style='color:#015393;'>".$priority."</label><div class='p-2 mx-4 mb-0 small lh-sm border-bottom'>".$classreso ." ". $classarm."<strong class='d-block text-dark' id=''>".$gtpupilsname ." ". $gtpupilfname."</strong><span id='' style='color:#015393;'>".$msgs."</span> <br><small class='text-nowrap text-dark' style='font-size:0.7em;'>".$msgsdate."</small> <button type='button' class='btn btn-outline-dark btn-sm rounded-pill' data-bs-toggle='modal' data-bs-target='#replymodal'  id='$gtpupilid' onclick='keepreplymeta(this,$holdmsg_id);' style='font-size:0.65em;font-weight:bold;'>reply</button></div>";
					}
					}else{
						
						//$this->getinitdata[] = $pupilnamesunreachable;
						echo $pupilnamesunreachable;
					}
					/////////////////////////////////////////////////
					//$this->getinitdata[] = $rowadmmeta;
					
					}
					//echo json_encode($this->getinitdata);
				}else{
						
			//$this->getinitdata[] = $metanotset;
			echo $metanotset;
		  }
		$conn->close();
	}
	
	
	/* function pullTeachermsgs(){
	include("../conect/connection.php");
	$mtanotset = -1;
	//echo $this->user_type; die();
	$sqlpulltcrmsgs = "SELECT * from messagesbygaurdn WHERE schuid = '{$this->sch_u_id}' AND pupilclass = '{$this->gt_clas}' AND classalias = '{$this->gt_clas_arm }' AND exclusiveto != 1 ORDER BY msgcreated DESC LIMIT 7";

			$resultchrdata = $conn->query($sqlpulltcrmsgs);
				//$tchrmsg = [];
				if ($resultchrdata->num_rows > 0) {
					
					while($rowtchrmeta = $resultchrdata->fetch_assoc()) {
							
					//$tchrmsg[] = $rowtchrmeta;
					//$this->getinitdata[] = $rowtchrmeta;
					
					$gtpupilid = $rowtchrmeta["msgauthor"];
					//echo "ID: ".$rowtchrmeta["msgauthor"]."<br>";
		///////////////get pupil names////////////////////
			$sqlgtnames = "SELECT pupilrefnumbr,pupilssurname,pupilsfname,photoinformal from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND pupilrefnumbr = '{$gtpupilid}'";

			$resultnamesdata = $conn->query($sqlgtnames);
				
				$pupilnamesunreachable = 0;// is not regitered in pupils table
				if ($resultnamesdata->num_rows > 0) {
					
					while($rownamesmeta = $resultnamesdata->fetch_assoc()) {
						
						$gtpupilsname = $rownamesmeta["pupilssurname"];
						$gtpupilfname = $rownamesmeta["pupilsfname"];
						
						$classreso = $this->classarray[$rowtchrmeta["pupilclass"]];
						$classarm  = $this->classarmarray[$rowtchrmeta["classalias"]];
						$priority  = $this->dprlabels[$rowtchrmeta["msgpriority"]];
						$msgs = $rowtchrmeta["bcastmsg"];
						$msgsdate  = date('M-d-Y',strtotime($rowtchrmeta['msgcreated']));
						
						$holdmsg_id = $rowtchrmeta['msgbcastid'];
						
					//echo "Pupil ID: ".$rowtchrmeta["msgauthor"]."<br>";	
					echo"<div class'card'><div class'card-body'><label class='fw-bold opacity-50 badge bg-light' id='' style='color:#015393;'>".$priority."</label><div class='p-2 mx-4 mb-0 small lh-sm border-bottom'>".$classreso ." ". $classarm."<strong class='d-block text-dark' id=''>".$gtpupilsname ." ". $gtpupilfname."</strong><span id='' style='color:#015393;'>".$msgs."</span> <br><small class='text-nowrap text-dark' style='font-size:0.7em;'>".$msgsdate."</small> <button type='button' class='btn btn-outline-dark btn-sm rounded-pill' data-bs-toggle='modal' data-bs-target='#replymodal'  id='$gtpupilid' onclick='keepreplymeta($gtpupilid,$holdmsg_id);' style='font-size:0.65em;font-weight:bold;'>reply</button></div></div></div>";
					}
					
					}else{
						
						//$this->getinitdata[] = $pupilnamesunreachable;
						echo $pupilnamesunreachable;
					}
					/////////////////////////////////////////////////
					
					}
					
					//$this->getinitdata[] = $tchrmsg;
					//echo json_encode($this->getinitdata);

				}else{
						
			//$this->getinitdata[] = $mtanotset;
			echo $mtanotset;//json_encode($this->getinitdata);
		  }
	$conn->close();

	} */



	/* function gatherPupilnames($gtpupilid){
		
			include("../conect/connection.php");

			///////////////get pupil names////////////////////
			$sqlgtnames = "SELECT pupilrefnumbr,pupilssurname,pupilsfname,photoinformal from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND pupilrefnumbr = '{$gtpupilid}'";

			$resultnamesdata = $conn->query($sqlgtnames);
				//$dprs = [];
				$pupilnamesunreachable = 0;
				if ($resultnamesdata->num_rows > 0) {
					
					while($rownamesmeta = $resultnamesdata->fetch_assoc()) {
						
						
						$this->getinitdata[] = $rownamesmeta;
						
					}
					
					echo json_encode($this->getinitdata);
					
					}else{
						
						$this->getinitdata[] = $pupilnamesunreachable;
						echo json_encode($this->getinitdata);
					}
					////////////////////////////////// 
		
	} */
	
}	

//print_r($_POST);

$gtschid   = $_POST['gt_sch_id'];
$usertpe   = $_POST['snd_utype'];
$gtstafid  = $_POST['snd_stfrid'];
//$gtclass   = $_POST['snd_class'];
//$gtclarm   = $_POST['snd_clarm']; 
//new AdminMsgs($gtschid,$usertpe,$gtstafid,$gtclass,$gtclarm);
new AdminMsgs($gtschid,$usertpe,$gtstafid);