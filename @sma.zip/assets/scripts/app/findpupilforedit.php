<?php
class PupilEdit{
	
	//private $gtadminid;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $pupilsmeta;

	function __construct($gtschid,$gtclass,$gtclsarm){
		
		//$this->gtadminid   = $gtadminid;
		$this->sch_u_id    = $gtschid;
		$this->gt_clas     = $gtclass;
		$this->gt_clas_arm = $gtclsarm;
				
		if(isset($gtschid)){
			
		$this->chckStfPrescencexist();
			
		}else{
			
			echo "No School ID ";
			
		}
	}
	
	function chckStfPrescencexist(){
		
	include("../conect/connection.php");
	
	
	$getinitdata = array();
	
	/////////////////////////
								
			$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND presentclass = '{$this->gt_clas}' AND classalias = '{$this->gt_clas_arm}'";
			
			$pupilsnotsetforthisclass = -1;
			
			$gtdata = [];		
			$pupildata = $conn->query($sqlpupilmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
					$gtdata[] = $rowpupl;
					//$gtpplfname  = $rowpupl["pupilsfname"];
					//$gtpplsname  = $rowpupl["pupilssurname"];
					//$gtpplid     = $rowpupl["pupilrefnumbr"];
														
						}
						//$getinitdata[] = $gtdata;
						echo json_encode($gtdata);

					}else{

			//$getinitdata[] = $pupilsnotsetforthisclass;
		echo json_encode($pupilsnotsetforthisclass);
		  }
			///////////////////////////
		$conn->close();			
	}
	
}	

//print_r($_POST);

//$gtadminid  = $_POST['snd_admin_id'];
$gtschid    = $_POST['snd_schid'];
$gtclass    = $_POST['snd_class'];
$gtclsarm   = $_POST['snd_classarm'];

new PupilEdit($gtschid,$gtclass,$gtclsarm);