<?php
require_once('../common/randcodegennr.php');
class ReplyPath{
	
	private $gt_schtomsg;
	private $gt_msgbdy;
	private $gtmsg_id;
	private $author_uid;
	private $stf_rply_id
;
	
	function __construct($gt_schtomsg,$gtmsg_id,$gt_msgbdy,$author_uid,$stf_rply_id){

	$this->gt_schtomsg = $gt_schtomsg;
	$this->gt_msgbdy   = filter_var($gt_msgbdy);
	$this->gtmsg_id    = $gtmsg_id;
	$this->author_uid  = $author_uid;
	$this->stf_rply_id = $stf_rply_id;
	
	self::replytoMsgsbyGuardian();
	
}
	
	function replytoMsgsbyGuardian(){
		
	 include("../conect/connection.php");
	 

		////////////////////////////////////////////
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		//$newUID = new Randomuiidgen; //generate unique ID for the msg
		//$this->newUID = $newUID->createUID();
		
		$query = "INSERT INTO msgreplies (schuid,msgbcastid,msgrply,msgauthor	,staffrefnumbr,datereply) VALUES ('$this->gt_schtomsg','$this->gtmsg_id','$this->gt_msgbdy','$this->author_uid','$this->stf_rply_id','$mklogdindatetime')";
		
		
				if ($conn->query($query) === TRUE) {
					
					echo "Sent successfully";

				}
				else {
		echo "Error: ";// . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
	}
}


//print_r($_POST);

$gtschtomsg  = $_POST['gt_sch_id'];
$gtmsgid     = $_POST['snd_bcstid'];
$gtmsgbdy    = trim($_POST['snd_rplybdy']);
$authr_uid   = $_POST['snd_authrid'];
$stfrply_id  = $_POST['snd_wureply'];

new ReplyPath($gtschtomsg,$gtmsgid,$gtmsgbdy,$authr_uid,$stfrply_id);