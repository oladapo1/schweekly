<?php
require_once('../common/randcodegennr.php');
class ParentMessges{
	
	private $gt_schtomsg;
	private $gt_stfuid;
	private $msg_towhom;
	private $gt_msgbdy;
	private $gt_msgprty;
	private $msg_author;
	private $pupil_clas;
	private $ppl_clsarm;
	
	function __construct($gt_schtomsg,$gt_stfuid,$msg_towhom,$gt_msgbdy,$gt_msgprty,$msg_author,$pupil_clas,$ppl_clsarm){
	
	$this->gt_schtomsg = $gt_schtomsg;
	$this->gt_stfuid   = $gt_stfuid;
	$this->msg_towhom  = $msg_towhom;
	$this->gt_msgbdy   = filter_var($gt_msgbdy);
	$this->gt_msgprty  = $gt_msgprty;
	$this->msg_author  = $msg_author;
	$this->pupil_clas  = $pupil_clas;
	$this->ppl_clsarm  = $ppl_clsarm;
	
	self::sendnewChatPostDetlsNow();
	
}
	
	function sendnewChatPostDetlsNow(){
		
	 include("../conect/connection.php");
	 
		/* if(!empty($this->newpostmsg)){ */
				
		////////////////////////////////////////////
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		$newUID = new Randomuiidgen; //generate unique ID for the msg
		$this->newUID = $newUID->createUID();
		
		$query = "INSERT INTO messagesbygaurdn (schuid,staffrefnumbr,exclusiveto,bcastmsg,msgpriority,msgauthor,msgcreated,msgbcastid,pupilclass,classalias) VALUES ('$this->gt_schtomsg','$this->gt_stfuid','$this->msg_towhom','$this->gt_msgbdy','$this->gt_msgprty','$this->msg_author','$mklogdindatetime','$this->newUID','$this->pupil_clas','$this->ppl_clsarm')";
		
		
				if ($conn->query($query) === TRUE) {
					
					echo "Sent successfully";

				}
				else {
		echo "Error: ";// . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
	}
}


//print_r($_POST);   

$gtschtomsg = $_POST['send_schuid'];
$gtstfuid   = $_POST['stffuid'];
$msgtowhom  = $_POST['rceiver'];
$gtmsgbdy   = trim($_POST['txtbody']);
$gtmsgprty  = $_POST['msgprity'];
$msgauthor  = $_POST['msgcreator'];
$pupilclas  = $_POST['snd_class'];
$pplclsarm  = $_POST['snd_clarm'];

new ParentMessges($gtschtomsg,$gtstfuid,$msgtowhom,$gtmsgbdy,$gtmsgprty,$msgauthor,$pupilclas,$pplclsarm);