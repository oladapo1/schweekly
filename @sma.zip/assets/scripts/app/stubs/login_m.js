function initiatilizeSessionvaruuid(){

		/////////////////////Genearate UUID once (recursive function)//////////////////////////
			let guid = function(){
			let s4 = function(){
				return Math.floor((1+Math.random())*0x10000).toString(36);
			}
			//return uid in this format 
			return s4() + s4()+ "-" +s4()+"-"+s4()+"-"+s4()+"-"+ s4() + s4()+ s4();
			}
			return guid();
	 /*  }else{
		  
		  // handle as due
	  } */
  }

var memberloginbtn = document.getElementById("submitmembrlogin");
memberloginbtn.addEventListener("click",function(){chkloginLoad_ifempty()},false);

//document.addEventListener("DOMContentLoaded",chkloginLoad_ifempty,false);
function chkloginLoad_ifempty(){

let gtLoginUname = document.getElementById("webdevloginemail").value;
let gtLoginPasskey = document.getElementById("webdevloginpasswd").value;


	if(gtLoginUname == "" || gtLoginPasskey == ""){
		
		alert("All fields are required to proceed");
		return false;
		
		}else{
			
			muv_login_Up(gtLoginUname,gtLoginPasskey);
		}
}

function muv_login_Up(membremail,membrpasskey){
	
	var newloginsession = initiatilizeSessionvaruuid();
	var emailo = membremail;
	var pwdy   = membrpasskey;

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
			//alert(xhttp.responseText);		
			console.log(xhttp.responseText);
			sessionStorage.setItem("loginitemresponses",xhttp.responseText);
			
			let itemrecieved = extractLoginitems();
			if(itemrecieved == -1){
					//remind about activation by email link"; 
					alert("You need to complete your verification");
					
					initMetadetails(emailo,pwdy); - //initialize meta-details
					setTimeout(location.href = "proviso.html?webdev=",3000);
					
				}else if(itemrecieved == 0){
					alert("check passkey");//from login_komaalo
					location.reload();
				}else if(itemrecieved == 1){
					// go to members account page - also precheck profile status
					let getsesionitem = JSON.parse(sessionStorage.getItem("loginitemresponses"));
					sessionStorage.setItem("MYACTIVESESSIONVALUE",getsesionitem[2]);
					location.href = "members.html?webdev="+getsesionitem[2];
				}else if(itemrecieved == 2){
					alert("Verify status unknown - contact admin");
				}else if(itemrecieved == 3){
					alert("User does not exist");
				}else{//login
						
				}
			}			
				  	
	};


	 /* Using POST */
	 
xhttp.open("POST","assets/scripts/auth/login_komaalo.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +membremail + "&send_lg_Pwd=" +membrpasskey + "&loginmusession=" +newloginsession);
	
}

// what does this function do?
function extractLoginitems(){
	
	if (sessionStorage.getItem("loginitemresponses") === null) {
                                  alert("Instance is not set ");
                            }else{
                        let getfirstloginitems = JSON.parse(sessionStorage.getItem("loginitemresponses"));
						return getfirstloginitems[0].toString();
                            }
}

function initMetadetails (email,pwd){
	
	let createaprojectmeta = [];
	createaprojectmeta[0] = email; createaprojectmeta[1] = pwd;
	sessionStorage.setItem("metaforcreateaprojct",JSON.stringify(createaprojectmeta));
		
		}


function createinitLoadmorevalue(){
	
	sessionStorage.setItem("sojinkahsessions","0");
}

