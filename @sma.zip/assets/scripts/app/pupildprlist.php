<?php
class DPRboardlist{
	
	private $gtstdid;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	//private $pupilsmeta;

	function __construct($gtstdid,$gtschid,$gt_class,$gt_clarm){
		
		$this->gtstdid     = $gtstdid;
		$this->sch_u_id    = $gtschid;
		$this->gt_clas     = $gt_class;
		$this->gt_clas_arm = $gt_clarm;
				
		if(isset($gtstdid)){
			
		$this->chckStfPrescencexist();
			
		}else{
			
			echo "No Pupil ID ";
			
		}
	}
	
	function chckStfPrescencexist(){
		
	include("../conect/connection.php");
	
			///////////////////////// pupilrefnumbr	
								
			$sqlpupildprmeta = "SELECT * from dailyprogresrportsecsch WHERE DATE(dateposted) = DATE(NOW()) AND pupilrefnumbr = '{$this->gtstdid}' AND curclass = '{$this->gt_clas}' AND curclassarm = '{$this->gt_clas_arm}'";
			
			//echo $this->gtstdid."-".$this->gt_clas."-".$this->gt_clas_arm; die();
			
			$pupilsnotset = -1;
			
			$pupildata = $conn->query($sqlpupildprmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
						$getinitdata[] = $rowpupl;	
												
						}

						echo json_encode($getinitdata);

					}
					else{

			//echo $pupilsnotset;//there is no pupil data available for display
			$getinitdata[] = $pupilsnotset;
			echo json_encode($getinitdata); 
		  }
			///////////////////////////
			$conn->close();
     }		
}
	


//print_r($_POST);

$gtpplid  = $_POST['snd_pupilid'];
$gtschid  = $_POST['snd_schid'];
$gtclass  = $_POST['snd_class'];
$gtclarm  = $_POST['snd_clarm'];

new DPRboardlist($gtpplid,$gtschid,$gtclass,$gtclarm);