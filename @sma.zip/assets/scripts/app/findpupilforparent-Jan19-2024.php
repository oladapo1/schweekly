<?php
class GuardianData{
	
	private $gt_pupil;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $pupilsmeta;
	private $getinitdata = array();


	function __construct($gt_pupil){
		
		$this->gt_pupil  = $gt_pupil;
		//$this->sch_u_id    = $gtschid;
		//$this->gt_clas     = $gtclass;
		//$this->gt_clas_arm = $gtclsarm;
				
		if(isset($gt_pupil)){
			
		$this->chckmetaValueifexist();
			
		}else{
			
			echo "No pupil ID ";
			
		}
	}
	
	function chckmetaValueifexist(){
		
	include("../conect/connection.php");	
	
	$stfuidwrong = 0;// incorrect
	
	$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE pupilrefnumbr = '{$this->gt_pupil}'";
						
	//$gtdata = [];
	
	$pupildata = $conn->query($sqlpupilmeta);
		
	if ($pupildata->num_rows > 0) {

	   while($rowpupl = $pupildata->fetch_assoc()) {
		
		$this->sch_u_id    = $rowpupl["schuid"];
		$this->gt_clas     = $rowpupl["presentclass"];
		$this->gt_cls_arm  = $rowpupl["classalias"];
		
		$this->getinitdata[] = $rowpupl;
			
        }
		//$getinitdata[] = $gtdata;
			//echo json_encode($this->getinitdata);
			//self::collateStaffmeta();	
			$this->collateStaffmeta();
	}else{
		
		$this->getinitdata[] = $stfuidwrong;
		echo json_encode($this->getinitdata);
	}
	
	$conn->close();
	}
	
	function collateStaffmeta(){
		
		include("../conect/connection.php");
		
		$staffnotset = -1;
		
		$sqlchkstfuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname from staffprofile WHERE schuid = '{$this->sch_u_id}' AND classtut = '{$this->gt_clas}' AND classarm = '{$this->gt_cls_arm}'";

			$resultgtdata = $conn->query($sqlchkstfuid);
				$drafts = [];
				if ($resultgtdata->num_rows > 0) {
					
					while($rowschmeta = $resultgtdata->fetch_assoc()) {
						
					$stfsname   = $rowschmeta["staffsurname"];
					$stfname    = $rowschmeta["stafffname"];
					//$gtcatype   = $rowschmeta["catype"];
					$stafrefid  = $rowschmeta["staffrefnumbr"];
							
					$drafts[] = $rowschmeta; //$this->getinitdata[] = $rowschmeta;
					
					}
					
					$this->getinitdata[] = $drafts;
					//echo json_encode($this->getinitdata);
					//$this->pullpreDPR();

				}else{
						
			$this->getinitdata[] = $staffnotset;
		  }
		  
		  $this->pullpreDPR();
		$conn->close();
	}
	
	function pullpreDPR(){
	include("../conect/connection.php");
	$dprnotset = -1;
	$sqlpulldpr = "SELECT * from dailyprogresrportsecsch WHERE schuid = '{$this->sch_u_id}' AND curclass = '{$this->gt_clas}' AND curclassarm = '{$this->gt_cls_arm}' AND pupilrefnumbr = '{$this->gt_pupil}' ORDER BY dateposted DESC LIMIT 7";

			$resultdprdata = $conn->query($sqlpulldpr);
				$dprs = [];
				if ($resultdprdata->num_rows > 0) {
					
					while($rowdprmeta = $resultdprdata->fetch_assoc()) {
							
					$dprs[] = $rowdprmeta;
					
					}
					
					$this->getinitdata[] = $dprs;
					//echo json_encode($this->getinitdata);
					//this->pullAttnload();

				}else{
						
			$this->getinitdata[] = $dprnotset;
		  }
		$this->pullAttnload();
	$conn->close();

	}
	
	//pull attendances
	
	function pullAttnload(){
	include("../conect/connection.php");
	$attndnotset = -1;
	$sqlpullattn = "SELECT * from scwkattendance WHERE schuid = '{$this->sch_u_id}' AND pupilclass = '{$this->gt_clas}' AND pupilarm = '{$this->gt_cls_arm}' ORDER BY entrydate DESC LIMIT 7";

			$resultattndata = $conn->query($sqlpullattn);
				$attns = [];
				if ($resultattndata->num_rows > 0) {
					
					while($rowattnmeta = $resultattndata->fetch_assoc()) {
					
					////////////////					
					$absents = $rowattnmeta["absentees"];
					////////////////
					
					$attns[] = $absents; //$rowattnmeta;
					
					}
					
					$this->getinitdata[] = $attns;
					//echo json_encode($this->getinitdata);
					//$this->pullHomeworkload();

				}else{
						
			$this->getinitdata[] = $attndnotset;
		  }
		$this->pullHomeworkload();
	$conn->close();

	}
	
	function pullHomeworkload(){
		
	include("../conect/connection.php");
	$hworknotset = -1;
	$sqlpullhwork = "SELECT * from scwhomework WHERE schuid = '{$this->sch_u_id}' AND pupilclass = '{$this->gt_clas}' AND pupilarm = '{$this->gt_cls_arm}' ORDER BY addate DESC LIMIT 7";

			$resulthworkdata = $conn->query($sqlpullhwork);
				$hwork = [];
				if ($resulthworkdata->num_rows > 0) {
					
					while($rowhworkmeta = $resulthworkdata->fetch_assoc()) {
							
					$hwork[] = $rowhworkmeta;
					
					}
					
					$this->getinitdata[] = $hwork;
					//echo json_encode($this->getinitdata);

				}else{
						
			$this->getinitdata[] = $hworknotset;
		  }
		echo json_encode($this->getinitdata);
		//$this->gtReplymesgsbublecount();
	$conn->close();

	}
	
	////////////////////reply to messages bubble count
	
	function gtReplymesgsbublecount(){
		
	include("../conect/connection.php");	
	$authruidwrong = 0;
	$sqlreplymeta = "SELECT msgrply from msgreplies WHERE msgauthor = '{$this->gt_pupil}' ORDER BY datereply DESC LIMIT 4";
	//$sqlcnt = "SELECT COUNT(*) FROM emergencynewbcastcreate WHERE exclusiveto = '{$mycatgory[$i]}'";
	//"SELECT COUNT(rootbcastid) FROM emrgencynewbroadcastrxn WHERE rootbcastid = $gtbcastid";
						
	//$gtdata = [];
	
	$replydata = $conn->query($sqlreplymeta);
	$replycount = [];
	if ($replydata->num_rows > 0) {

	   while($rowrply = $replydata->fetch_assoc()) {
		
		$replycount[] = $rowrply["msgrply"];
		
			
        }
		
		$this->getinitdata[] = count($replycount);
			//$this->collateStaffmeta();
	}else{
		
		$this->getinitdata[] = $authruidwrong;
		echo json_encode($this->getinitdata);
	}
	echo json_encode($this->getinitdata);
	$conn->close();
	}
	
}	

//print_r($_POST);

$gtpupilid  = $_POST['send_pupl_id'];

new GuardianData($gtpupilid);