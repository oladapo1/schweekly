var gtlogoutlink = document.getElementById("logoutfrontend");
var gtlogoutlink2 = document.getElementById("logoutendit");
//AMDELEGATED 
/* my_loadmocounter
myNotifs_CnReqst
PullsuggestedConnectionstostore
initMemberforsearch
MYPersonalVALUES
mylimsize
myArraystarter
comcount_reload
myNotifs
initBcastsload
LOADMORElim
fcontributntopic
AMDELEGATED
postid_reload
frmcntribttvws
flashInfo
frmcntribauthor
articlecontent
audiotxtncontent
topbanrbysystem
videotxtncontent 
.
PROJCTid
PROJCTMtitle
CurrentActive
LoadBubbles
namedlbl
actvtylogstc
pcnidstatus
PullConnectionsrequestedtostore
// frmcntribttvws
// frmcntribauthor
// fcontributntopic
// comcount_reload
// postid_reload
// myArraystarter
// my_loadmocounter
// mylimsize
tpcounter
numbrofturnstpbanr
temptopbanner
// topbanrbysystem
AilmentData
MYTOPBANNER
flashInfo
SlidePrevw
Minidetails
loadeventinmonthlyrange
eventlen
countevent
numbrofturns
PullselectedMemberforview




*/

gtlogoutlink.addEventListener("click",function(){logmeOutnow();},false);
gtlogoutlink2.addEventListener("click",function(){logmeOutnow();},false);

//var keyItemsinlocalstore = ["",""];
var keyItemsinsessionstore =  ["initMemberforsearch","MYPersonalVALUES","PullselectedMemberforview","initMembers","MYTOPBANNER","videotxtncontent","my_loadmocounter","myNotifs_CnReqst","PullsuggestedConnectionstostore","initMemberforsearch","mylimsize","myArraystarter","myNotifs","LOADMORElim","AMDELEGATED","flashInfo","articlecontent","tpcounter","audiotxtncontent","topbanrbysystem","fcontributntopic","frmcntribauthor","frmcntribttvws","postid_reload","comcount_reload","initBcastsload","myNotifs"];
//remember to put an indicator for the redirection progress on logout

function logmeOutnow(){

	for(j = 0; j < keyItemsinsessionstore.length; j++){
		var itemsn = keyItemsinsessionstore[j];
		
		sessionStorage.removeItem(itemsn);
	} 
	setTimeout(syouLater,2000);
}

function syouLater(){
	location.href = "login.php";
}
