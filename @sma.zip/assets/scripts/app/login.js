var getLoginadmin = document.getElementById("login_owabtnid");

getLoginadmin.addEventListener("click",chkloginLoad_ifempty,false);

function chkloginLoad_ifempty(){

let gtLoginPasskey = document.getElementById("login_owapwd").value;
let gtLoginUname = document.getElementById("login_owaun").value;

if(gtLoginUname == "" || gtLoginPasskey == ""){
	
	alert("All fields are required");
	document.getElementById("login_owaun").focus();
	return false;
	
	}else{
		
		muv_login_Up(gtLoginUname,gtLoginPasskey);
	
	}
}


function muv_login_Up(owaUname,owaPasskeyr){
		
//console.log(owaUname +"--"+owaPasskeyr); return false;
	document.getElementById("resplogin").style.display = "inline-block";
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
			
			console.log(xhttp.responseText);
			
		let resp = JSON.parse(xhttp.responseText);
		
			if(resp[0] == -1){
				alert("User not yet verified");
				location.reload();
			}else if(resp[0] == 0){
				alert("Incorrect password");
				location.reload();
			}else if(resp[0] == 2){
				alert("Verify status unknown");
				location.reload();
			}else if(resp[0] == 3){
				alert("User doest not exist");
				location.reload();
			}else{
				
				let respr = JSON.parse(xhttp.responseText);
				if(respr[0][0].verifystatus == 1){
					alert("Welcome");
					//console.log(xhttp.responseText);
					sessionStorage.setItem("schweeklymeta",xhttp.responseText);
					sessionStorage.setItem("Countr",0);
					location.href = "admin/";
				}else{
					
					alert("See support");
				}
			}
	document.getElementById("resplogin").style.display = "none";
			
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","assets/scripts/auth/login_komaalo.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +owaUname + "&send_lg_Pwd=" +owaPasskeyr);
}


//for teacher login_
let tchrsubmitbtn = document.getElementById("login_owabtchernid");
tchrsubmitbtn.addEventListener("click",chktchr_ifempty,false);

function chktchr_ifempty(){
//console.log("okay"); return false;
let tchrLoginkey = document.getElementById("login_tchrpwd").value;

if(tchrLoginkey == ""){

	alert("Passkey required");
	document.getElementById("login_tchrpwd").focus();
	return false;
	
	}
	
	if(tchrLoginkey.length < 8){
	
	alert("Passkey cannot be less than 8");
	
	setTimeout(function(){
		//replbl.innerHTML = "";
		document.getElementById("login_tchrpwd").value = "";
	},2000);
		
	}
	
	else{
		
		muv_login_tchr(tchrLoginkey);
	
	}
}


function muv_login_tchr(owaPasskeyr){
	//console.log("okay "+owaPasskeyr); return false;
	var tchrLogin_key = document.getElementById("login_tchrpwd");

	document.getElementById("resplogintchr").style.display = "inline-block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			//console.log(xhttp.responseText);
			
			let initresp = JSON.parse(xhttp.responseText);
			//console.log(initresp.length);return false;
			
			if(initresp[1] == 3){
				console.log("This teacher has no pupils set in table yet");
				alert("This teacher has no pupils to view, rem to add some");
				//setTimeout(function(){
				//	tchrLogin_key.value = "";
				//},4000);
				
				/////////////////////
				 let usrtype	= JSON.parse(xhttp.responseText);
				let utype = usrtype[0][0].catype;
				
					alert("Welcome");
					
				if(utype == 1){
						//admin
				sessionStorage.setItem("schweeklymeta",xhttp.responseText);
				sessionStorage.setItem("Countr",0);
				location.href="admin/";	
				}else if(utype == 2){
						//tcher		
				sessionStorage.setItem("schweeklymeta",xhttp.responseText);
				sessionStorage.setItem("Countr",0);
				location.href="teacher/";
				
				}
				/////////////////////
				//location.reload();
				//return false;
			}
			
			if(initresp[0] == 0){
				
				alert("User not found");
				setTimeout(function(){
					tchrLogin_key.value = "";
				},2000);
				
			}else{
				let usrtype	= JSON.parse(xhttp.responseText);
				//console.log(usrtype[0][0].catype);	return false;	
				let utype = usrtype[0][0].catype;
				
					alert("Welcome");
					
				if(utype == 1){
						//admin
				sessionStorage.setItem("schweeklymeta",xhttp.responseText);
				sessionStorage.setItem("Countr",0);
				location.href="admin/";	
				}else if(utype == 2){
						//tcher		
				sessionStorage.setItem("schweeklymeta",xhttp.responseText);
				sessionStorage.setItem("Countr",0);
				location.href="teacher/";
				
				}
			}
	document.getElementById("resplogintchr").style.display = "none";
		}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","assets/scripts/auth/global/screapst/login_glob.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Pwd=" +owaPasskeyr);
}  