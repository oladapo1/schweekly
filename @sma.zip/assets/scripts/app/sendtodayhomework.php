<?php
require_once('../common/randcodegennr.php');
class Homework{
	
	private $gt_schtomsg;
	private $gt_stfuid;
	private $gt_msgbdy;
	private $gt_class;
	private $hwrkcarm;
	
	function __construct($gt_schtomsg,$gt_stfuid,$gt_msgbdy,$gt_class,$hwrkcarm){
	
	$this->gt_schtomsg = $gt_schtomsg;
	$this->gt_stfuid   = $gt_stfuid;
	$this->gt_msgbdy   = filter_var($gt_msgbdy);
	$this->gt_class  = $gt_class;
	$this->hwrkcarm  = $hwrkcarm;
	
	self::sendnewHomeworktoday();
	
}
	
	function sendnewHomeworktoday(){
		
	 include("../conect/connection.php");
	 
		/* if(!empty($this->newpostmsg)){ */
				
		////////////////////////////////////////////
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		//$newUID = new Randomuiidgen; //generate unique ID for the msg
		//$this->newUID = $newUID->createUID();
		
		$query = "INSERT INTO scwhomework (schuid,staffrefnumbr,homewrk,pupilclass	,pupilarm	,addate) VALUES ('$this->gt_schtomsg','$this->gt_stfuid','$this->gt_msgbdy','$this->gt_class','$this->hwrkcarm','$mklogdindatetime')";
		
		
				if ($conn->query($query) === TRUE) {
					
					echo "Sent successfully";

				}
				else {
		echo "Error: ";// . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
	}
}


//print_r($_POST);

$gtschtomsg = $_POST['gt_sch_id'];
$gtstfuid   = $_POST['stf_id'];
$gtmsgbdy   = trim($_POST['send_hwrkbdy']);
$sndclass   = $_POST['snd_clas'];
$clasarm    = $_POST['snd_carm'];



new Homework($gtschtomsg,$gtstfuid,$gtmsgbdy,$sndclass,$clasarm);