<?php
class Loginsessionlogr{

	private $userverifiedId;
	private $loginsesion;
	function __construct($userverifiedId,$_userssnId){
			
			$this->userverifiedId = $userverifiedId;
			$this->loginsesion    = $_userssnId;
			$this->filloginSessions();
		}

	function filloginSessions(){
			
			include("../../conect/connection.php");
			$userprofileinitgood = 14;
			date_default_timezone_set("Africa/Lagos");
			$mklogddatetime = date("Y-m-d h:i:s",time());
			//$yearnow = date("Y-m-d");

			$query = "INSERT INTO loginlogr (membruid,sessuid,datelogd) VALUES ('$this->userverifiedId','$this->loginsesion','$mklogddatetime')";
					if ($db->query($query) === TRUE) {					 	
						
							//echo "session init successfully ";

					}else {
					echo "Error: " . $query . "<br>" . $conn->error;
				}
				
			include "../../conect/closedb.php";
		}				
}