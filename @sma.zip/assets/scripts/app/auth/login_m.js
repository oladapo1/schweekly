function initiatilizeSessionvaruuid(){
		/////////////////////Genearate UUID once (recursive function)//////////////////
			let guid = function(){
			let s4 = function(){
				return Math.floor((1+Math.random())*0x10000).toString(36);
			}
			//return uid in this format 
			return s4() + s4()+ "-" +s4()+"-"+s4()+"-"+s4()+"-"+ s4() + s4()+ s4();
			}
			return guid();
}

let membrloginbtn = document.getElementById("loginsubmitbtn");
membrloginbtn.addEventListener("click", function(){chkloginLoad_ifempty();},false);

function chkloginLoad_ifempty(){

	let gtLoginUname   = document.getElementById("emailaddrr").value;
	let gtLoginPasskey = document.getElementById("pinpassword").value;


	if(gtLoginUname == "" || gtLoginPasskey == ""){
		
		alert("All fields are required to proceed");
		return false;
		
		}else{
			muv_login_Up(gtLoginUname,gtLoginPasskey);
		}
}

function muv_login_Up(membremail,membrpasskey){
	
	let newloginsession = initiatilizeSessionvaruuid();
	let emailo 			= membremail;
	let pwdy  			= membrpasskey;
	
	//console.log(newloginsession);
	let busyholder = document.getElementById("busyindicatr");
	busyholder.innerHTML = '<div class="spinner-grow text-light float-end" role="status"  style="margin-top:-30px;"><span class="visually-hidden">loading...</span></div>';
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
			//alert(xhttp.responseText);		
			console.log(xhttp.responseText);
	busyholder.innerHTML = '<div class="spinner-grow text-light float-end" role="status"  style="margin-top:-30px;"><span class="visually-hidden">loading...</span></div>';		
			
			sessionStorage.setItem("loginitemresponses",xhttp.responseText);
			let itemrecieved = extractLoginitems();
			if(itemrecieved == -1){
					//remind about activation by email link"; 
					alert("You need to complete your activation - check email sent");
					location.reload();
					//initMetadetails(emailo,pwdy);//initialize meta-details for further procs
					//setTimeout(location.href = "index.html?pinned=",3000);
				}else if(itemrecieved == 0){
					alert("check passkey");//from login_komaalo
					location.reload();
				}else if(itemrecieved == 1){
					// go to members account page - also precheck profile status
					sessionStorage.setItem("MYACTIVESESSIONVALUE",newloginsession);
					let getsesionitem = JSON.parse(sessionStorage.getItem("loginitemresponses"));
					//location.href = "index.html?pinned="+getsesionitem[1];
					location.href = "index.html?pinned="+newloginsession;
				}else if(itemrecieved == 2){
					alert("Verify status unknown - contact admin");
				}else if(itemrecieved == 3){
					alert("User does not exist");
					busyholder.innerHTML = "";
				}else{//login-todo			
				}
			}			
				  	
	};


	 /* Using POST */
	 
xhttp.open("POST","scripts/auth/login_komaalo.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +membremail + "&send_lg_Pwd=" +membrpasskey + "&loginmusession=" +newloginsession);
	
}

// function ?? todo
function extractLoginitems(){
	
	if (sessionStorage.getItem("loginitemresponses") === null) {
                                  alert("Instance is not set ");
                            }else{
                        let getfirstloginitems = JSON.parse(sessionStorage.getItem("loginitemresponses"));
						return getfirstloginitems[0].toString();
                            }
}

function initMetadetails (email,pwd){
	
	let createaprojectmeta = [];
	createaprojectmeta[0] = email; createaprojectmeta[1] = pwd;
	sessionStorage.setItem("metaforcreateaprojct",JSON.stringify(createaprojectmeta));
		
}


/* function createinitLoadmorevalue(){
	
	sessionStorage.setItem("pinedsessions","0");
} */