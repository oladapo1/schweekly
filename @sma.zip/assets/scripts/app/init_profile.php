<?php
class NewmemberInitprofile{
private $uid;
function __construct($membruid){
		$this->uid = $membruid;
		//echo $this->uid;
		//self::initProfileifNew();
	}
function initProfileifNew(){
	
			include("../conect/connection.php");
	$query = "SELECT alphamembrid FROM membrprofile WHERE alphamembrid = '$this->uid'";
			
			$data = $conn->query($query);
		
		if ($data->num_rows == 0){
		
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		// do an insert only for member id
		$query = "INSERT INTO membrprofile (alphamembrid,initdate) VALUES ('$this->uid','$mklogdindatetime')";
				if ($conn->query($query) === TRUE) {					 	
						//echo "Member uid init sent";

				}else {
				echo "Error: ";// . $query . "<br>" . $conn->error;
			}
			//print "Member uid does not exist ".$this->uid;

		}
	else{
		
			//print "Member uid exist ".$this->uid;
} 
$conn->close();
}				
}