<?php
class GuardianDatadated{
	
	private $gtdates;
	private $gt_pupil;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $pupilsmeta;
	private $getinitdata = array();


	function __construct($gtdates,$gt_pupil){
		
		$this->gtdates   = $gtdates;
		$this->gt_pupil  = $gt_pupil;
				
		if(isset($gt_pupil)){
			
		$this->chckmetaValueifexist();
			
		}else{
			
			echo "No pupil ID ";
			
		}
	}
	
	function chckmetaValueifexist(){
		
	include("../conect/connection.php");	
	
	$stfuidwrong = 0;// incorrect
	
	$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE pupilrefnumbr = '{$this->gt_pupil}'";
						
	//$gtdata = [];
	
	$pupildata = $conn->query($sqlpupilmeta);
		
	if ($pupildata->num_rows > 0) {

	   while($rowpupl = $pupildata->fetch_assoc()) {
		
		$this->sch_u_id    = $rowpupl["schuid"];
		$this->gt_clas     = $rowpupl["presentclass"];
		$this->gt_cls_arm  = $rowpupl["classalias"];
		
		//$this->getinitdata[] = $rowpupl; //do not keep pupiul dataload - already exists
			
        }
			$this->pullAttnload();
	}else{
		
		$this->getinitdata[] = $stfuidwrong;
		echo json_encode($this->getinitdata);
	}
	
	$conn->close();
	}

	
	//pull attendances by date 
	
	function pullAttnload(){
	include("../conect/connection.php");
	$attndnotset = -1;
	$sqlpullattn = "SELECT absentees from scwkattendance WHERE DATE(entrydate) = '{$this->gtdates}' AND  schuid = '{$this->sch_u_id}' AND pupilclass = '{$this->gt_clas}' AND pupilarm = '{$this->gt_cls_arm}' ORDER BY entrydate DESC LIMIT 2";

			$resultattndata = $conn->query($sqlpullattn);
				$attnsload = [];
				if ($resultattndata->num_rows > 0) {
					
					while($rowattnmeta = $resultattndata->fetch_assoc()) {
					
					////////////////					
					$absents = $rowattnmeta["absentees"];
									
					//$attnsload[] = $this->splitAbsenteesUid($absents);
					$this->getinitdata[] = $this->splitAbsenteesUid($absents);
					
					}
						
					//$this->getinitdata[] = $attnsload;

				}else{
						
			$this->getinitdata[] = $attndnotset;
			
		  }
		  echo json_encode($this->getinitdata);
	$conn->close();

	}
	
	function splitAbsenteesUid($val){
		
		$hold = explode(",",$val);
		
		//return $hold;
		
		if(in_array($this->gt_pupil,$hold)){
			
			return 0;
			
		}else if($val == 0){
			
			return 1;
			
		}else{
			
			return 9;
			
		}
		
	}
}

//print_r($_POST);

$gtdate     = $_POST['chk_pupl_attn_by_date'];
$gtpupilid  = $_POST['gt_pupl_id'];

new GuardianDatadated($gtdate,$gtpupilid);