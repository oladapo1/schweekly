//refactor chkLoad_ifempty function to a single file and pass argument to parameter

var getSigneeLoad = document.getElementById("signee_id");
//alert("ok");

getSigneeLoad.onclick = chkLoad_ifempty;

function chkLoad_ifempty(){

var gtSigneeSchName = document.getElementById("seSchoolnameId").value;
var gtSigneecountry = document.getElementById("schownercountry").value;
var gtSigneeEmail = document.getElementById("seEmailId").value;
var gtSigneeTel = document.getElementById("seTelefId").value;
var gtSigneePwd = document.getElementById("seSchoolpwd").value;

if(gtSigneeSchName == "" || gtSigneecountry == "" || gtSigneeEmail == "" || gtSigneePwd == "" || gtSigneeTel == ""){
	
	alert("All fields are required");
	document.getElementById("seSchoolnameId").focus();
	return false;
	
	}//else{
		
		//muv_signee_Up(gtSigneeSchName,gtSigneecountry,gtSigneeEmail,gtSigneeTel,gtSigneePwd);
	//}
	
	let vlidatemail = ValidateEmail(gtSigneeEmail);
	
	if(vlidatemail){
		
		//console.log("correctly formed email");
		muv_signee_Up(gtSigneeSchName,gtSigneecountry,gtSigneeEmail,gtSigneeTel,gtSigneePwd);
		
	}else{
		alert("wrongly formed email");
		console.log("wrongly formed email");
	}

}

//validate-email
function ValidateEmail(inputText){
var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	if(inputText.match(mailformat))
		{
		return true;
		}
		else
		{
		return false;
		}
}


function muv_signee_Up(schlname,countryname,emailr,telf,passkeyr){
	
	//console.log(emailr+passkeyr+telf+schlname+countryname);
	//return false;
	document.getElementById("respsignup").style.display = "block";

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			//console.log(xhttp.responseText);

			let resp = xhttp.responseText;
			
			if(resp == -1){
				alert("Email exist");
				location.reload();
			}else if(resp == 1){
				//alert("Sent");
				document.getElementById("respspan").innerHTML = "details sent";
				document.getElementById("respsignup").style.display = "none";
				setTimeout(refreshPage,3000);
			}else if(resp == 2){
				alert("Incomplete fields");
				location.reload();
			}else{
				
				alert(xhttp.responseText);
				
			}			
    	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","assets/scripts/auth/signup_proced.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_sg_schname=" +schlname +"&send_ctryname=" +countryname  +"&send_sg_email=" +emailr +"&send_sg_tel=" +telf + "&send_sg_pwd=" +passkeyr);
	
}

function refreshPage(){
	
	location.reload();
}




