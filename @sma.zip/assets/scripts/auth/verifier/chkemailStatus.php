<?php
class SignChkStatusNew{
private $emailed;
function __construct($eml_usrs){
		$this->emailed = $eml_usrs;
		//echo $this->emailed; //die();
	}
function SignChkStatusNow(){
	
			include("../conect/connection.php");
	$query = "SELECT email FROM signupnew WHERE email = '$this->emailed'";
			
			$data = $conn->query($query);
		
		if ($data->num_rows == 0){
		
			return true; //"Email does not exist";
			//print "ok ".$this->emailed;

		}
	else{
		
		return false; //"Email Exists,kindly use another";
		//print "not ok";
		
	} 
$conn->close();
}
		/* --- --------------------------------------*/
				
}