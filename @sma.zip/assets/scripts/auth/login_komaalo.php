<?php
require_once('login_verifyifstatus.php'); //verify if acct verified/activated
class AppLoginUser{
	
	private $gtuseremail;
	private $gtuserpwd;
	//private $gtusrsessid;

	function __construct($usernemaile,$userpwd){
		
		$this->gtuseremail = $usernemaile;
		$this->gtuserpwd = $userpwd;
		//$this->gtusrsessid = $usrsessid;
		$this->getEmlandVerifyPWD();
		
	}

	function getEmlandVerifyPWD(){
		$pwdrex = 0;
		$usernonexist = 3;
		$getinitloginresult = array();
		include("../conect/connection.php");
		$query = "SELECT schuid,userpwd FROM signupnew WHERE email = '$this->gtuseremail'";
				
				$data =  $conn->query($query);
			
			if ($data->num_rows == 0){
			
				//return true;
				//print "User does not exist";
				$getinitloginresult[] = $usernonexist;
			echo json_encode($getinitloginresult);
			exit();
			}
		else{
			
			$row = $data->fetch_assoc();
			$pwdTblhashed = $row["userpwd"];
			
			//check if password is incorrect
			if($pwdTblhashed !== $this->gtuserpwd){
				$getinitloginresult[] = $pwdrex;
			echo json_encode($getinitloginresult);
			exit();
			}
			/* verify password using password_verify function*/
			//if(password_verify($this->gtuserpwd,$pwdTblhashed)){
				
			new LoginChkVerifiedStatus($this->gtuseremail,$row["schuid"]);
			
	} 
	$conn->close();
	}
} 


//print_r($_POST);

$gtUnamed       = trim($_POST['send_lg_Uname']);
$gtPasskey      = trim($_POST['send_lg_Pwd']);
//$gtloginsession = $_POST['loginmusession'];


new AppLoginUser($gtUnamed,$gtPasskey);