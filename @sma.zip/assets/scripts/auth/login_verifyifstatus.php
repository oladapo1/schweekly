<?php
//session_start();
require_once('schprofileinit.php');
//require_once('../app/auth/sessionslogr.php');
class LoginChkVerifiedStatus{

private $emailed;
private $userverifiedId;
//private $usersessnId;

function __construct($eml_usrs,$userverifiedId){
		$this->emailed = $eml_usrs;
		$this->userverifiedId = $userverifiedId;
		//$this->usersessnId = $usersessid;
		//echo $this->usersessnId;
		$this->LoginChkStatusNow();
	}
/* --- ----------------------------------- */
function LoginChkStatusNow(){
	
		$usernotyetverified     = -1;
		$userverifiedstatusgood = 1;
		$verifystatusunknown    = 2;
		$gtinitresult = array();
		include("../conect/connection.php");
		$query = "SELECT schuid,staffrefnumbr,verifystatus FROM signupnew WHERE email = '$this->emailed' AND schuid = '$this->userverifiedId'";
				
			$data =  $conn->query($query);
			//$gtdata = [];
			$row = $data->fetch_assoc();
			$uerverfiedstate = $row["verifystatus"];
			/* verify states*/
					if($uerverfiedstate == 0 || $uerverfiedstate == null){
						$gtinitresult[] = $usernotyetverified;
						echo json_encode($gtinitresult);	//not yet verified		
					}elseif($uerverfiedstate == 1){
						 
						 // init sch profilre tbl with schuuid
						$myprofile = new SchProfiller($row["schuid"]);
						$resp = $myprofile->chckIfSchuidexist($row["schuid"]);
																		
						if($resp == 1){
							
							
						    $gtinitresult[] = array($row);//$row["schuid"];
							//$gtinitresult[] = $userverifiedstatusgood; // verified							 
							 
						// plug-in session uid
						//$pluginsessid = new Loginsessionlogr($row["schuid"]);
							 
							 echo json_encode($gtinitresult);
						 }else if($resp == -1){
							 $gtinitresult[] = $userverifiedstatusgood; // Initialized and verified 
						     $gtinitresult[] = $row["schuid"];	
							 echo json_encode($gtinitresult);
							 
						 }else{
						  $gtinitresult[] = $verifystatusunknown;
						  echo json_encode($gtinitresult);//"Your verified state is unknown";
							 
						 }
						
					}else{
						$gtinitresult[] = $verifystatusunknown;
						echo json_encode($gtinitresult);//"Your verified state is unknown";
					}
	$conn->close();
	}				
}