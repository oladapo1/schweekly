<?php
class VerifyEmaile{
	
	private $verifystring;
	private $verifyemail;
	
	function __construct($gtverifystring,$gtemail){
		$this->verifystring = $gtverifystring;
		$this->verifyemail = $gtemail;
		/* print $this->verifystring." in verify email constructor". $this->verifyemail; die(); */
		$this->sendEmail();
	}
	/* echo $verify_url."?email=".$safe_email."&verify_string=".$verify_string; */
	function sendEmail(){
		
		//$verify_string = $this->verifystring;
		$verify_string = urlencode($this->verifystring);
		$safe_email = urlencode($this->verifyemail);
		$verify_url = "https://www.invoiceipt.com.ng/invoiceipverifyschool.php";

		$mail_body = <<<_MAIL_

		To $this->verifyemail:
		Please click on the following link to verify your account:
		$verify_url?email=$safe_email&verify_string=$verify_string
		try to verify your account in the next seven days to avoid deletion.
_MAIL_;

		mail($this->verifyemail,"User Verification",$mail_body);
		
	}
}

