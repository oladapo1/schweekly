<?php
require_once('insert_signupdetails.php');
	
class SignUpNewUsers{

private $usernemaile;
private $userpwd;

function __construct($usernemaile,$userpwd){

	$this->usernemaile = trim($usernemaile);
	$this->userpwd     = trim($userpwd);
	self::doInsertionDetails();
}

function doInsertionDetails(){
	
		$newSignee = new SendDetailsNow($this->usernemaile,$this->userpwd);
	
}

}