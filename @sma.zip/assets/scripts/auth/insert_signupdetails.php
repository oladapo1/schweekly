<?php
require_once('pwdChecker.php');
require_once('newregistration_email_auto.php');
require_once('../common/randcodegennr2.php');
//require_once('../common/verifystringmaker.php');
class SendDetailsNow{
	
	private $schoolname;
	private $urcountry;
	private $emailo;
	private $telfo;
	private $pwdo;
	private $newUID;
	
	
function __construct($sch_nme,$con_try,$em_ail,$tel_fo,$ps_wd){
		
		$this->schoolname = $sch_nme;
		$this->urcountry  = $con_try;
		$this->emailo     = $em_ail;
		$this->telfo      = $tel_fo;
		$this->pwdo       = $ps_wd;
		
		$this->chkPwdStatus();
	}
//further password check
function chkPwdStatus(){
	if(empty($this->pwdo)){
			echo"password cannot be empty!";
		exit();
	}
	else{
	
			$checkPwd = new CheckPassword($this->pwdo);
			$passwordOK = $checkPwd->check();
			if($passwordOK){
			
			$this->sendDetlsNow();//finally send details
			
			} else {
			$result = $checkPwd->getErrors();
			}
			if (isset($result)) {
			foreach ($result as $item) {
			echo "$item";
				}

			}
	    }
}
	////////////////////////// Details sent successfully ... kindly login to activate account and continue.
	

function sendDetlsNow(){
		$signupstatus = 1;
		$imcompflds   = 2;
		include("../conect/connection.php");
		
		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time()); // datetime('now')
		if(!empty($this->emailo) || !empty($this->pwdo)){
				
		////////////////////////////////////////////
		//$dewy   = new Verifystringgen;
		//$this->newverifystring = $dewy->generateVerifyString();  
		$newUID = new Randomuiidgen; //generate unique ID for schuid
		$this->newUID = $newUID->createUID();
			//do a full insert query invoicerysignup
						$query = "INSERT INTO signupnew (userschoolname,usercountryname,email,telf,userpwd,schuid,entrydate) VALUES ('$this->schoolname','$this->urcountry','$this->emailo','$this->telfo','$this->pwdo','$this->newUID','$mklogdindatetime')";
			if($conn->query($query) === TRUE) {
						 //$sendnewregtoemail = new VerifyEmaile($this->newverifystring,$this->emailo);
						//echo "your details sent successfully";
						echo $signupstatus;

				}else {
				echo "Error: ";// . $query . "<br>" . $conn->error;
			} 
			//full insert query ends
	}else{
		//print"please complete all fields";
		echo $imcompflds;
	}
				
	//close connection
		$conn->close();		
			
	}
}