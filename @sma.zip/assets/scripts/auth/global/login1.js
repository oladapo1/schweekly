var glbLoginadmin = document.getElementById("adminglbsbtn");
var glbLoginstf   = document.getElementById("globalstfbtn");

glbLoginadmin.addEventListener("click",chkloginglb_ifempty,false);
glbLoginstf.addEventListener("click",chkStf_ifempty,false);

function chkloginglb_ifempty(){

let gtLoginPasskey = document.getElementById("adminpwd_glb").value;
let gtLoginUname   = document.getElementById("adminemail_glb").value;

if(gtLoginUname == "" || gtLoginPasskey == ""){
	
	alert("All fields are required");
	document.getElementById("adminpwd_glb").focus();
	return false;
	
	}else{
		
		muv_login_glb(gtLoginUname,gtLoginPasskey);
	
	}
}


function chkStf_ifempty(){

let tchrLoginkey = document.getElementById("stftchrpasskey").value;

if(tchrLoginkey == ""){
	
	alert("Passkey required");
	document.getElementById("stftchrpasskey").focus();
	return false;
	
	}else{
		
		muv_login_glb(gtstatustype = "2",tchrLoginkey);
	
	}
}


function muv_login_glb(owaUname,owaPasskeyr){
		
//console.log(owaUname +"--"+owaPasskeyr); return false;

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				alert(xhttp.responseText);
				console.log( xhttp.responseText);
				//document.getElementById('verifynow').innerHTML = xhttp.responseText;
				//location.href="getstarted.php";

			}else{
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/auth/global/screapst/login_glob.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +owaUname + "&send_lg_Pwd=" +owaPasskeyr);
}