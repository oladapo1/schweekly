<?php
class AppLoginG{
	
	private $gtuserpwd;
	private $pupilsmeta;

	function __construct($userpwd){
		
		$this->gtuserpwd = $userpwd;
				
		if(isset($userpwd)){
			
		$this->chckStfPrescencexist();
			
		}else{
			
			echo "No password";
			
		}
	}
	
	function chckStfPrescencexist(){
		
	include("../../../conect/connection.php");	
	
	$pwdwrong = 0;//password incorrect
	
	$sqlchkschuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname,catype,isloginsuspended,teachrtype from staffprofile WHERE passwordstaf = '{$this->gtuserpwd}'";

	$resultgtdata = $conn->query($sqlchkschuid);
	
	$getinitdata = array();
	
	if ($resultgtdata->num_rows > 0) {

	   while($rowschmeta = $resultgtdata->fetch_assoc()) {
		
		$gtschuid = $rowschmeta["schuid"];
		$stfsname = $rowschmeta["staffsurname"];
		$stfname  = $rowschmeta["stafffname"];
		$gtclstut = $rowschmeta["classtut"];
		$gtclsarm = $rowschmeta["classarm"];
		$gtcatype = $rowschmeta["catype"];
		$stafrefid  = $rowschmeta["staffrefnumbr"];
		$suspndstat = $rowschmeta["isloginsuspended"];
				
		if($gtcatype == 1){
			//admin
			$getinitdata[] = array($rowschmeta);
			
		}else if($gtcatype == 2){
			//teachers
			$stfdtails = array($rowschmeta);			
			$getinitdata[] = $stfdtails;

			/////////////////////////
			
			$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$gtschuid}' AND presentclass = '{$gtclstut}' AND classalias = '{$gtclsarm}'";
			
			$stfnotset = 3;//staff has no pupil yet
			$gtdata = [];		
			$pupildata = $conn->query($sqlpupilmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
						$gtdata[] = $rowpupl;	
						
						$gtfname = $rowpupl["pupilsfname"];
						$gtsname = $rowpupl["pupilssurname"];
						$gtref   = $rowpupl["pupilrefnumbr"];
						}
						
						$getinitdata[] = $gtdata;
						//echo json_encode($getinitdata);
					}else{

			//echo $stfnotset;//staff not set
			$getinitdata[] = $stfnotset;
		//echo json_encode($getinitdata);
		  }
			///////////////////////////
			
		}
							
   }
			echo json_encode($getinitdata);	
	}else{
		
		$getinitdata[] = $pwdwrong;
		echo json_encode($getinitdata);
	}
	
	$conn->close();
}


/* function chckifTcherexist($gtschuid,$classtut,$clasalias){
	
				/////////////////////////////////
		
	include("../../../conect/connection.php");

			$conn->close();
	}*/
}  

//print_r($_POST);

$gtPasskey = trim($_POST['send_lg_Pwd']);

new AppLoginG($gtPasskey);