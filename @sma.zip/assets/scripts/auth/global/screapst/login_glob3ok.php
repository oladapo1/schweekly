<?php
class AppLoginG{
	
	//private $gtuseremail;
	private $gtuserpwd;
	private $pupilsmeta;

	function __construct($userpwd){
		
		//$this->gtuseremail = $usernemaile;
		$this->gtuserpwd = $userpwd;
		//$this->gtusrsessid = $usrsessid;
				
		if(isset($userpwd)){
			
			$this->chckStfPrescencexist();
			
		}else{
			
			echo "No password";
			
		}

	}
	
	
	/* $pwdrex = 0;//password incorrect
		$usernonexist = 3;
		$getinitloginresult = array(); */
	
	function chckStfPrescencexist(){
		
	include("../../../conect/connection.php");	
	
	$pwdwrong = 0;//password incorrect
	
	$sqlchkschuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname,catype,isloginsuspended from staffprofile WHERE passwordstaf = '{$this->gtuserpwd}'";

	$resultgtdata = $conn->query($sqlchkschuid);
	
	$getinitdata = array();
	
	if ($resultgtdata->num_rows > 0) {

	   while($rowschmeta = $resultgtdata->fetch_assoc()) {
		
		$gtschuid = $rowschmeta["schuid"];
		$stfsname = $rowschmeta["staffsurname"];
		$stfname  = $rowschmeta["stafffname"];
		$gtclstut = $rowschmeta["classtut"];
		$gtclsarm = $rowschmeta["classarm"];
		$gtcatype = $rowschmeta["catype"];
		$stafrefid  = $rowschmeta["staffrefnumbr"];
		$suspndstat = $rowschmeta["isloginsuspended"];
				
		
		if($gtcatype == 1){
			
			//$stfdtails = array($rowschmeta);			
			//$getinitdata[] = $stfdtails;
			$getinitdata[] = array($rowschmeta);
			//$this->chckifAdminexist();
			//echo "Admin..".$gtcatype;
			
		}else if($gtcatype == 2){
			
			//$this->chckifTcherexist($gtschuid,$gtclstut,$gtclsarm);
			//$getinitdata[] = $rowschmeta;
			
			$stfdtails = array($rowschmeta);			
			$getinitdata[] = $stfdtails;

			/////////////////////////
			
			$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$gtschuid}' AND presentclass = '{$gtclstut}' AND classalias = '{$gtclsarm}'";
					// AND presentclass = '{$classtut}' AND classalias = '{$clasalias}'
			
			//$schstate = 2; 
			$stfnotset = -1;
			$gtdata = [];		
			$pupildata = $conn->query($sqlpupilmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
						//$getinitdata[] = array($rowpupl);					
						$gtdata[] = $rowpupl;	
						//$json .= '{"schyid":"' . $rowpupl["pupilrefnumbr"] . '","fname":"' . $rowpupl["pupilsfname"]. '","surnsme":"' . $rowpupl["pupilssurname"] .'","class":' . $rowpupl["presentclass"].'},';

						$gtfname = $rowpupl["pupilsfname"];
						$gtsname = $rowpupl["pupilssurname"];
						$gtref   = $rowpupl["pupilrefnumbr"];
						
						//echo json_encode($rowpupl);
						
						
					/* 	$getinitdata = array(
			
								//"pupilsmeta" => $rowpupl
								
								//$this->pupilsmeta  => array($rowpupl)
								//"pupilsmeta"  => array($rowpupl)
								
								"meat" => array(),
								'vegetables' => array(
								"pupilfirstname"  => $gtfname,
								"pupilsurname"  => $gtsname,
								//"pupilrefuid"  => $gtref
								)

								); */

						}
						$getinitdata[] = $gtdata;
						//echo json_encode($getinitdata);
					}else{

			echo $stfnotset;//staff not set
		  }
			///////////////////////////
			
		}
		
				
				//echo json_encode($getinitdata);
					
   }
			echo json_encode($getinitdata);	
	}else{
		
		$getinitdata[] = $pwdwrong;
		echo json_encode($getinitdata);
	}
	
	$conn->close();
}


function chckifTcherexist($gtschuid,$classtut,$clasalias){
	
				/////////////////////////////////
		
	include("../../../conect/connection.php");	

					

			$conn->close();
	}

} 

//print_r($_POST);

$gtPasskey  = trim($_POST['send_lg_Pwd']);
//$gtloginsession = $_POST['loginmusession'];

new AppLoginG($gtPasskey);