<?php
//session_start();
require_once('schprofileinit.php');
//require_once('../app/auth/sessionslogr.php');
class LoginChkVerifiedStatus{

private $emailed;
private $userverifiedId;
//private $usersessnId;

function __construct($eml_usrs,$userverifiedId){
		$this->emailed = $eml_usrs;
		$this->userverifiedId = $userverifiedId;
		//$this->usersessnId = $usersessid;
		//echo $this->usersessnId;
		$this->LoginChkStatusNow();
	}
/* --- ----------------------------------- */
function LoginChkStatusNow(){
	
		$usernotyetverified     = -1;
		$userverifiedstatusgood = 1;
		$verifystatusunknown    = 2;
		$gtinitresult = array();
		include("../conect/connection.php");
		$query = "SELECT signeeuid,verifystatus FROM signupnew WHERE email = '$this->emailed' AND signeeuid = '$this->userverifiedId'";
				
			$data =  $conn->query($query);
			
			$row = $data->fetch_assoc();
			$uerverfiedstate = $row["verifystatus"];
			/* verify states*/
					if($uerverfiedstate == 0 || $uerverfiedstate == null){
						$gtinitresult[] = $usernotyetverified;
						echo json_encode($gtinitresult);	//not yet verified		
					}elseif($uerverfiedstate == 1){
						 
						 // init sch profilre tbl with schuuid
						$myprofile = new SchProfiller($row["signeeuid"]);
						$resp = $myprofile->chckIfSchuidexist($row["signeeuid"]);
																		
						if($resp == 1){
							 $gtinitresult[] = $userverifiedstatusgood; // verified
						     $gtinitresult[] = $row["signeeuid"];
							 
						// plug-in session uid
						//$pluginsessid = new Loginsessionlogr($row["signeeuid"]);
							 
							 echo json_encode($gtinitresult);
						 }else if($resp == -1){
							 $gtinitresult[] = $userverifiedstatusgood; // Initialized and verified 
						     $gtinitresult[] = $row["signeeuid"];	
							 echo json_encode($gtinitresult);
							 
						 }else{
						  $gtinitresult[] = $verifystatusunknown;
						  echo json_encode($gtinitresult);//"Your verified state is unknown";
							 
						 }
						
					}else{
						$gtinitresult[] = $verifystatusunknown;
						echo json_encode($gtinitresult);//"Your verified state is unknown";
					}
	$conn->close();
	}				
}