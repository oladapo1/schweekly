<?php
//require_once('login_verifyifstatus.php'); //verify if acct verified/activated
class AppLoginG{
	
	private $gtuseremail;
	private $gtuserpwd;
	private $pupilsmeta;

	function __construct($usernemaile,$userpwd){
		
		$this->gtuseremail = $usernemaile;
		$this->gtuserpwd = $userpwd;
		//$this->gtusrsessid = $usrsessid;
		
		//echo $usernemaile;die();
		
		if($usernemaile == 2){
			
			$this->chckifTcherSchuidexist();
			
		}else{
			
			$this->getEmlandVerifyPWD();
			
		}

	}

	function getEmlandVerifyPWD(){
		$pwdrex = 0;//password incorrect
		$usernonexist = 3;
		$getinitloginresult = array();
		include("../../../conect/connection.php");
		$query = "SELECT schuid,signeeuid,userpwd FROM signupnew WHERE email = '$this->gtuseremail' OR userpwd = '{$this->gtuserpwd}'";
				
				$data =  $conn->query($query);
			
			if ($data->num_rows == 0){
			
				//return true;
				//print "User does not exist";
				$getinitloginresult[] = $usernonexist;
			echo json_encode($getinitloginresult);
			exit();
			}
		else{
			
			$row = $data->fetch_assoc();
			$pwdTblhashed = $row["userpwd"];//todo
			
			//check if password is incorrect
			if($pwdTblhashed !== $this->gtuserpwd){
				$getinitloginresult[] = $pwdrex;
			echo json_encode($getinitloginresult);
			exit();
			}else{
				
				echo "fine";
			}
			
			/* verify password using password_verify function*/
			//if(password_verify($this->gtuserpwd,$pwdTblhashed)){
				
			//new LoginChkVerifiedStatus($this->gtuseremail,$row["signeeuid"]);
			
	}
	
	$conn->close();
	}
	
	function chckifTcherSchuidexist(){
	
	$getinitdatax = array();
	
	include("../../../conect/connection.php");
	$schstate = 2; $stfnotset = -1;
	
	
	$sqlchkschuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname,isloginsuspended from staffprofile WHERE passwordstaf = '{$this->gtuserpwd}'";

	$resultgtdata = $conn->query($sqlchkschuid);
	//$getinitdata;
	$json = '[';
	if ($resultgtdata->num_rows > 0) {

	   while($rowschmeta = $resultgtdata->fetch_assoc()) {
		
		$gtschuid = $rowschmeta["schuid"];
		$gtclstut = $rowschmeta["classtut"];
		$gtclsarm = $rowschmeta["classarm"];
		
		$getinitdatak = array(
		
		"catype" => $schstate,
		"meat" => array()
		
		);

				//$getinitdata[] = $schstate;
				//echo json_encode($getinitdata);
					
			}
			
					/////////////////////////////////
					
		$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$gtschuid}'";
				
				
		$pupildata = $conn->query($sqlpupilmeta);
		//$pupilsmeta = array();				
			if ($pupildata->num_rows > 0) {
				while($rowpupl = $pupildata->fetch_assoc()) {
		   					
					$getinitdatav[] = $rowpupl;					
					
					$json .= '{"schyid":"' . $rowpupl["pupilrefnumbr"] . '","fname":"' . $rowpupl["pupilsfname"]. '","surnsme":"' . $rowpupl["pupilssurname"] .'","class":' . $rowpupl["presentclass"].'},';
					
					
					//$pupilsmeta .= json_encode($rowpupl);
					$gtfname = $rowpupl["pupilsfname"];
					$gtsname = $rowpupl["pupilssurname"];
					$gtref   = $rowpupl["pupilrefnumbr"];
					
					//echo json_encode($rowpupl);
					
					//$getinitdatac[] = array("pupilfirstname"=>$gtfname,$gtsname,$gtref);
					
					$getinitdata = array(
		
							//"pupilsmeta" => $rowpupl
							
							//$this->pupilsmeta  => array($rowpupl)
							//"pupilsmeta"  => array($rowpupl)
							
							"meat" => array(),
							'vegetables' => array(
							"pupilfirstname"  => $gtfname,
							"pupilsurname"  => $gtsname,
							//"pupilrefuid"  => $gtref
							)

							);
					
						//echo json_encode($getinitdata);
															
			
						//$getinitdataz;
					}
					
					//echo json_encode($rowpupl);
					//echo json_encode($getinitdatac);
					//echo json_encode($getinitdataz);
					
					//echo $count($getinitdata);
					//echo json_encode($getinitdata);				
					//echo json_encode($getinitdatav);
		   }
		   		/////////////////////
			
			$getinitdatav[] = array(
		
					"catype" => $schstate,
					"meat" => array()
					
					);
			
	   }else{

		//todo	echo"Not yet initialized in profile list";
		
		//self::initProfilestates(); //now initialize a schuid instance for profile entry
		echo $stfnotset;
	}				
	
					$getinitdatak = array(
		
					"catype" => $schstate,
					"meat" => array()
					
					);

					echo json_encode($getinitdatav);
					
					$json .= json_encode($getinitdatak)."}";
					$json = substr($json, 0, -1);
					$json .= ']';						
					echo $json;
					
		$conn->close();
	
}
} 

//print_r($_POST);

$gtUnamed   = trim($_POST['send_lg_Uname']);
$gtPasskey  = trim($_POST['send_lg_Pwd']);
//$gtloginsession = $_POST['loginmusession'];

new AppLoginG($gtUnamed,$gtPasskey);