<?php
class SchweekData{
	
	private $gtadminid;
	private $sch_u_id;
	private $gt_clas;
	private $gt_clas_arm;
	private $pupilsmeta;

	function __construct($gtadminid,$gtschid,$gtclass,$gtclsarm){
		
		$this->gtadminid   = $gtadminid;
		$this->sch_u_id    = $gtschid;
		$this->gt_clas     = $gtclass;
		$this->gt_clas_arm = $gtclsarm;
				
		if(isset($gtadminid)){
			
		$this->chckStfPrescencexist();
			
		}else{
			
			echo "No Staff ID ";
			
		}
	}
	
	function chckStfPrescencexist(){
		
	include("../../../conect/connection.php");	
	
	$stfuidwrong = 0;// incorrect
	
	$sqlchkstfuid = "SELECT schuid,staffrefnumbr,classtut,classarm,staffsurname,stafffname,catype,isloginsuspended from staffprofile WHERE staffrefnumbr = '{$this->gtadminid}'";

	$resultgtdata = $conn->query($sqlchkstfuid);
	
	$getinitdata = array();
	
	if ($resultgtdata->num_rows > 0) {

	   while($rowschmeta = $resultgtdata->fetch_assoc()) {
		
		$gtschuid   = $rowschmeta["schuid"];
		$stfsname   = $rowschmeta["staffsurname"];
		$stfname    = $rowschmeta["stafffname"];
		$gtclstut   = $rowschmeta["classtut"];
		$gtclsarm   = $rowschmeta["classarm"];
		$gtcatype   = $rowschmeta["catype"];
		$stafrefid  = $rowschmeta["staffrefnumbr"];
		$suspndstat = $rowschmeta["isloginsuspended"];
				
		if($gtcatype == 1){
			
			$getinitdata[] = array($rowschmeta);
			
		}
			/////////////////////////
								
			$sqlpupilmeta = "SELECT schuid,presentclass,classalias,pupilsfname,pupilssurname,pupilrefnumbr from pupilsprofile WHERE schuid = '{$this->sch_u_id}' AND presentclass = '{$this->gt_clas}' AND classalias = '{$this->gt_clas_arm}'";
			
			$pupilsnotset = -1;
			
			$gtdata = [];		
			$pupildata = $conn->query($sqlpupilmeta);

				if ($pupildata->num_rows > 0) {
					while($rowpupl = $pupildata->fetch_assoc()) {
						
						$gtdata[] = $rowpupl;	
												
						}
						$getinitdata[] = $gtdata;
						//echo json_encode($getinitdata);

					}else{

			//echo $pupilsnotset;//there is no pupil data available for display
			$getinitdata[] = $pupilsnotset;
		//echo json_encode($getinitdata);
		  }
			///////////////////////////				
     }
			echo json_encode($getinitdata);	
	}else{
		
		$getinitdata[] = $stfuidwrong;
		echo json_encode($getinitdata);
	}
	
	$conn->close();
	}
}	

//print_r($_POST);

$gtadminid  = $_POST['snd_admin_id'];
$gtschid    = $_POST['snd_schid'];
$gtclass    = $_POST['snd_class'];
$gtclsarm   = $_POST['snd_classarm'];

new SchweekData($gtadminid,$gtschid,$gtclass,$gtclsarm);