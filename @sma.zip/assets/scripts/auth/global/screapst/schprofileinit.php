<?php
//session_start();
class SchProfiller{

private $userverifiedId;
//private $loginsesion;

function __construct($usrverified_Id){
	
	$this->userverifiedId = $usrverified_Id;
	self::chckIfSchuidexist();
}


function chckIfSchuidexist(){
	
	include("../conect/connection.php");
	$schstate = 1; $schuidewlyset = -1;
	$sqlchkschuid = "SELECT schuid from schoolprofile WHERE schuid = '{$this->userverifiedId}'";

	$resultgtdata = $conn->query($sqlchkschuid);

	if ($resultgtdata->num_rows > 0) {

	   while($rowrchkr = $resultgtdata->fetch_assoc()) {
		
		$gtuid = $rowrchkr["schuid"];
		
				if($gtuid == $this->userverifiedId){
					
					return $schstate; //already exist
				}
			}
	   }else{

		//todo	echo"Not yet initialized in profile list";
		
		self::initProfilestates(); //now initialize a schuid instance for profile entry
		return $schuidewlyset;
	}
		$conn->close();
	
}

function initProfilestates(){
		
		include("../conect/connection.php");
		$userprofileinitgood = 14;

		$query = "INSERT INTO schoolprofile (schuid) VALUES ('$this->userverifiedId')";
				if ($conn->query($query) === TRUE) {					 	
						//echo $userprofileinitgood;
						//echo "Sch init successfully ";

				}else {
				echo "Error: ";// . $query . "<br>" . $conn->error;
			}
			
	$conn->close();
	}				
}