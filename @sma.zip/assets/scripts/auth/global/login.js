var glbLoginstf   = document.getElementById("globalstfbtn");
glbLoginstf.addEventListener("click",chkStf_ifempty,false);

let replbl = document.getElementById("loginresp");
let tchrLogin_key = document.getElementById("stftchrpasskey");

function chkStf_ifempty(){

let tchrLoginkey = document.getElementById("stftchrpasskey").value;

if(tchrLoginkey == ""){
	
	//alert("Passkey required");
	//replbl.style.display = "block";
	replbl.innerHTML = "Passkey required";
	setTimeout(function(){
		replbl.innerHTML = "";
	},2000);
	document.getElementById("stftchrpasskey").focus();
	return false;
	
	}
	
	if(tchrLoginkey.length < 8){
	
	replbl.innerHTML = "Passkey cannot be less than 8";
	setTimeout(function(){
		replbl.innerHTML = "";
		tchrLoginkey = "";
	},2000);
		
	}
	
	else{
		
		muv_login_glb(tchrLoginkey);
	
	}
}


function muv_login_glb(owaPasskeyr){
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			console.log(xhttp.responseText);
			
			let initresp = JSON.parse(xhttp.responseText);
			//console.log(initresp.length);return false;
			
			if(initresp[1] == 3){
				console.log("This teacher has no pupils set in table yet");
				replbl.innerHTML = "This teacher has no pupils to view";
				setTimeout(function(){
					replbl.innerHTML = "";
					tchrLogin_key.value = "";
				},4000);
				return false;
			}
			
			if(initresp[0] == 0){
				
				replbl.innerHTML = "User not found";
				setTimeout(function(){
					replbl.innerHTML = "";
					tchrLogin_key.value = "";
				},2000);
				
			}else{
							
				sessionStorage.setItem("scweeklymeta",xhttp.responseText);
				sessionStorage.setItem("Countr",0);
				location.href="attendance.html";
				//location.href="dpr.html";

			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/auth/global/screapst/login_glob.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Pwd=" +owaPasskeyr);
}  