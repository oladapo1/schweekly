<?php
require_once('insert_signupdetails.php');
require_once('verifier/chkemailStatus.php');
class ProceedToSignOps{

	private $schname;
	private $country;
	private $usernemaile;
	private $tefly;
	private $pwrod;
	
	
	function __construct($schname,$country,$usernemaile,$tefly,$pwrod){
	
	$this->schname     = $schname;
	$this->country     = $country;
	$this->usernemaile = $usernemaile;
	$this->tefly       = $tefly;
	$this->pwrod       = $pwrod;
	
	}
		
	function checkEmailStatus(){
		$emailexists = -1;
		$ChkStatus = new SignChkStatusNew($this->usernemaile);
		$gtStatus = $ChkStatus->SignChkStatusNow();
		if(isset($gtStatus) && $gtStatus == true){
			$this->muvSignupDetails($this->schname,$this->country,$this->usernemaile,$this->tefly,$this->pwrod);
			//echo "Email does not even exists, can create new account!";
		}else{
			echo $emailexists;//"Email exists!";
		}
	}
		
		function muvSignupDetails($sch_name,$cntry,$emali,$tel,$pwde){
			//$sendDetails = new SignUpNewUsers($emali,$pwde);
			$newSignee = new SendDetailsNow($sch_name,$cntry,$emali,$tel,$pwde);
		}
}

	// cehck for a token or an acountable registration sender at the login end or from the Owners end
	$gtschname = $_POST['send_sg_schname'];
	$gtcntry   = $_POST['send_ctryname'];
	$gtemail   = $_POST['send_sg_email'];
	$gtelf     = $_POST['send_sg_tel'];
	$gtlpwd    = $_POST['send_sg_pwd'];

	//print_r($_POST);
	
	$gtrqdVars = new ProceedToSignOps($gtschname,$gtcntry,$gtemail,$gtelf,$gtlpwd);
	$gtrqdVars->checkEmailStatus();