<?php
class Defaultvalues{
	
	private $sent_membr_ids;
	private $holderall = array();
	
	function __construct($schuid){
		
		$this->sent_membr_ids = $schuid;
		
		if(isset($this->sent_membr_ids)){
			
			self::pullDefaultvalues();
			
		}else{
			
			echo "School id not set";
		}
		
	}
		
	/* function collateInvoices(){} */
	
	function pullDefaultvalues(){
		
		include("../conect/connection.php"); 
		
		$sqldeftvals = "SELECT staffrefnumbr,staffsurname,stafffname,staffoname,jobdesignation,staffpix,classtut,staffqualfy,classarm from staffprofile WHERE isloginsuspended = 0  ORDER BY id DESC";
	
		$deftvals = [];
		$resultvals = $conn->query($sqldeftvals);
	if ($resultvals->num_rows > 0) {
	   while($row_1 = $resultvals->fetch_assoc()) {
		
			//$deftvals[] = $row_1;
			
			$this->holderall[] = $row_1;
			
	   }
	     
	   //$this->holderall[] = $deftvals;
	   echo json_encode($this->holderall); die();
	   
	}else{
		//echo"No values found yet";
		echo "Error: " . $sqldeftvals . "<br>" . $conn->error;
			
		}//todo
		$conn->close();

	}
}

//print_r($_POST);
$schuid = $_POST['send_sch_uid'];
//$uid    = $_POST['send_schuid'];
new Defaultvalues($schuid);