<?php
class ProductDelete{
	
	private $sent_prd_id;
	
	function __construct($prdctId){
				
		$this->sent_prd_id = $prdctId;
		self::suspendUser();
		
	}

	function suspendUser(){
	
	include("../conect/connection.php"); 

	$sql ="UPDATE staffprofile set isloginsuspended = '1' WHERE staffrefnumbr = '{$this->sent_prd_id}'";
	   
		if ($conn->query($sql) === TRUE) {
				echo "User suspended";
			} else {
				echo "Error updating record: ";// . $conn->error;
			}
	 
	$conn->close();

	}

}

//print_r($_POST);
$PrdctId = $_POST['send_membr_id'];
new ProductDelete($PrdctId);