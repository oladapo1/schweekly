<?php
class AssignStaffstatus{
	
	private $gtstfuid;
	private $gtstflag; 
	private $gtfieldtofill = array('isstaffofdweek','addtoteam','isloginsuspended');
	private $ifield;

	
	function __construct($gtstflag,$gtstfuid){
		
		//print $gtstfuid." ".$gtstflag;
			
			$i;
			
			$this->gtstfuid = $gtstfuid;
			
			
			if($gtstflag == '1'){
				//$i = 0;
				$this->ifield = $this->gtfieldtofill[0];
			}elseif($gtstflag == '2'){
				$this->ifield = $this->gtfieldtofill[1];
			}elseif($gtstflag == '3'){
				$this->ifield = $this->gtfieldtofill[2];
			}else{
				return false;//exit
			}
		
		$this->setStaffstatus();
	}

	function setStaffstatus(){
		include("../../../common/connectiondb/connection.php");

		if(!empty($this->gtstfuid)){
				
		$query = "UPDATE staffmanager SET  $this->ifield = 1 WHERE staffrefnumbr = '{$this->gtstfuid}'";
		
				if ($conn->query($query) === TRUE) {
					
					echo "updated successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
	}
	else{
		print"please staff id cannot be empty";
		return false;
	}
		
	}
}


$gtflagtype = $_POST['sendstfflagtype'];
$gtstuid = $_POST['sendstfid'];

$objSetStfstatus = new AssignStaffstatus($gtflagtype,$gtstuid);