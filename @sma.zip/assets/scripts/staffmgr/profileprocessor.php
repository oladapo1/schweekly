<?php
//session_start();
processUserProfile();

function processUserProfile(){
	
	include("../conect/connection.php"); 
	
	$editdItem     = $_POST['send_itemEdited'];
	$editdItemType = $_POST['send_itemType'];	
	$PrdctId       = $_POST['send_prdctid'];
	
	
	switch($editdItemType ){
		case ($editdItemType == "jobDescrtnedt"):
		$itemField = "jobdesignation";
		break;
		case ($editdItemType == "stafQualifcedt"):
		$itemField = "staffqualfy";
		break;
		case ($editdItemType == "stafsurNamedt"):
		$itemField = "staffsurname";
		break;
		case ($editdItemType == "staffNamedt"):
		$itemField = "stafffname";
		break;
		case ($editdItemType == "selClassTaughtedt"):
		$itemField = "classtut";
		break;
		case ($editdItemType == "classalias1edt"):
		$itemField = "classarm";
		break;
		/* case ($editdItemType == ""):
		$itemField = "";
		break; */
		default:
		print"Voops";
	}
	

$sql ="UPDATE staffprofile set $itemField = '$editdItem' WHERE staffrefnumbr = '$PrdctId'";
   
    if ($conn->query($sql) === TRUE) {
			echo "update successful";
		} else {
			echo "Error updating record: ";// . $conn->error;
		}
 
$conn->close();

}