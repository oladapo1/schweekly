<?php
/* todo */
/* check for Staff TUID / School SURN and session to activate the function herein */

//session_start();
//$chkSchSURNFieldinsession = $_SESSION["universealvar"];

require_once('stafmgretodb.php');


class StaffProfileToDBLauncher{
	/* constructor */
	function __construct($stafTitlep,$stafjDescrptnp,$stf_type,$stafSurnamep,$stafFnamep,$stafQulifcp,$stafClasstutp,$tcher_type,$stsfAssgndPwdp,$stsfcls_arm,$sch_uid){
		 
		/* call constructor in stafmgretodb directly in this constructor */
	new SendAllStaffProfilevalues($stafTitlep,$stafjDescrptnp,$stf_type,$stafSurnamep,$stafFnamep,$stafQulifcp,$stafClasstutp,$tcher_type,$stsfAssgndPwdp,$stsfcls_arm,$sch_uid);
	}
	}
	
	/* todo */
	
//print_r($_POST);

	/*rem to Sanitize and validate */
$stafTitle     = $_POST['send_staff_title'];
$stafjDescrptn = $_POST['send_staff_jdescrtn'];
$stftype       = $_POST['send_stf_type'];
$stafSurname   = $_POST['send_staff_surname'];
$stafFname     = $_POST['send_staff_fname'];
$stafQulifc    = $_POST['send_staff_qualifc'];
$stafClasstut  = $_POST['send_staff_clastot'];
$tchertype     = $_POST['send_tcher_type'];
$stsfAssgndPwd = $_POST['send_staff_pwd'];
$stsfclsarm    = $_POST['send_clas_arm'];
$schuid        = $_POST['send_sch_uid'];



new StaffProfileToDBLauncher($stafTitle,$stafjDescrptn,$stftype,$stafSurname,$stafFname,$stafQulifc,$stafClasstut,$tchertype,$stsfAssgndPwd,$stsfclsarm,$schuid);