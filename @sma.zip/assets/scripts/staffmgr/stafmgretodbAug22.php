<?php
require_once('../common/randcodegennr.php');
class SendAllStaffProfilevalues{
	
	/* contructor */
	
	private $stafTitlep;
	private $stafjDescrptnp;
	private $stafSurnamep;
	private $stafFnamep;
	private $stafQulifcp;
	private $stafClasstutp;
	private $stafClassarm;
	private $stsfAssgndPwdp;
	private $staffRFN;

	
	
	/* contructor */
	function __construct($stafTitlep,$stafjDescrptnp,$stafSurnamep,$stafFnamep,$stafQulifcp,$stafClasstutp,$stsfAssgndPwdp,$stafClsarm){
		
	$this->stafTitlep     = $stafTitlep;
	$this->stafjDescrptnp = $stafjDescrptnp;
	$this->stafSurnamep   = $stafSurnamep;
	$this->stafFnamep     = $stafFnamep;
	$this->stafQulifcp    = $stafQulifcp;
	$this->stafClasstutp  = $stafClasstutp;
	$this->stafClassarm   = $stafClsarm;
	$this->stsfAssgndPwdp = $stsfAssgndPwdp;
	
	//$this->staffRFN = "	GCS-STF-0027";
	$this->schSURN = "AO1-7774442019";
	
		//call function now to insert values
	$this->sendAllStaffProfilevaluesNow();
	}
	
	function sendAllStaffProfilevaluesNow(){
	
	include("../conect/connection.php"); // to get to this connection file,go out four levels,go in two levels
//handle all empty fields in another file and hook through function rturn value

		date_default_timezone_set("Africa/Lagos");
		$mklogdindatetime = date("Y-m-d h:i:s",time());
		
		$newUID = new Randomuiidgen; //generate unique ID for schuid
		$this->staffRFN = $newUID->createUID();
		
		if(!empty($this->staffRFN)){
		$query = "INSERT INTO staffprofile (schuid,staffrefnumbr,stafftitle,jobdesignation,staffsurname,stafffname,staffqualfy,classtut,classarm,passwordstaf,entrydate) 
		VALUES ('$this->schSURN','$this->staffRFN','$this->stafTitlep','$this->stafjDescrptnp','$this->stafSurnamep','$this->stafFnamep','$this->stafQulifcp','$this->stafClasstutp','$this->stafClassarm','$this->stsfAssgndPwdp','$mklogdindatetime')";
		
				if ($conn->query($query) === TRUE) {
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
					echo "Error: " . $query . "<br>" . $conn->error;
				}

					$conn->close();
				}
				else{
					print"please complete all fields";
					return false;
				}
					
			}

}	
?>