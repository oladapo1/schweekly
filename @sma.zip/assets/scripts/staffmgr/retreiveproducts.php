<!DOCTYPE html>
<html lang="en">

<head>
 <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.css" rel="stylesheet">
	</head>
	<body>
	
<?php
   include "connection.php";
   
 $sql =<<<EOF
      SELECT * from PRODUCTSTBL;
EOF;

   $ret = $db->query($sql);
  echo "<table class='table table-hover'>";
   echo "<thead>";
   echo "<tr class='info'>";
  echo "<th><h4><b>Id</b></h4></th>";
  echo "<th><h4><b>Products</b></h4></th>";
  echo "<th><h4><b>Price</b></h4></th>";
  echo "<th><h4><b>Quantity</b></h4></th>";
    echo "</tr>";
   echo "</thead>";
   echo "<tbody>";
   
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
	  
      echo "<tr>";
     echo "<td>". $row['ID'] ."</td>";
	 echo "<td>". $row['PRODUCTS'] ."</td>";
	 echo "<td>". $row['PRICE'] ."</td>";
	 echo "<td>". $row['QTY'] ."</td>";
	  echo "</tr>";
	  
   }
   
   echo "</tbody>";
   echo "</table>";
  // echo "Operation done successfully ";  
   
   include "closedb.php";
   
?>
	
	<!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	</body>
	</html>