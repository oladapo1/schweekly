var inputtypeflag;
/* var getsetassowkradio = document.getElementById("settchroweek");
var getshowonsitechkbox = document.getElementById('shwonsite');
var getsuspdloginchkbox = document.getElementById('suspndlogin');

 //document.getElementById('viewpwd');

//alert('ouua');
//getsetassowkradio.checked = getInputtypes;

getsetassowkradio.addEventListener("click",function(){getInputtypes(getsetassowkradio.value);});
getshowonsitechkbox.addEventListener("click",function(){getInputtypes(getshowonsitechkbox.value);});
getsuspdloginchkbox.addEventListener("click",function(){getInputtypes(getsuspdloginchkbox.value);});
 */ 
function getInputtypes(inputtype,expctdidvalue){
	
	if(inputtype == "settchroweek"){
		//alert("SOWeek "+expctdvalue);
		inputtypeflag = 1;
		setnAssignStatuses(inputtypeflag,expctdidvalue);
	}
	else if(inputtype == "shwonsite"){
		//alert("show on site "+expctdvalue);
		inputtypeflag = 2;
		setnAssignStatuses(inputtypeflag,expctdidvalue);
	}
	else if(inputtype == "suspndlogin"){
		//alert("suspend login "+expctdvalue);
		inputtypeflag = 3;
		setnAssignStatuses(inputtypeflag,expctdidvalue);
	}
	else if(inputtype == "viewpwd"){
		//alert("view pwd "+expctdvalue);
		inputtypeflag = 4;
		setnAssignStatuses(inputtypeflag,expctdidvalue);
	}
	else{
		alert("we have just a few options");
	}
}

function setnAssignStatuses(flagtype,stafid){

       if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

						alert(xmlhttp.responseText);
						//var getObj = JSON.parse(xmlhttp.responseText);					
						
				}
        };
	

xmlhttp.open("POST","rotescripts/swallowr/staffmgr/scripts/setassignstatuses.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded"); 
xmlhttp.send("sendstfflagtype="+flagtype+"&sendstfid="+stafid);     
}