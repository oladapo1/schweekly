var gtrcentpupilsbatch = document.getElementById("poststaffscontentNow");
gtrcentpupilsbatch.onclick = pushstaffsDetails;

function pushstaffsDetails(){
	//alert("OkayStaffs");	
	var gtStaffTitle = document.getElementById("stafTitle").value;
	var gtStaffJobDescrtn = document.getElementById("jobDescrtn").value;
	var gtStaffSurname = document.getElementById("stafsurName").value;
	var gtStaffFname = document.getElementById("staffName").value;
	var gtStaffOname = document.getElementById("stafoName").value;
	var gtStaffEmpDate= document.getElementById("employddate").value;
	var gtStaffPix = document.getElementById("stafPix").value;
	var gtStaffQualifc = document.getElementById("stafQualifc").value;
	var gtStaffReligion = document.getElementById("stafReligion").value;
	var gtStaffGendr = document.getElementById("stafgender").value;
	var gtStaffNation= document.getElementById("stafNation").value;
	var gtStaffState = document.getElementById("stafState").value;
	var gtStaffClasTot = document.getElementById("selClassTaught").value;
	var gtStaffAsgndPwd = document.getElementById("stafPwd").value;
			
	
	if(gtStaffSurname == "" && gtStaffClasTot == ""){
		alert("All fields required!");
		return false;
	}
	else{
		
		//alert(gtPupilsurname+" "+gtPupilsEmail);
	
		//gtrcentschoolbatch.innerHTML = "<i class='fa fa-circle-o-notch fa-spin'></i>";
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
	/* var gtrcentbatchnames = document.getElementById("name_rec").value;
	var gtrcentbatchemail = document.getElementById("email_rec").value;
	var gtrcentbatchmobile = document.getElementById("phone_rec").value;
	var gtrcentbatchmsg = document.getElementById("mssg_body").value; */
	
			/* if(xhttp.responseText!=""){
				
				gtrcentschoolbatch.innerHTML = "Details Sent";
				gtrcentbatchnames="";
				gtrcentbatchemail="";
				gtrcentbatchmobile="";
				gtrcentbatchmsg="";
				
			}else{
				gtrcentschoolbatch.innerHTML = "Details Not Sent";
				location.reload();
			} */
			alert(xhttp.responseText);
					
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","rotescripts/swallowr/staffmgr/scripts/launcher/staffmgrlauncher.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send(
"send_staff_title="+gtStaffTitle+
"&send_staff_jdescrtn="+gtStaffJobDescrtn+
"&send_staff_surname="+gtStaffSurname+
"&send_staff_fname="+gtStaffFname+
"&send_staff_oname="+gtStaffOname+
"&send_staff_empdate="+gtStaffEmpDate+
"&send_staff_pix="+gtStaffPix+
"&send_staff_qualifc="+gtStaffQualifc+
"&send_staff_relign="+gtStaffReligion+
"&send_staff_gender="+gtStaffGendr+
"&send_staff_nation="+gtStaffNation+
"&send_staff_state="+gtStaffState+
"&send_staff_clastot="+gtStaffClasTot+
"&send_staff_pwd="+gtStaffAsgndPwd
);
}
}