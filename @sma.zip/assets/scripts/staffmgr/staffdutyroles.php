<?php
class SendAllStaffProfilevalues{
	
	/* contructor */
	
	private $stafTitlep;
	private $stafjDescrptnp;
	private $stafSurnamep;
	private $stafFnamep;
	private $stafOnamep;
	private $stafEmpDatep;
	private $stafPixp;
	private $stafQulifcp;
	private $stafRelignp;
	private $stafGendrp;
	private $stafCountryp;
	private $stafStatep;
	private $stafClasstutp;
	private $stsfAssgndPwdp;

	
	
	/* contructor */
	function __construct($stafTitlep,$stafjDescrptnp,$stafSurnamep,$stafFnamep,$stafOnamep,$stafEmpDatep,$stafPixp,$stafQulifcp,$stafRelignp,$stafGendrp,$stafCountryp,$stafStatep,$stafClasstutp,$stsfAssgndPwdp){
		
	$this->stafTitlep = $stafTitlep;
	$this->stafjDescrptnp = $stafjDescrptnp;
	$this->stafSurnamep = $stafSurnamep;
	$this->stafFnamep = $stafFnamep;
	$this->stafOnamep = $stafOnamep;
	$this->stafEmpDatep = $stafEmpDatep;
	$this->stafPixp = $stafPixp;
	$this->stafQulifcp = $stafQulifcp;
	$this->stafRelignp = $stafRelignp;
	$this->stafGendrp = $stafGendrp;
	$this->stafCountryp = $stafCountryp;
	$this->stafStatep = $stafStatep;
	$this->stafClasstutp = $stafClasstutp;
	$this->stsfAssgndPwdp = $stsfAssgndPwdp;
	
	$this->staffRFN = "	GCS-STF-0027";
	/* $this->schSURN = "AO1-7774442019"; */
	
		//call function now to insert values
	$this->sendAllStaffProfilevaluesNow();
	}
	
	function sendAllStaffProfilevaluesNow(){
	
	include("../../../../common/connectiondb/connection.php"); // to get to this connection file,go out four levels,go in two levels
//handle all empty fields in another file and hook through function rturn value
		if(!empty($this->stafjDescrptnp)){
		$query = "INSERT INTO staffmanager (staffrefnumbr,stafftitle,jobdescrptn,staffsurname,stafffname,staffoname,yearstaffed,staffpix,staffqualfy,religion,gender,nationality,stateoforigstaf,classtut,passwordstaf) 
		VALUES ('$this->staffRFN','$this->stafTitlep','$this->stafjDescrptnp','$this->stafSurnamep','$this->stafFnamep','$this->stafOnamep','$this->stafEmpDatep','$this->stafPixp','$this->stafQulifcp','$this->stafRelignp','$this->stafGendrp','$this->stafCountryp','$this->stafStatep','$this->stafClasstutp','$this->stsfAssgndPwdp')";
		
				if ($conn->query($query) === TRUE) {
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
					echo "Error: " . $query . "<br>" . $conn->error;
				}

					$conn->close();
				}
				else{
					print"please complete all fileds";
					return false;
				}
					
			}

}	
?>