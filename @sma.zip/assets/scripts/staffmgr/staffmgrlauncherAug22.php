<?php
/* todo */
/* check for Staff TUID / School SURN and session to activate the function herein */

//session_start();
//$chkSchSURNFieldinsession = $_SESSION["universealvar"];

require_once('stafmgretodb.php');


class StaffProfileToDBLauncher{
	/* constructor */
	function __construct($stafTitlep,$stafjDescrptnp,$stafSurnamep,$stafFnamep,$stafQulifcp,$stafClasstutp,$stsfAssgndPwdp,$stsfcls_arm){
		 
		/* call constructor in stafmgretodb directly in this constructor */
	new SendAllStaffProfilevalues($stafTitlep,$stafjDescrptnp,$stafSurnamep,$stafFnamep,$stafQulifcp,$stafClasstutp,$stsfAssgndPwdp,$stsfcls_arm);
	}
	}
	
	/* todo */
	
//print_r($_POST);

	/*rem to Sanitize and validate */
$stafTitle     = $_POST['send_staff_title'];
$stafjDescrptn = $_POST['send_staff_jdescrtn'];
$stafSurname   = $_POST['send_staff_surname'];
$stafFname     = $_POST['send_staff_fname'];
$stafQulifc    = $_POST['send_staff_qualifc'];
$stafClasstut  = $_POST['send_staff_clastot'];
$stsfAssgndPwd = $_POST['send_staff_pwd'];
$stsfclsarm    = $_POST['send_clas_arm'];
 


new StaffProfileToDBLauncher($stafTitle,$stafjDescrptn,$stafSurname,$stafFname,$stafQulifc,$stafClasstut,$stsfAssgndPwd,$stsfclsarm);