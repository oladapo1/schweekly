var newregbtn = document.getElementById("newregformbtn");

newregbtn.onclick = formitemsTohandler;

function formitemsTohandler(){
	
	var lname = document.getElementById("lname").value;
	var fname = document.getElementById("fname").value;
	var dob = document.getElementById("dob").value;
	var gender = document.getElementById("selgender").value;
	var termofentry = document.getElementById("seltermofentry").value;
	var mthrname = document.getElementById("mthrname").value;
	var fthrname = document.getElementById("fthrname").value;
	var telf1 = document.getElementById("telf1").value;
	var telf2 = document.getElementById("telf2").value;
	var emailf = document.getElementById("emailf").value;

       if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
				alert(this.responseText);
				
			}
        };

		xmlhttp.open("POST","rotescripts/swallowr/childregistrations/scripts/newchildregstr.php",true);
		xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded"); 
        xmlhttp.send("sendlname="+lname+"&sendfname="+fname+"&senddob="+dob+"&sendgender="+gender+"&sendtermofentry="+termofentry+"&sendmthrname="+mthrname+"&sendfthrname="+fthrname+"&sendtelf1="+telf1+"&sendtelf2="+telf2+"&sendemailf="+emailf);     
}