<?php
//echo $gtlastname." ".$gtentryterm." ".$gtemaile;

class NewRegofPupilToDB{
	
	private $lname;
	private $fname;
	private $pupildobrth;
	private $pupilgender;
	private $preffredtermofentry;
	private $mothername;
	private $fathername;
	private $contacttelf1;
	private $contacttelf2;
	private $contactemail;
	
	/* contructor */
	
	function __construct($lname,$fname,$pupildobrth,$pupilgender,$preffredtermofentry,$mothername,$fathername,$contacttelf1,$contacttelf2,$contactemail){
		
		$this->lname = $lname;
		$this->fname = $fname;
		$this->pupildobrth = $pupildobrth;
		$this->pupilgender = $pupilgender;
		$this->preffredtermofentry = $preffredtermofentry;
		$this->mothername = $mothername;
		$this->fathername = $fathername;
		$this->contacttelf1 = $contacttelf1;
		$this->contacttelf2 = $contacttelf2;
		$this->contactemail = $contactemail;
		
		$this->getnewPupilregisterations();
		
	}
	
	function getnewPupilregisterations(){
		include("../../../common/connectiondb/connection.php");
		if(!empty($this->lname) || !empty($this->fname) || !empty($this->contacttelf1) || !empty($this->contacttelf2) || !empty($this->mothername)){
				
		////////////////////////////////////////////
	
	$query = "INSERT INTO  childregistration (childsurname,childfname,childdob,gender,rqstdtermofentry,mothername,fathername,contacttelf1,contacttelf2,contactemail) VALUES ('$this->lname','$this->fname','$this->pupildobrth','$this->pupilgender','$this->preffredtermofentry','$this->mothername','$this->fathername','$this->contacttelf1','$this->contacttelf2','$this->contactemail')";
		
				if ($conn->query($query) === TRUE) {
					
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
			
			
}
}//class ends


$gtlastname = $_POST["sendlname"];
$gtfirstname = $_POST["sendfname"];
$gtdob = $_POST["senddob"];
$gtgendr = $_POST["sendgender"];
$gtentryterm = $_POST["sendtermofentry"];
$gtmthrname = $_POST["sendmthrname"];
$gtfaname = $_POST["sendfthrname"];
$gttelf1 = $_POST["sendtelf1"];
$gttelf2 = $_POST["sendtelf2"];
$gtemaile = $_POST["sendemailf"];


$objNerwgdata = new NewRegofPupilToDB($gtlastname,$gtfirstname,$gtdob,$gtgendr,$gtentryterm,$gtmthrname,$gtfaname,$gttelf1,$gttelf2,$gtemaile);
