<?php
/* todo */
/* check for school SURN and session to activate the function herein */

session_start();
//$chkSchSURNFieldinsession = $_SESSION["universealvar"];

require_once('../schoolprotextarefiletodb.php');

//require_once('');

class SchoolProfileToDBLauncher{
	/* constructor */
	function __construct($txtAreaSpecp,$txtAreaContentp){
		 
		/* call constructor in schoolprotextarefiletodb */
	new SendEachSchoolProfileTextareavalues($txtAreaSpecp,$txtAreaContentp);
	}
	}
	
	/* todo */
	/* rem to Sanitize and validate */
$txtAreaSpec = $_POST['send_txtarea_spec'];
$txtAreaContent = $_POST['send_txtarea_message'];



//print $welcNote." OPos";
function preSURNstatusChkNow(){
	$chkSchSURNFieldinsession = 1;
	//rem to check for SURN
	if($chkSchSURNFieldinsession == 1){
		return true;
	}	
	}

if(preSURNstatusChkNow()){
new SchoolProfileToDBLauncher($txtAreaSpec,$txtAreaContent);
}else{
	print "SURN rqd!";
}