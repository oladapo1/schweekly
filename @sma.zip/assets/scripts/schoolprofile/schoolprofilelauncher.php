<?php
/* todo */
/* check for school SURN and session to activate the function herein */

session_start();
//$chkSchSURNFieldinsession = $_SESSION["universealvar"];

require_once('../schoolprofiletodb.php');

//require_once('');

class SchoolProfileToDBLauncher{
	/* constructor */
	function __construct($schNamev,$coreValsv,$schMottov,$schSoc1v,$contPersonv,$schStatev,$schAddrline1v,$schAddrline2v,$schEmailv,$schTelfv,$schLogov,$schBanrv){
		 
		/* call constructor in schoolprofiletodb */
	new SendAllSchoolProfilevalues($schNamev,$coreValsv,$schMottov,$schSoc1v,$contPersonv,$schStatev,$schAddrline1v,$schAddrline2v,$schEmailv,$schTelfv,$schLogov,$schBanrv);
	}
	}
	
	/* todo */
	/* rem to Sanitize and validate */
$schName = $_POST['send_sch_name'];
$coreVals = $_POST['send_sch_corevals'];
$schMotto = $_POST['send_sch_motto'];
$schSoc1 = $_POST['send_sch_soc1'];
$contPerson = $_POST['send_contprsn'];
$schState = $_POST['send_sch_state'];
$schAddrline1 = $_POST['send_sch_addrL1'];
$schAddrline2 = $_POST['send_sch_addrL2'];
$schEmail = $_POST['send_sch_email'];
$schTelf = $_POST['send_sch_telf'];
$schLogo = $_POST['send_sch_logo'];
$schBanr = $_POST['send_sch_banr'];

//print $welcNote." OPos";
function preSURNstatusChkNow(){
	$chkSchSURNFieldinsession = 1;
	//rem to check for SURN
	if($chkSchSURNFieldinsession == 1){
		return true;
	}	
	}

if(preSURNstatusChkNow()){
new SchoolProfileToDBLauncher($schName,$coreVals,$schMotto,$schSoc1,$contPerson,$schState,$schAddrline1,$schAddrline2,$schEmail,$schTelf,$schLogo,$schBanr);
}else{
	print "SURN rqd!";
}