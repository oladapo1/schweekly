<?php
/* tod */
/* run test for update content - discovered that commas are clashing- chk php solution txt bk*/
class SendEachSchoolProfileTextareavalues{

		private $gtspecifictextarea;
		private $gtspecifictextareacontent;
		private $schSURN;
		private $textareafield;
		private $spectxtarea = array('welcomenote','schanthem','schoolhistory','schvision');
			
	/* constructor */
	function __construct($gtspecifictextarea,$gtspecifictextareacontent){
	
		$this->gtspecifictextarea = $gtspecifictextarea;
		$this->gtspecifictextareacontent = $gtspecifictextareacontent;
		$this->schSURN = "AO1-2224442019";
		//$this->SUID = "GCS-0014";
		
		self::sendEachSchoolProfilevaluesNow();
	}
	
		
	function sendEachSchoolProfilevaluesNow(){
		include("../../../../common/connectiondb/connection.php");
		
		
		//rework or avoid  the repetitveness of the instance variables
		if($this->gtspecifictextarea == 'postschContentwelcome'){
		$this->textareafield = $this->spectxtarea[0];
		}
		elseif($this->gtspecifictextarea == 'postschContentanthem'){
		$this->textareafield = $this->spectxtarea[1];
		}
		elseif($this->gtspecifictextarea == 'postschContenthistory'){
		$this->textareafield = $this->spectxtarea[2];
		}
		elseif($this->gtspecifictextarea == 'postschContentvision'){
		$this->textareafield = $this->spectxtarea[3];
		}
		else{
			print "not beyond this level";
		}
		
		
		if(!empty($this->gtspecifictextareacontent)){
				
		$query = "UPDATE schoolprofile SET {$this->textareafield}='$this->gtspecifictextareacontent' WHERE schrefnumber = '$this->schSURN'";
	
	
				if ($conn->query($query) === TRUE) {
					
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
			
			
}
}//class ends
?>