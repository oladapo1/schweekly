<?php
/* todo */
/* check for SURN before sending  data, also do more checks for safety*/
class SendAllSchoolProfilevalues{
	private $schNamev;
	private $coreValsv;
	private $schMottov;
	private $schSoc1v;
	private $contPersonv;
	private $schStatev;
	private $schAddrline1v;
	private $schAddrline2v;
	private $schEmailv;
	private $schTelfv;
	private $schLogov;
	private $schBanrv;
	//private $welcNotev;
	/* private $schHistryv;
	private $schVisionv;
	private $schAnthemv;
	private $schPledgev; */
	
	/* contructor */
	function __construct($schNamev,$coreValsv,$schMottov,$schSoc1v,$contPersonv,$schStatev,$schAddrline1v,$schAddrline2v,$schEmailv,$schTelfv,$schLogov,$schBanrv){
		
	$this->schNamev = $schNamev;
	$this->coreValsv = $coreValsv;
	$this->schMottov = $schMottov;
	$this->schSoc1v = $schSoc1v;
	$this->contPersonv = $contPersonv;
	$this->schStatev = $schStatev;
	$this->schAddrline1v = $schAddrline1v;
	$this->schAddrline2v = $schAddrline2v;
	$this->schEmailv = $schEmailv;
	$this->schTelfv = $schTelfv;
	$this->schLogov = $schLogov;
	$this->schBanrv = $schBanrv;
	//$this->welcNotev = $welcNotev;
	/* $this->schHistryv = $schHistryv;
	$this->schVisionv = $schVisionv;
	$this->schAnthemv = $schAnthemv;
	$this->schPledgev = $schPledgev; */
	$this->schSURN = "AO1-2224442019";
	
		//call function now to insert values
	$this->sendAllSchoolProfilevaluesNow();
	}
	
	function sendAllSchoolProfilevaluesNow(){
	//print $this->welcNotev ."  ".$this->schNamev;
	include("../../../../common/connectiondb/connection.php"); // to get to this connection file,go out four levels,go in two levels

		$query = "INSERT INTO schoolprofile (schrefnumber,schoolname,corevalues,motto,socials1,contactperson,statelocated,address1,address2,schoolemail,schooltelef,schoollogo,schoobanr1) VALUES ('$this->schSURN','$this->schNamev','$this->coreValsv','$this->schMottov','$this->schSoc1v','$this->contPersonv','$this->schStatev','$this->schAddrline1v','$this->schAddrline2v','$this->schEmailv','$this->schTelfv','$this->schLogov','$this->schBanrv')";
		
				if ($conn->query($query) === TRUE) {
					echo "your details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
	}
	
}
?>