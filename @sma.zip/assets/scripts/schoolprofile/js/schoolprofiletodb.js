var gtrcentschoolbatch = document.getElementById("postschContentnow");
gtrcentschoolbatch.onclick = puschoolDetails;

function puschoolDetails(){
	//alert("okayschoolq");	
	var gtSchname = document.getElementById("schName").value;
	var gtrCorevalues = document.getElementById("coreVals").value;
	var gtMotto = document.getElementById("schMotto").value;
	var gtrSocial1 = document.getElementById("schSoc1").value;
	var gtContactPrsn = document.getElementById("schContactPrsn").value;
	var gtSchstate = document.getElementById("selstate").value;
	var gtSchAddrL1 = document.getElementById("schAdrss1").value;
	var gtSchAddrL2 = document.getElementById("schAdrss2").value;
	var gtSchEmail = document.getElementById("schEmail").value;
	var gtSchTelef = document.getElementById("schTelf").value;
	var gtSchlogo = document.getElementById("schLogo").value;
	var gtSchBanr = document.getElementById("schBanner").value;
		
	
	if(gtSchname == "" && gtSchEmail == ""){
		alert("All fields required!");
		return false;
	}
	else{
		
		//alert(gtSchname+" "+gtMotto +" "+gtSchEmail +" " +gtWelcomeNote);
	
		//gtrcentschoolbatch.innerHTML = "<i class='fa fa-circle-o-notch fa-spin'></i>";
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
	/* var gtrcentbatchnames = document.getElementById("name_rec").value;
	var gtrcentbatchemail = document.getElementById("email_rec").value;
	var gtrcentbatchmobile = document.getElementById("phone_rec").value;
	var gtrcentbatchmsg = document.getElementById("mssg_body").value; */
	
			/* if(xhttp.responseText!=""){
				
				gtrcentschoolbatch.innerHTML = "Details Sent";
				gtrcentbatchnames="";
				gtrcentbatchemail="";
				gtrcentbatchmobile="";
				gtrcentbatchmsg="";
				
			}else{
				gtrcentschoolbatch.innerHTML = "Details Not Sent";
				location.reload();
			} */
			alert(xhttp.responseText);
					
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","rotescripts/swallowr/schoolprofile/scripts/launcher/schoolprofilelauncher.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_sch_name="+gtSchname+"&send_sch_corevals="+gtrCorevalues+"&send_sch_motto="+gtMotto+"&send_sch_soc1="+gtrSocial1+"&send_contprsn="+gtContactPrsn+"&send_sch_state="+gtSchstate+"&send_sch_addrL1="+gtSchAddrL1+"&send_sch_addrL2="+gtSchAddrL2+"&send_sch_email="+gtSchEmail+"&send_sch_telf="+gtSchTelef+"&send_sch_logo="+gtSchlogo+"&send_sch_banr="+gtSchBanr);
}
}