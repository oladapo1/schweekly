function determImgCatgor(e){
	//alert(e);
	passImgCatgotoHandler(e);
}

function passImgCatgotoHandler(filepix){
	alert(filepix +" from profile pixle");
var form = document.forms.namedItem(filepix);
form.addEventListener('onclick', function(ev) {
	
	 var folderToUpload;
	 var catgori;
	//profilepix portfolios banners
	if(filepix == "schBanner1"){
		
		folderToUpload = "profilepix";
		catgori = "myprofilepixle";
	}
	else if(filepix == ""){
		
		folderToUpload = "banners";
		catgori = "pixlbanner";
	}
	else{
		alert("Voops!");
	}
  //alert(filepix +" from profile pixle");
 
  var oOutput = document.getElementById("uploadmsg"),
      oData = new FormData(form);

  oData.append("UploadDir", folderToUpload);
  oData.append("Category", catgori);

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "owambe/ituraenishe/uploadimagebanner.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;
	  
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br \/>";
    }
  };

  oReq.send(oData);
  ev.preventDefault();
}, false);
}