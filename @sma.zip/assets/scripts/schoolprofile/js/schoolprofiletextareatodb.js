function puschoolTextareaDetails(gttextareasendr,textareaID){
//alert(gttextareasendr+' okopopoz '+textareaID);
//var gttextareacontent = tinymce.get(textareaID).getContent();
	
if(tinymce.get(textareaID).isDirty()){
	var gttextareacontent = tinymce.get(textareaID).getContent();
		//alert("content available "+gttextareacontent);
		
		processTextcontent(gttextareasendr,gttextareacontent); //call xhr funtion handler now
		
}else{
	alert("empty field");
	return false;
}

}

function processTextcontent(s,e){
	
	//alert(e +" in xhttp function");
	var gttextareasendr = s;
	var gttextareacontent = e;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200){  
				
	/* var gtrcentbatchnames = document.getElementById("name_rec").value;
	var gtrcentbatchemail = document.getElementById("email_rec").value;
	var gtrcentbatchmobile = document.getElementById("phone_rec").value;
	var gtrcentbatchmsg = document.getElementById("mssg_body").value; */
	
			/* if(xhttp.responseText!=""){
				
				gtrcentschoolbatch.innerHTML = "Details Sent";
				gtrcentbatchnames="";
				gtrcentbatchemail="";
				gtrcentbatchmobile="";
				gtrcentbatchmsg="";
				
			}else{
				gtrcentschoolbatch.innerHTML = "Details Not Sent";
				location.reload();
			} */
			alert(xhttp.responseText);
					
  	}
	};
	/* Using POST */ 
		xhttp.open("POST","rotescripts/swallowr/schoolprofile/scripts/launcher/schoolprofiletextarealauncher.php",true);
		xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		xhttp.send("send_txtarea_spec="+gttextareasendr+"&send_txtarea_message="+gttextareacontent);
	}