<?php
require_once('../mediatodb.php');
class Mediahandler{
		
	function __construct($mediatitlenamec,$mediadescrptnc,$mediauploadedc,$mediadtagsc,$mediagennotec){
		
		new MediaItemsEventsData($mediatitlenamec,$mediadescrptnc,$mediauploadedc,$mediadtagsc,$mediagennotec);
	}
	
}

$mediatitlename = $_POST['send_media_name'];
$mediadescrptn = $_POST['send_media_descrtn'];
$mediauploadedjs = $_POST['send_media_uploaded'];
$mediauploaded = $_FILES[$mediauploadedjs]['name'];
//$mediauploaded = $mediauploadedjs;
//print $mediauploaded;
$mediadtags = $_POST['send_media_tag'];
$mediagennote = $_POST['send_general_note'];

$objMediahandler = new Mediahandler($mediatitlename,$mediadescrptn,$mediauploaded,$mediadtags,$mediagennote);

