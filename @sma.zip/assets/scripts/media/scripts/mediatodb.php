<?php
class MediaItemsEventsData{
	
	private $medianame;
	private $mediadescptn;
	private $mediauploads;
	private $mediatag;
	private $mediagennotes;
	private $schSURN;
	
	
	/* contructor */
	function __construct($medianame,$mediadescptn,$mediauploads,$mediatag,$mediagennotes){
		
		$this->medianame = $medianame;
		$this->mediadescptn = $mediadescptn;
		$this->mediauploads = $mediauploads;
		$this->mediatag = $mediatag;
		$this->mediagennotes = $mediagennotes;
		$this->schSURN = "GCS-7774442019";
		
		self::getAllMediavaluestodb();
		
	}
	
	
	function getAllMediavaluestodb(){
		include("../../../../common/connectiondb/connection.php");
		
		if(!empty($this->medianame) || !empty($this->mediauploads) || !empty($this->mediatag) || !empty($this->mediadescptn) || !empty($this->mediagennotes)){
				
		////////////////////////////////////////////
		//rem to solidify follow - open/close principle to optimize here

		$query = "INSERT INTO schoolmedia (schrefnumber,medianame,mediadescription,mediauploaded,mediatag,mediageneralnote) VALUES ('$this->schSURN','$this->medianame','$this->mediadescptn','$this->mediauploads','$this->mediatag','$this->mediagennotes')";
		
				if ($conn->query($query) === TRUE) {
				 echo "your media details sent successfully";
					 //header('Refresh: 1; URL = ../../../on_boarding.php');
				}
				else {
		echo "Error: " . $query . "<br>" . $conn->error;
	}

		$conn->close();
		
		/////////////////////////////////////////////
		
	}
	else{
		print"please complete all fileds";
		return false;
	}
			
			
}
	
}//class ends 
?>