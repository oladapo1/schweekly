var gtmediabtn = document.getElementById("uploadmedia");
gtmediabtn.onclick = pushMediadetails;

function pushMediadetails(){
	//alert("OkayMedia");	
	var gtmediatype = document.getElementById("medianameid").value;
	var gtmediadescription = document.getElementById("descriptid").value;
	var gtmediatypeuploaded = document.getElementById("mediauplodid").files[0].name;
	//var gtmediatypeuploaded = document.getElementById("mediauplodid").value;
	var gtmediatag = document.getElementById("selmediatag").value;
	var gtgeneralnote = document.getElementById("generalnoteid").value;
					
	if(gtmediatag == "" && gtmediatypeuploaded == ""){
		alert("Essential fields required!");
		return false;
	}
	else{
		//determImgCatgo(gtmediatypeuploaded,gtmediatag);
		alert(gtmediatag+" "+gtmediatypeuploaded);
	
		//gtrcentschoolbatch.innerHTML = "<i class='fa fa-circle-o-notch fa-spin'></i>";
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
	/* var gtrcentbatchnames = document.getElementById("name_rec").value;
	var gtrcentbatchemail = document.getElementById("email_rec").value;
	var gtrcentbatchmobile = document.getElementById("phone_rec").value;
	var gtrcentbatchmsg = document.getElementById("mssg_body").value; */
	
			/* if(xhttp.responseText!=""){
				
				gtrcentschoolbatch.innerHTML = "Details Sent";
				gtrcentbatchnames="";
				gtrcentbatchemail="";
				gtrcentbatchmobile="";
				gtrcentbatchmsg="";
				
			}else{
				gtrcentschoolbatch.innerHTML = "Details Not Sent";
				location.reload();
			} */
			alert(xhttp.responseText);
					
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","rotescripts/swallowr/media/scripts/launcher/mediatodblauncher.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send(
"send_media_name="+gtmediatype+
"&send_media_descrtn="+gtmediadescription+
"&send_media_uploaded="+gtmediatypeuploaded+
"&send_media_tag="+gtmediatag+
"&send_general_note="+gtgeneralnote
);
}
}


function determImgCatgo(e,j){
	//alert("okin");
	//passImgCatgotoHandler(e,j);
	//document.getElementById('mediauplodid').addEventListener('click', function(e) {
  //var file = this.files[0];
  //alert(e+"--"+j);
}

function passImgCatgotoHandler(filepix,mediatag){
	//alert(filepix +" from profile pixle");
//var form = document.forms.namedItem(filepix);
//form.addEventListener('submit', function(ev){
	//alert(filepix+'///'+mediatag);
	 //var folderToUpload;
	 //var catgori;
	//profilepix portfolios banners

 
  //var oOutput = document.getElementById("uploadmsg"),
      /* oData = new FormData(filepix);
	  alert(oData.files[0].name); */

}