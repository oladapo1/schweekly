<?php
return (object) array(
'servername' => "localhost",
'username' => "id21192367_roteskyni",
'password' => "r%FFM=Cf!sC#C70p",
'dbname' => "id21192367_schoweeklydb"
);

