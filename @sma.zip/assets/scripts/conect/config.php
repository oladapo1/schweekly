<?php
return (object) array(
'servername' => "localhost",
'username' => "roteskyni",
'password' => "r%FFM=Cf!sC#C70p",
'dbname' => "schoweeklydb"
);

