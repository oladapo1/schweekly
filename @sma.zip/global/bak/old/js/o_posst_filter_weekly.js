window.addEventListener("load",function(){getOlderPosts()},false);

var getmyoldpostmnu= document.getElementById("oldpostmenu");
getmyoldpostmnu.addEventListener("click",function(){getOlderPosts()},false);
function getOlderPosts(){
	
	//alert('gteventidoptedin');

	
var gtmembersrid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersrid = gtmembersrid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			
			document.getElementById("olderpostdiv").innerHTML = this.responseText;
	
		//var myOldpoststArrytObj = JSON.parse(xhttp.responseText);
	    //var elementary_sh ="";	
	
/* 		for(i = 0; i < myOldpoststArrytObj.length; i++){
			
			alert(myOldpoststArrytObj.length);
		elementary_sh += "<tr><td>"+myOldpoststArrytObj[i].eventtitle+"</td><td>"+myOldpoststArrytObj[i].eventdate+"</td>"+"<td ><a href='#' style='margin-left:30px;' id='"+myOldpoststArrytObj[i].eventid+"' onclick='getMyeventsOptIns(this.id)' class='ui-btn ui-icon-eye ui-btn-icon-notext'>Icon only</a></td></tr>";
					
			// attache to body
			document.getElementById("listmyeventstbl").innerHTML = elementary_sh;
			 } */
            }
        };
		
	xhttp.open("POST","scripts/o_posst_filter_weekly.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_members_id="+gtmembersrid);
	//xhttp.send();
}