btnfeedbvck = document.getElementById("feedbackbtn");
btnfeedbvck.addEventListener("click",sendFeedbacktoDev,false);
function sendFeedbacktoDev(){
	let membersidt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersidt = membersidt.memberid.toString();
	
	let txtareafdbck = document.getElementById("feedbackformtxt");
	
	if(txtareafdbck.value == ""){
		alert("Feedback field required");
		return false;
	}else{
		var feedbcktxtmsg = txtareafdbck.value;
	}
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		//alert(xhttp.responseText);
		//console.log(xhttp.responseText);
		
		document.getElementById("sendrespfdbck").innerHTML = xhttp.responseText;
		setTimeout(cleanUpresp,3000);
  	}
	};
	
	 /* Using POST */	 
xhttp.open("POST","scripts/yesbatoddevfeedbvck.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_memberid="+membersidt+"&feedbckmsg="+feedbcktxtmsg);	
}

function cleanUpresp(){
	document.getElementById("sendrespfdbck").innerHTML = "";
	document.getElementById("feedbackformtxt").value = "";
	document.getElementById("feedbackformtxt").focus();
}