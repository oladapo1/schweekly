function pullmyReactions(whoreacted){
	
	//alert(whoreacted);
			
	var mymembershipeidbcasticreated = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbcasticreated = mymembershipeidbcasticreated.memberid.toString();	
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
		console.log(this.responseText);
		document.getElementById("myreactnsdiv").innerHTML = this.responseText;
		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/myreactors.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_whoreacted="+whoreacted);
}