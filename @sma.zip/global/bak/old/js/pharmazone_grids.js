window.onload = chckPCNIDexists;

function chckPCNIDexists(){

let gtpcnid = sessionStorage.getItem("pcnidstatus");
		
if(gtpcnid == null || gtpcnid != 1){
		return false;

		}else if(gtpcnid == 1){
				document.getElementById("pharmazonepills").style.display = "none";
				initLinks();					
		}else{
			alert("PCN ID not avalaible");
		}
}

let pcnidbtn = document.getElementById("pharmazonepillsbtn");
pcnidbtn.onclick = sendMembridCtype;

function sendMembridCtype(){

	let mymembercareer = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembercareer = mymembercareer.occupatntype;

	let mymemberctid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberctid = mymemberctid.memberid.toString();
	
	let pcnidtxtbox = document.getElementById("urpcnidpills").value;
	
	if(pcnidtxtbox == ""){
		
		alert("Please, no empty field for PCN id");
		//pcnidtxtbox.focus();
		return false;
	}
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			
			//alert(xhttp.responseText);
			if(xhttp.responseText == 1){
				gtresponse = xhttp.responseText;
				sessionStorage.setItem("pcnidstatus",gtresponse);
				document.getElementById("pharmazonepills").style.display = "none";	
				alert("Ride on gallantly");
				checkPCNStatus();
				//initLinks();			
			}else{
				alert("PCN Id not set, fill this in profile");
				setTimeout(location.reload(),3000);
			}
	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","../scripts/checkpcnidstatus.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_careeer=" +mymembercareer+"&user_id_member="+mymemberctid+"&send_pcnval="+pcnidtxtbox);
}


/* let pharmgrid = document.getElementById("pharmazonev");
pharmgrid.onclick = checkPCNStatus; */

function checkPCNStatus(){
	
		let mymembercareer = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
		mymembercareer = mymembercareer.occupatntype;

		let gtpcnid = sessionStorage.getItem("pcnidstatus");
		
if(gtpcnid == null || gtpcnid != 1 || mymembercareer != 0){
			//alert("Not available ");
			return false;
		}else if(gtpcnid == 1 || mymembercareer == 0){
			initLinks();
		}else{
			alert("Report to Admin");
		}
}

function initLinks(){

let btnref = document.getElementsByClassName("pharmazones");
btnref[0].addEventListener("click",function(){oncheckPCNStatusgotolink(0)},false);
btnref[1].addEventListener("click",function(){oncheckPCNStatusgotolink(1)},false);
btnref[2].addEventListener("click",function(){oncheckPCNStatusgotolink(2)},false);
btnref[3].addEventListener("click",function(){oncheckPCNStatusgotolink(3)},false);
btnref[4].addEventListener("click",function(){oncheckPCNStatusgotolink(4)},false);
btnref[5].addEventListener("click",function(){oncheckPCNStatusgotolink(5)},false);
btnref[6].addEventListener("click",function(){oncheckPCNStatusgotolink(6)},false);
btnref[7].addEventListener("click",function(){oncheckPCNStatusgotolink(7)},false);

}

var pharmzones_links = [
"#healthlog",
"#illegalspots",
"#logisticserve",
"#mediayesba",
"#nearbypharms",
"#settingsz",
"#",
"#"
];

function oncheckPCNStatusgotolink(e){
	
	location.href = pharmzones_links[e];
		
}