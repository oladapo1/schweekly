document.addEventListener("DOMContentLoaded",pullmyBcastresponsesforbubbles,false);
//setInterval(pullrecentBcastlistforbubbles,5000);
function pullmyBcastresponsesforbubbles(){

	let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();

	/* let mymembersoccupatn = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembersoccupatn = mymembersoccupatn.occupatntype;
	
	let mymembersspecializatn = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembersspecializatn = mymembersspecializatn.occuspecializatn;
	
	let mymemberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberzone = mymemberzone.zone; */
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			var obj = JSON.parse(xhttp.responseText);
			//alert(obj[1]);
			//document.getElementById("msgsbubble").innerHTML = obj[0];
			document.getElementById("mybcastsresponses").innerHTML = obj[1];
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/mybcastbubblet.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("membr_idd="+mymembershipeid);
}