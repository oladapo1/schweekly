var mycount = 0;
var geteventmenu = document.getElementById("eventmenu_m");
geteventmenu.addEventListener("click",function(){loadEvenrangeMonth()},false);
function loadEvenrangeMonth(){
	
	let my_eventlen = JSON.parse(sessionStorage.getItem("eventlen"));
		
	if(mycount == ""){
		sessionStorage.setItem("countevent",0);
	}else{
		
		 mycount = JSON.parse(sessionStorage.getItem("countevent"));
	}
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		sessionStorage.setItem("loadeventinmonthlyrange",this.responseText); //save toseesion store
		myeventArr = JSON.parse(xhttp.responseText); // get event Ids
		myeventArrlen = myeventArr.length;
		sessionStorage.setItem("eventlen",myeventArrlen); // set event size or length
		setEventCountlen(myeventArr[mycount]);

		}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/new_pull_eventmgr.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send();	
}

function setEventCountlen(event_ids){
	 
	var mymembervid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembervid = mymembervid.memberid.toString();
	 
		/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		//console.log(xhttp.responseText);
		//alert(xhttp.responseText);
		myeventObj = JSON.parse(xhttp.responseText);
		if(myeventObj.eventartwork == ""){
			
			myeventObj.eventartwork = "ballonHotair.PNG";
		} 
		
		document.getElementById("event_title").innerHTML = myeventObj.eventtitle;
		document.getElementById("datetimeofevent").innerHTML = myeventObj.eventdate;
		document.getElementById("timeofevent").innerHTML = myeventObj.eventstarttime +"-"+myeventObj.eventfinishtime;
		document.getElementById("keepmyinterestid").value = myeventObj.eventid;
		document.getElementById("evntbody").innerHTML = myeventObj.eventnsgbody;
		document.getElementById("eventsimg").src = "../images/eventmedia/"+myeventObj.eventartwork;
	 }
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pulleventsformyview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//xhttp.send("sent_evtID="+event_ids+"&sent_membrevtid="+mymembervid);	
xhttp.send("sent_evtID="+event_ids);	
}


var getnexteventbtn = document.getElementById("nexteventbtn");//upnextveventbtn
getnexteventbtn.addEventListener("click",function(){gogetUpcomingEvents(getnexteventbtn.id)},false);

var getpreveventbtn = document.getElementById("preveventbtn");//downpreveventbtn
getpreveventbtn.addEventListener("click",function(){gogetUpcomingEvents(getpreveventbtn.id)},false);

function gogetUpcomingEvents(getbtnsent){

	let event_sess_id = JSON.parse(sessionStorage.getItem("loadeventinmonthlyrange"));
    let count = JSON.parse(sessionStorage.getItem("countevent"));
	let my_eventlen = JSON.parse(sessionStorage.getItem("eventlen"));
	sessionStorage.setItem("countevent",mycount);
	if(count == my_eventlen){
		alert("No more events for now");
		setEventCountlen(event_sess_id[count]);
		sessionStorage.setItem("countevent","0");
		//return false;
	}
 
let myeventArr = [];
if(getbtnsent === "nexteventbtn"){
	mycount = ++count;
	setEventCountlen(event_sess_id[mycount]);
	sessionStorage.setItem("countevent",mycount);
	
	if(mycount == 1){
		document.getElementById("preveventbtn").style.display = "block";
	}
}else if(getbtnsent === "preveventbtn"){
	mycount = --count;
	setEventCountlen(event_sess_id[mycount]);
	sessionStorage.setItem("countevent",mycount);
	if(mycount == 0){
	document.getElementById("preveventbtn").style.display = "none";
	}
}else{
	console.log(mycount);
}

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		myeventObj = JSON.parse(xhttp.responseText);
		
		if(myeventObj.eventartwork == ""){
			
			myeventObj.eventartwork = "ballonHotair.PNG";
		}
		
		document.getElementById("event_title").innerHTML = myeventObj.eventtitle;
		document.getElementById("datetimeofevent").innerHTML = myeventObj.eventdate;
		document.getElementById("timeofevent").innerHTML = myeventObj.eventstarttime +"-"+myeventObj.eventfinishtime;
		document.getElementById("keepmyinterestid").value = myeventObj.eventid;
		document.getElementById("evntbody").innerHTML = myeventObj.eventnsgbody;
		document.getElementById("eventsimg").src = "../images/eventmedia/"+myeventObj.eventartwork;
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pulleventsformyview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_count="+mycount);
}