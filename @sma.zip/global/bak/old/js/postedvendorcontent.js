function sendvendorsPostImg(postform){
		var arrytypev = ["VendorQuotes"];
		// vendorstype
		var txtv;
		//alert(postform);
		
	if(postform === "vendorstype"){
		arrychked = arrytypev[0];
		 txtv = document.getElementById("nbcastextareavendors");
		if( txtv.value == ""){
			alert("Cannot be empty");
			txtv.focus();
			return false;
		}
		//check the store for Vendors category key
		let isVendorCatgokeyavailable = sessionStorage.getItem("VendorQuotes");
		 if(isVendorCatgokeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 		
	}else{
		alert("Cannot process");
	}
	
	passtoPostHandlerv(txtv.value,arrychked,postform);	
}

function getRndIntegerv(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function passtoPostHandlerv(messagebcasted,vendortypechked,formposted){
//alert(vendortypechked);
	var form = document.forms.namedItem(formposted);

	let membermakingpost = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermakingpost = membermakingpost.memberid.toString();
	let mybcastorgnid = getRndIntegerv(1000000,9999999);
	var exclusiveonlylen = JSON.parse(sessionStorage.getItem(vendortypechked));
	var exclusiveonlyto = JSON.stringify(JSON.parse(sessionStorage.getItem(vendortypechked)));
	
	folderToUploadpostdimg = "../images/vendors";
   
  //var oOutput = document.getElementById("displaysent"),

  oData = new FormData(form);
  oData.append("Bcastmsg", messagebcasted);
  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", membermakingpost);
  oData.append("Exclusiveonlylen", exclusiveonlylen.length); 
  oData.append("Exclusiveonlyto", exclusiveonlyto);
  oData.append("Bcasstoriginid", mybcastorgnid);
  

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/postedvendorcontent.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  alert(oReq.responseText);	  
	  console.log(oReq.responseText);
	  //location.reload();	  
	  //setTimeout(cleanUp,3000);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);


}

function cleanUpv(){
	document.getElementById("").value = "";
	document.getElementById("").value = "";
	document.getElementById("").innerHTML = "";
	document.getElementById("").value = "-";
}