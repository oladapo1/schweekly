var getoptoutrf= document.getElementById("optoutrf");
getoptoutrf.addEventListener("click",function(){loadEventsioptin()},false);

function loadEventsioptin(){

var mymembersenderoptout = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderoptout = mymembersenderoptout.memberid.toString();

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){ 
		//alert(xhttp.responseText);
		//console.log(xhttp.responseText);
		// attache to body
	document.getElementById("listeventamoptnouttbl").innerHTML = xhttp.responseText;

  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pull_eventintresetedoptouts.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_amoptoutmyid=" +mymembersenderoptout);	
}


function Optoutofevent(gteventidoptout){

let mymembersenderoptoutid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderoptoutid = mymembersenderoptoutid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			alert(this.responseText);	
			console.log(this.responseText);	
			location.reload();
			 }		
        };
		
	xhttp.open("POST","scripts/eventintresetedoptouts.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_optout_ids="+mymembersenderoptoutid+"&sent_eventoptoutid="+gteventidoptout);
}