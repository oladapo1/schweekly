function sendnbcastPostImg(postform){
		var arrytype = ["ToAllnBcast","ToPharmacistsnBcast","ToDoctorsnBcast","ToOthersnBcast"];
		var txt;
		//alert(postform);
		
	if(postform === "alloccutype"){
		arrychked = arrytype[0];
		 txt = document.getElementById("nbcastextareall");
		if( txt.value == ""){
			alert("Message area cannot be empty");
			txt.focus();
			return false;
		}
		//check the store for All category key
		let isAllCatgokeyavailable = sessionStorage.getItem("ToAllnBcast");
		 if(isAllCatgokeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 		
	}else if(postform === "pharmsoccutype"){
		arrychked = arrytype[1];
		 txt = document.getElementById("nbcastextareapharms");
		if( txt.value == ""){
			alert("Message area cannot be empty");
			txt.focus();
			return false;
		} 
		//check the store for Pharms key
		let isPharmkeyavailable = sessionStorage.getItem("ToPharmacistsnBcast");
		 if(isPharmkeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 
	}else if(postform === "drsoccutype"){
		arrychked = arrytype[2];
		  txt = document.getElementById("nbcastextareadrs");
		if( txt.value == ""){
			alert("Message area cannot be empty");
			txt.focus();
			return false;
		}
		//check the store for Drs key
		let isDrkeyavailable = sessionStorage.getItem("ToDoctorsnBcast");
		 if(isDrkeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 
		
		/* if("ToDoctorsnBcast" in sessionStorage){
			alert("You have not made any selection");
		}else{
			alert("Nope");
		} */

	}else if(postform === "moreoccutype"){
		arrychked = arrytype[3];
		  txt = document.getElementById("nbcastextareamore");
		if( txt.value == ""){
			alert("Message area cannot be empty");
			txt.focus();
			return false;
		}
		//check the store for More category key
		let isMoreCatgokeyavailable = sessionStorage.getItem("ToOthersnBcast");
		 if(isMoreCatgokeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 		
	}else{
		alert("Cannot process");
	}
	
	passtoPostHandler(txt.value,arrychked,postform);	
}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function passtoPostHandler(messagebcasted,occutypechked,formposted){
//alert(occutypechked);
	var form = document.forms.namedItem(formposted);

	var membermakingpost = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermakingpost = membermakingpost.memberid.toString();
	let mybcastorgnid = getRndInteger(1000000,9999999);
	var exclusiveonlylen = JSON.parse(sessionStorage.getItem(occutypechked));
	var exclusiveonlyto = JSON.stringify(JSON.parse(sessionStorage.getItem(occutypechked)));
	
	folderToUploadpostdimg = "../images/nbcast";
   
  //var oOutput = document.getElementById("displaysent"),

  oData = new FormData(form);
  oData.append("Bcastmsg", messagebcasted);
  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", membermakingpost);
  oData.append("Exclusiveonlylen", exclusiveonlylen.length); 
  oData.append("Exclusiveonlyto", exclusiveonlyto);
  oData.append("Bcasstoriginid", mybcastorgnid);
  

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/postedcontent_nbcast.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  alert(oReq.responseText);	  
	  console.log(oReq.responseText);
	  //location.reload();	  
	  setTimeout(cleanUp,3000);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);


}

function cleanUp(){
	document.getElementById("nbcastextareall").value = "";
	//document.getElementById("mediatopost").value = "";
	//document.getElementById("displaysent").innerHTML = "";
	//document.getElementById("exclusiveonlyto").value = "-";
}