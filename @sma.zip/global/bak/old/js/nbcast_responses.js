function collateResp(a){
    let frm =  document.getElementById(a.form.id);
    //alert("Ok"+ a.form.id);
    var loadarray = ["txtload","xclusiveto","bcasautor","bcastuid"];
    
   /* var txt = "";
    var i;
    for (i = 0; i < frm.length; i++) {
      txt = txt + frm.elements[i].value + "<br>";
    }*/
    //alert(txt);
    
    loadarray[0] = frm.elements[0].value; // txtrea load
    loadarray[1] = frm.elements[1].value; // exlusive
    loadarray[2] = frm.elements[2].value; // authour
    loadarray[3] = frm.elements[3].value;// bcastId
    
    /*for(i = 0; i < loadarray.length; i++){
        
        alert(loadarray[i]);
        
    }*/
    
    let memberiud = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberiud = memberiud.memberid.toString();
    
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				alert(xhttp.responseText);
				console.log(xhttp.responseText);
				//document.getElementById("").innerHTML = xhttp.responseText;
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/nbcast_responses.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_membr_uid=" +memberiud+"&send_membr_respload="+loadarray[0]+"&send_mbr_exclive="+loadarray[1]+"&send_mbr_authr="+loadarray[2]+"&send_bcastId="+loadarray[3]);
    
}
