window.onload = checkInitexist();
	function checkInitexist(){

		let getinitags = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
			
		if(getinitags == null){
			location.href = "index.php";
		} else if(getinitags != null){
			console.log("Initialized");
		}else{
			console.log("oops! challenges with getting page");
		}
		
	}

