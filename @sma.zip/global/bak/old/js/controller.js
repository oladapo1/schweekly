function AppCtrl($scope)
 {
$scope.name = "";

$scope.clickHandler = function(){
window.alert('Clicked!');
};

$scope.contacts = [
{
name: 'John Doe',
phone: '01234567890',
email: 'john@example.com'
},
{
name: 'Karan Bromwich',
phone: '09876543210',
email: 'karan@email.com'
},
{
name: 'Oladapo Roitmi',
phone: '08020597327',
email: 'dapof@demail.com'
},
{
name: 'Hughes Bales',
phone: '09876324210',
email: 'hughes@email.com'
}
];

$scope.styleDemo = function(){
if(!$scope.styler){
return;
}
return {
background: 'red',
fontWeight: 'bold'
};
};



}