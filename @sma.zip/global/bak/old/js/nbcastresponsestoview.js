function pull_myBcastresponsesforview(dbcast_id){
    
    var divbcast = "responsesasviewd"+dbcast_id;
    let responsesdiv_id = document.getElementById(divbcast);
	//let responses_mnu = document.getElementById("mylogistic_mnu");
	//responses_mnu.addEventListener("click",revealLogisticsDiv,false);
	//function revealLogisticsDiv(){
	 
	responsesdiv_id.style.display = "block";
	//responsesdiv_id.style.width = "100%";
	//responsesdiv_id.style.height = "450px";
	//responsesdiv_id.style.position = "absolute";
	//responsesdiv_id.style.top = "120px";
	//responsesdiv_id.style.left = "-2px";
	//responsesdiv_id.scrollIntoView();
//	}
	
	//Close responseviews div
	let clsspn = "clsrespviewdiv"+dbcast_id;
  var clsresponsesdivx = document.getElementById(clsspn);
  //clsrespviewdiv$gtbcastid
  
  clsresponsesdivx.addEventListener("click",function(){
  
   closeInitChatDivs("responsesasviewd"+dbcast_id); //
  
  },false);
    
    //alert(dbcast_id);
	
	/*let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();
	
	let mymembercarrer = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembercarrer = mymembercarrer.occupatntype.toString();
	
	let mymemberspec = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberspec = mymemberspec.occuspecializatn.toString();
	
	let mymemberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberzone = mymemberzone.zone.toString();*/
	

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    let bcsatid = "mybcastresponses"+dbcast_id
	    document.getElementById(bcsatid).innerHTML = "<div class='progress'><div class='indeterminate'></div></div>";
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			//var obj = JSON.parse(xhttp.responseText);
			//alert(obj[1]);
			//document.getElementById("msgsbubble").innerHTML = obj[0];
			 document.getElementById(bcsatid).innerHTML = xhttp.responseText;
			 //document.getElementById(bcsatid).scrollIntoView(false);
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/nbcastresponsestoview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//xhttp.send("membr_idod="+mymembershipeid+"&membr_occu="+mymembercarrer+"&membr_spec="+mymemberspec+"&membr_zone="+mymemberzone);
xhttp.send("sent_bcastId="+dbcast_id);
}