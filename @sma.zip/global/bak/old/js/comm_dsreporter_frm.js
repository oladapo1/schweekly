function dailySymptomreporter(frm){
    let thisfrm = document.getElementById(frm.form.id);
    //alert(frm.form.id)
        /*var fileinputval = document.getElementById("symptomattachmnt");
	if(fileinputval.files.length === 0){
	//alert("No image selected");
	
	event.preventDefault();
	return false;
	}
	*/
	let dtextareavalue  = document.getElementById("mytxtareahowifeel");
	let dpreference     = document.getElementById("myprefhexpert");
	
	if(dtextareavalue.value === ""){
		alert("Kindly fill in your symptom");
		dtextareavalue.focus();
		return false;
	}
	
	passDailySymptomsReportdetailstoHandler(thisfrm.name);
}

function passDailySymptomsReportdetailstoHandler(formposted){
	
    let form = document.forms.namedItem(formposted);
	let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
	//check for image

    var uploadir = "images/communitydsr";
  //var oOutput = document.getElementById("displayvctorsent"),
      oData = new FormData(form);
//symptomattachmnt
  oData.append("CommnityMembrID", mycommmembershipeid);
  oData.append("UploadDir", uploadir);
/*oData.append("ImagefrompostFileInput", dsrhasmediaimagefile);
  oData.append("PostLoad", postbody);
  oData.append("Exclusiiveto", onlyto); */

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/comm_dsreporter_frm.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      alert(oReq.responseText);
	  console.log(oReq.responseText);
	  document.getElementById("mytxtareahowifeel").value = "";
	  //oOutput.innerHTML = oReq.responseText;	
	  //location.reload();	  
	  //setTimeout(cleanUpVistrform,1000);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
      alert( oReq.status);
    }
  };

  oReq.send(oData);
}

/*function collateResp(a){
    let frm =  document.getElementById(a.form.id);
    var loadarray = ["txtload","xclusiveto","bcasautor","bcastuid"];

    loadarray[0] = frm.elements[0].value; // txtrea load
    loadarray[1] = frm.elements[1].value; // exlusive
    loadarray[2] = frm.elements[2].value; // authour
    loadarray[3] = frm.elements[3].value;// bcastId
    
    let memberiud = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberiud = memberiud.memberid.toString();
    
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				alert(xhttp.responseText);
				console.log(xhttp.responseText);
				//document.getElementById("").innerHTML = xhttp.responseText;
  	}
	};
	
	 / Using POST/
	 
xhttp.open("POST","scripts/nbcast_responses.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_membr_uid=" +memberiud+"&send_membr_respload="+loadarray[0]+"&send_mbr_exclive="+loadarray[1]+"&send_mbr_authr="+loadarray[2]+"&send_bcastId="+loadarray[3]);
    
}*/
