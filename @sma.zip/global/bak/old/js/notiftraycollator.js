gtnotifbell = document.getElementById("notificationbell");
document.addEventListener("DOMContentLoaded",pullMyNotifsTotray,false);
function pullMyNotifsTotray(){
var mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			document.getElementById("notifdropdowntray").innerHTML = this.responseText;
			//sessionStorage.setItem("myNotifs", '{"\NotifItems"\:'+this.responseText+'}');
	
            }
        };
		
	xhttp.open("POST","scripts/notiftraycollator.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
}