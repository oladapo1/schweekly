document.addEventListener("DOMContentLoaded",pullSlideshowLists,false);
function pullSlideshowLists(){
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  

		document.getElementById("loadtopfivestub").innerHTML = xhttp.responseText;
		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/loadtopfivesidebarstub.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send();	
}