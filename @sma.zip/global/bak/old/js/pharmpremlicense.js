function passPharPremsRenewaltoHandler(licnseformname){
	
  var licentype;
  sessionStorage.removeItem("MembrLicencedata");
  var form = document.forms.namedItem(licnseformname);
  	/////////////////////////

	if( licnseformname == "pharmlicensfrm" ){
		licentype = 0;
		
		/////
		  fileinputvalue = form.membr_licencopy;	  
		  if(fileinputvalue.files.length === 0){
			alert("No Pharm. licence file selected");
			return false;
		  }
		  //convert
		  convertoBase64ImageLic(form,fileinputvalue,licentype);
	
	}else if( licnseformname == "premslicensfrm" ){
		licentype = 1;
			
		/////
		  fileinputvalue = form.membr_premislicencopy;	  
		  if(fileinputvalue.files.length === 0){
			alert("No Premises licence file selected");
			return false;
		  }
		  //convert
		  convertoBase64ImageLic(form,fileinputvalue,licentype);
		  
	}else if( licnseformname == "affidlicensfrm" ){
		licentype = 2;

		/////
		  fileinputvalue = form.membr_affidlicencopy;	  
		  if(fileinputvalue.files.length === 0){
			alert("No Affidavit licence file selected");
			return false;
		  }
		  //convert
		  convertoBase64ImageLic(form,fileinputvalue,licentype);
		  
	}
	
	////////////////////////
 }

//convert to bae64IMG for licences
var filemaxUploadLimit = 204800; // 200kbB 
var uploadOk = 1;
var licenceStorageKey = "MembrLicencedata";
let image_lic_Data = [];
function convertoBase64ImageLic(form,hye,lictype){
		
		const file =  hye.files[0];
		
		
		// Allow certain file formats
		if(file.type != "image/jpg" && file.type != "image/png" && file.type != "image/PNG" && file.type != "image/jpeg"
		&& file.type != "image/gif") {
			alert("Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
			uploadOk = 0;
			return false;
			//Boolean(uploadOk);
			}	
		
		if (file.size <= filemaxUploadLimit) {
		  const reader = new FileReader();

		  reader.onloadend = () => {
			const base64String = reader.result
			  .replace('data:', '')
			  .replace(/^.+,/, '');

			// Create an object containing image information.
			let imageObj = {
			  name: "image-" + file.name,
			  timestamp: Date.now(),
			  licencetype:lictype,
			  file_base64: base64String.toString()
			};
			
		  // console.log(imageObj.file_base64);
			//image_lic_Data.push(imageObj);
			//sessionStorage.setItem(licenceStorageKey, JSON.stringify(image_lic_Data));
			addlicImage(imageObj);					
			passLicenceImgdata(form,imageObj.licencetype,imageObj.file_base64);		
	
		  };

		  reader.readAsDataURL(file);
		} else {
		//upload.after("<p>File too large</p>");
		  alert("File too large! - max size allowed is 200kb");
		}
	   
}

function addlicImage(imageObj) {
  image_lic_Data.push(imageObj);
  sessionStorage.setItem(licenceStorageKey, JSON.stringify(image_lic_Data));
}

function passLicenceImgdata(licenceformname,lictype,licenceimg){
	
  let membrpcnuid = document.getElementById("licencesactivatorcheckr");//check foremepty value
  if(membrpcnuid.value===""){
	  alert("fill in pcn_id");
	  return false;
  }
  		
		/*var memberLicencebase64 = sessionStorage.getItem("MembrLicencedata");
		if(memberLicencebase64 == null){
		  
		  alert("Licence Image not in store");
		  return false;
		   
	  }*/
  
  //let img_data = JSON.parse(memberLicencebase64);
 //let licenceimg = img_data[0].file_base64;//get the image item
  
  //var oOutput = document.getElementById("logrenewalrqst"),
    
	  oData = new FormData(licenceformname);
      oData.append("Licence_Bs_64", licenceimg);
	  oData.append("LicenceType", lictype);
	  oData.append("MemberPCNuid", membrpcnuid.value);
	  var oReq = new XMLHttpRequest();
	  oReq.open("POST", "scripts/pharmpremlicense.php", true);
	  oReq.onload = function(oEvent) {
		if (oReq.readyState == 4 && oReq.status == 200){
		  //oOutput.innerHTML = oReq.responseText;
		  console.log(oReq.responseText);	  
		  alert(oReq.responseText);	  
		} else {
		  //alert("Error " + oReq.status + " occurred when trying to upload your file.<br>");
		  alert("Error occurred when trying to upload your file.<br>");
		}
	  };

	  oReq.send(oData);
	//}else{
		
	//	alert("Operation cannot proceed!");
		//return false;		
	//}	 
	
}

let h = document.getElementById("licencesactivatorbtn");
h.addEventListener("click",checkActivationstatus,false);
function checkActivationstatus(){
	
	let uid = document.getElementById("licencesactivatorcheckr");
	
	if(uid.value === "" || uid.value === undefined){
			
			alert("Enter official number");
			return false;
		}
	
	// create xhr object 
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
		
    if (this.readyState == 4 && this.status == 200){ 
		
		if(this.responseText === "exist"){
			
			document.getElementById("mystatusreport").innerHTML = "Member Found";
			document.getElementById("pharmlicensfrmidiv").style.display = "inline-block";
			document.getElementById("premslicensfrmidiv").style.display = "inline-block";
			document.getElementById("affidlicensfrmidiv").style.display = "inline-block";
		
		}else if(this.responseText === "doesnotExist"){
			
			document.getElementById("mystatusreport").innerHTML = "Member not found, please fill the section1 form above";
			document.getElementById("pharmlicensfrmidiv").style.display = "none";
			document.getElementById("premslicensfrmidiv").style.display = "none";
			document.getElementById("affidlicensfrmidiv").style.display = "none";
			//setTimeout(location.reload(),9000);
		}
			//alert(this.responseText);
		
	}
	};
	
	 //Using POST 
	xhttp.open("POST","scripts/mystatuschecker.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_uid="+uid.value);
}
