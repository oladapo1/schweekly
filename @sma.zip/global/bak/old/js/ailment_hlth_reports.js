document.addEventListener("DOMContentLoaded",getAilmentdata,false); 

function getAilmentdata() { 

	var myovermembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	myovermembershipeid = myovermembershipeid.memberid.toString();
       
		if(myovermembershipeid == ""){
		alert("You are required to do the needful");//signin to register staffs
		return false;
			}
		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            //console.log(xhttp.responseText);
			sessionStorage.setItem("AilmentData", '{"\CollatedAilment"\:['+this.responseText+']}');
			
			createProgressbars();
            }
        };
		
	xhttp.open("POST","../scripts/healthreports.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_myovermembershipeid="+myovermembershipeid);

}

var ailarrays = ["Asthma","Cough","Headache","Migraine","Diarhrea","Dysentery","Rashes","Tuberculosis"];

var progbardivarrays = ["firstprogbar","secondprogbar","thirdprogbar","fourthprogbar","fifthprogbar","sixthprogbar","seventhprogbar","eightprogbar"];

//var myailmentObj = JSON.parse(sessionStorage.getItem("AilmentData"));	

function createProgressbars(){
	
	var myailmentObj = JSON.parse(sessionStorage.getItem("AilmentData"));
	var ailcolvarrays = [
	myailmentObj.CollatedAilment[0].Asthma,
	myailmentObj.CollatedAilment[1].Cough,
	myailmentObj.CollatedAilment[2].Headache,
	myailmentObj.CollatedAilment[3].Migraine,
	myailmentObj.CollatedAilment[4].Diarhrea,
	myailmentObj.CollatedAilment[5].Dysentery,
	myailmentObj.CollatedAilment[6].Rashes,
	myailmentObj.CollatedAilment[7].Tuberculosis,
	myailmentObj.CollatedAilment[8].TotalAilmentcount
	];
	
	
	console.log(ailcolvarrays);
	
	/* for(i = 0; i < myailmentObj.CollatedAilment.length-1; i++){
	
	//console.log(ailarrays[i]+" "+ailcolvarrays[i]);
	console.log(ailcolvarrays);
	
		} */
}