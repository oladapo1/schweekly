window.addEventListener("load",gtDataReload,false);

function gtDataReload(){
	let postidcom = sessionStorage.getItem("postid_reload");
	let countcom = sessionStorage.getItem("comcount_reload");
	sendCommentPostid(postidcom,countcom);
	//alert(postidcom+"-"+countcom);
}

function sendCommentPostid(postidincomment,commentcount){
	
	sessionStorage.setItem("postid_reload",postidincomment);
	sessionStorage.setItem("comcount_reload",commentcount);
	
	let membrviewncomments = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membrviewncomments = membrviewncomments.memberid.toString();
	
	
			//alert(postidincomment+" ok ");
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			
			//alert(xhttp.responseText);
			document.getElementById("postscommntersload").innerHTML = xhttp.responseText;
			
	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","scripts/pull_allcomments_toview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_postedcomtid=" +postidincomment+"&send_commentcounts="+commentcount+"&send_membridcmnt="+membrviewncomments);
}
