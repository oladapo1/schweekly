//searchbar_m.js

/* var srchblox = document.getElementById("searchblox");
srchblox.addEventListener("blur",function(){hideSuggestlabel()},false);
<span><input type="text" class="form-control" id="searchblox" name="searchblox" placeholder="search a profile by first name:" style="width:80%;" onkeyup="showsearchedHint(this.value)"></span> */

/* function hideSuggestlabel(){
//document.getElementById("labelsuggestn").style.display = "none";
//document.getElementById("searchblox").value = "";
//document.getElementById("searchblox").focus();
} */

/* var srchblox = document.getElementById("searchblox");
srchblox.addEventListener("blur",function(){resetView()},false);

function resetView(){
	//alert("ok");
	document.getElementById("txtHint").innerHTML = "";
	document.getElementById("listmembrsearch").innerHTML = "";
	document.getElementById("listmembrsearchdiv").innerHTML = "";
} */

function showsearchedHint(chartopick){
//alert(chartopick);
document.getElementById("labelsuggestn").style.display = "block";
var myObjsearchmembr = JSON.parse(sessionStorage.getItem("initMemberforsearch"));	

	//let text = "";
	srchload = myObjsearchmembr.InitMsearchData;
	srchloadlen = srchload.length;
	
	//alert(srchloadlen);
	//var searchblox = document.getElementById("searchblox");

	
    if (chartopick.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
		//document.getElementById("listmembrsearch").innerHTML = "";
		document.getElementById("listmembrsearchdiv").innerHTML = "";
       } else {
for(i = 0; i < srchloadlen;i++){

	if(srchload[i].Firstname.charAt(0) === chartopick.toUpperCase() || srchload[i].Surname.charAt(0) === chartopick.toUpperCase()){
	
	document.getElementById("listmembrsearchdiv").innerHTML += "<ul class='list-group'><li class='list-group-item'><a href='#mprofile_srchd' class='mysearchlist' id='"+myObjsearchmembr.InitMsearchData[i].MemberID+"'onclick='getSelectedsearchloadtoview(this.id);'>"+myObjsearchmembr.InitMsearchData[i].Surname+" "+myObjsearchmembr.InitMsearchData[i].Firstname+"</a></li></ul>";
		
	}else{
	continue;
	}
	}
}
}

///////////////////

window.addEventListener("load",function(){getInitloadforsearch()},false);

function getInitloadforsearch(){
//Ensure to check the user making the request
//shopUId = localStorage.getItem("SHOPUID");

	//console.log(shopUId);
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			sessionStorage.setItem("initMemberforsearch", '{"\InitMsearchData"\:'+this.responseText+'}');
				//alert(this.responseText);
				//getMyConnPostPointsrchd();
            }
        };
		
	xhttp.open("POST","scripts/initbasicsearchmembrs.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send();
}

///////////////////

function getSelectedsearchloadtoview(searchedmemberid){
//Ensure to check the user making the request
//shopUId = localStorage.getItem("SHOPUID");

//alert(searchedmemberid+" in next select searched fucntion");

getMyConnPostPointsrchd(searchedmemberid); // call the function to pick posts,connctions now

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			sessionStorage.setItem("PullselectedMemberforview", '{"\InitMSelectedsearchData"\:'+this.responseText+'}');
				//alert(this.responseText);
	
		var myObjselectedsearch = JSON.parse(sessionStorage.getItem("PullselectedMemberforview"));
				
				document.getElementById("familiarsurname_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Surname;
				
				document.getElementById("familiarfname_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Firstname;
				
				document.getElementById("pharmaname").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Pharmname; 
				
				document.getElementById("nickusername").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Nickname;
				
				document.getElementById("zonedloc_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Zone;
				
				document.getElementById("statloc_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].State;
				
				document.getElementById("careertype_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Career;
				
				document.getElementById("reachmetelf_srchd").innerHTML = myObjselectedsearch.InitMSelectedsearchData[0].Mobile;
				
				document.getElementById("userprofilepix_srchd").src = "../images/profileimages/"+myObjselectedsearch.InitMSelectedsearchData[0].Profilepix;
				
				basedir = "../images/topbanners/"+myObjselectedsearch.InitMSelectedsearchData[0].Topbanner;
				document.getElementById("topbanner_srchd").style.backgroundImage = "url("+basedir+")";	
            }
        };
		
				
	xhttp.open("POST","scripts/initselectedsearchload.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_searchmamberid="+searchedmemberid);
}


function getMyConnPostPointsrchd(srchd){

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			mydataload = JSON.parse(this.responseText);
			document.getElementById("alltimeconnectn_srchd").innerHTML = mydataload[0];
			document.getElementById("myposts_srchd").innerHTML = mydataload[1];
			
            }
        };
		
	xhttp.open("POST","scripts/mprofile_c_p_pts.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_members_id="+srchd);	
}




/////
