var bcastcreatebtn = document.getElementById("bcastcreatebtn");
bcastcreatebtn.onclick = chkbcastcreateLoad_ifempty;

function chkbcastcreateLoad_ifempty(){

var gtRequestopic = document.getElementById("mkbcastrequest").value;
var gtExpirationdate   = document.getElementById("castexpiration").value;
var gtCastmsg   = document.getElementById("bcaststcreatn").value;

//var gtWhomadeposr = document.getElementById("memberid").value;


if(gtRequestopic == "" || gtExpirationdate === ""){
	
	alert("All fields required");
	document.getElementById("mkbcastrequest").focus();
	return false;
	
	}else{
		
		muv_newBCastohandler(gtRequestopic,gtExpirationdate,gtCastmsg);
			
	}

}

function muv_newBCastohandler(newcastrequest,expirewhen,newcastmsg){
		
var mymembershipeidbcreator = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbcreator = mymembershipeidbcreator.memberid.toString();
	
		//alert("You seem not to be logged in "+mymembershipeidbcreator);
	
		if(mymembershipeidbcreator == ""){
		alert("You seem not to be logged in");
		return false;
			}
			
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			
			if(xhttp.responseText){
				//alert("sent :)");
				alert(xhttp.responseText);
			setTimeout(refreshToViewRecentBcasts,2000);
			}else{
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/broadcastcreate.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_castrqst=" +newcastrequest +"&send_expiratn=" +expirewhen+"&send_castmsg="+newcastmsg+"&send_mymembershipeidbcreator="+mymembershipeidbcreator);
	
}


function refreshToViewRecentBcasts(){
	location.reload();
	//pullrecentBroadcast();// this funtion is in the emergency broadcast file it fires the php handler - Pullrecentbroadcastdotphp
}


