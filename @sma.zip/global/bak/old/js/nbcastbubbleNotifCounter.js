//setInterval(pull_myBcastresponsesforview,5000);
document.addEventListener("DOMContentLoaded",pull_myBcastBubbles,false);
//var btnmybcastviews = document.getElementById("mybcastviews");
//btnmybcastviews.addEventListener("click",pullmyBcastresponsesforview,false);
//var mynotifsarray = ["","","","",""]; //chatnotifbubble allbcastresponses allchatresponses allcommunityresponses
function pull_myBcastBubbles(){
    //alert("hi");
	let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();
	
	let mymembercarrer = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembercarrer = mymembercarrer.occupatntype.toString();
	
	let mymemberspec = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberspec = mymemberspec.occuspecializatn.toString();
	
	let mymemberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberzone = mymemberzone.zone.toString();
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			//var obj = JSON.parse(xhttp.responseText);
			//alert(obj[1]);
			//document.getElementById("msgsbubble").innerHTML = obj[0];
			  document.getElementById("chatnotifbubble").innerHTML = xhttp.responseText;
			  /*to do - save value to store*/
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/nbcastcollatenew.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("membr_idod="+mymembershipeid+"&membr_occu="+mymembercarrer+"&membr_spec="+mymemberspec+"&membr_zone="+mymemberzone);
}


document.addEventListener("DOMContentLoaded",collateBcastsrxnsnotif,false);

function collateBcastsrxnsnotif(){
    
    let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();
	
	let mymembercarrer = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembercarrer = mymembercarrer.occupatntype.toString();
	
	let mymemberspec = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberspec = mymemberspec.occuspecializatn.toString();
	
	let mymemberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberzone = mymemberzone.zone.toString();
	
	
var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			//var obj = JSON.parse(xhttp.responseText);
			//alert(obj[1]);
			  document.getElementById("allbcastresponses").innerHTML = xhttp.responseText;
			  /*to do - save value to store*/
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/nbcastcollatereactions.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("membr_idod="+mymembershipeid+"&membr_occu="+mymembercarrer+"&membr_spec="+mymemberspec+"&membr_zone="+mymemberzone);
}




/*
Bcast notif - emergencynewbcastcreate
Bcast responses/rxns notif - emrgencynewbroadcastrxn 
Chat notif - chatmgr
Chat responses notif - chatmgr
Community notifs - chatmgrpublic


function collateChatsnotifs(){

add notif for Chat responses/msgs

}


function collateCommunitynotifs(){

add notif for Community msgs

}



function collateAllnotifs(){

add notif for Bcast rxn + Chat responses/msgs + Community msgs

}
*/