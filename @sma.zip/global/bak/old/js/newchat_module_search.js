var newchat_srchdbtn = document.getElementById("newchat_module_search_id");

newchat_srchdbtn.onclick = sendSearchNewchatreqst;

function sendSearchNewchatreqst(){
	
	let inputsearched = document.getElementById("newchatinput_id");
	if(inputsearched.value === ""){
	alert("Kindly fill a name in");
	inputsearched.focus();
	return false;
	}
	document.getElementById("newchatr_inputfrm").style.display = "none";// hide search form if showing
	//var mymembershipeidbcasticreated = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	//mymembershipeidbcasticreated = mymembershipeidbcasticreated.memberid.toString();	
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
		//alert(this.responseText);
		//console.log(this.responseText);
		document.getElementById("searchchatrlist").innerHTML = this.responseText;
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/newchat_module_search.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_delgatenamechar="+inputsearched.value);
}
