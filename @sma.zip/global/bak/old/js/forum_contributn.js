//forum_contributn.js

//window.addEventListener("load",function(){()},false);

/*var getforummnu= document.getElementById("");
getforummnu.addEventListener("click",function(){},false);*/

function sendForumacontribs(topicontribtd,contribload){
	//alert(topicontribtd +"-Mo");
var gtmembersrid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersrid = gtmembersrid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			alert(this.responseText);	
			//console.log(this.responseText);
			//document.getElementById("myforumloads").innerHTML = this.responseText;
		   location.reload();
            }
        };
		
	xhttp.open("POST","scripts/forum_contributn.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_topic_contribid="+topicontribtd+"&send_contribload="+contribload+"&send_whocontrib="+gtmembersrid);
	//xhttp.send();
}