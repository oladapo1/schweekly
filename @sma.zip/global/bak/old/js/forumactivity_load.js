window.addEventListener("load",function(){pullForumactivitiestoviewjs()},false);

var getforummnu= document.getElementById("forummnu");
getforummnu.addEventListener("click",function(){pullForumactivitiestoviewjs()},false);

function pullForumactivitiestoviewjs(){
//alert(opostid+'-'+postolookup);
	
var gtmembersrid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersrid = gtmembersrid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			document.getElementById("myforumloads").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/forumactivity_load.php",true);
	//xhttp.open("POST","scripts/forum_pull_contributions.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_id_fpost="+gtmembersrid);
	//xhttp.send();
}