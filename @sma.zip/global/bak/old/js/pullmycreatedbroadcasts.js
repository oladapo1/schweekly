var gtmybroacasttoviewbtn = document.getElementById("mybroacasttoviewbtn");

gtmybroacasttoviewbtn.onclick = pullmyBroadcasts;

function pullmyBroadcasts(){
			
	var mymembershipeidbcasticreated = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbcasticreated = mymembershipeidbcasticreated.memberid.toString();	
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
	//sessionStorage.setItem("initBcastsload", '{"\BcastsData"\:['+this.responseText+']}');
	//sessionStorage.setItem("initBcastsload", '{"\BcastsData"\:'+this.responseText+'}');
		//console.log(this.responseText);
		document.getElementById("mycreatedbcasts").innerHTML = this.responseText;
		//mycreatedbcasts
		
		//getItemsandlisthem();	
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/broadcastmycreation.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_myidbcasticreated="+mymembershipeidbcasticreated);
}