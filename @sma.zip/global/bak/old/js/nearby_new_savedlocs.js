<?php
function getSavedlocdata(){
$sent_membr_ids  = $_POST["sent_membr_ids"];

include("connection.php");

$sqlgtsaved = "SELECT nlat,nlng,locsavduid from nearbyloc WHERE membrid = $sent_membr_ids";

$resultgtsvd = $conn->query($sqlgtsaved);

if ($resultgtsvd->num_rows > 0) {

   while($rowrsvd = $resultgtsvd->fetch_assoc()) {
	
	$gtsvd   	 = $rowrsvd["nlat"];
	$gtnlng 	 = $rowrsvd["nlng"];
	$gtlocsvduid = $rowrsvd["locsavduid"];
	
	//echo $gtopcount;
	echo"
	  <tr style='text-align:center;'>
        <td id='newlat'>$gtsvd</td>
        <td id='newlng'>$gtnlng</td>
        <td id='dellocbtn'><button type='button' class='btn btn-primary btn-sm' id='$gtlocsvduid' name='delcoordinate' onclick='alert(this.id)'>x</button></td>
      </tr>
	";

   }

}else{
	echo"No results";
}
	$conn->close();
	
}

getSavedlocdata();