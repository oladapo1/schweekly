setTimeout(pullrecentPostsfromyconnectiontoview,3000);
function pullrecentPostsfromyconnectiontoview(){
//alert("am in")
var mymembersenderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderid = mymembersenderid.memberid.toString();

//alert(mymembersenderid);


var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				
			//console.log(this.responseText);
			document.getElementById("postoviewcontainer").innerHTML = this.responseText;
			
            }
        };
		
	xhttp.open("POST","scripts/postoview.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_pullmembersenderxid="+mymembersenderid);
}