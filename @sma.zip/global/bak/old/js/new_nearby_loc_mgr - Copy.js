        var latlongdispresp = document.getElementById("respholderx");
		var latlongcoords = document.getElementById("listnewloccaptured");
			
		let newnearby_actnowbtn = document.getElementById("newnearbyactnowbtn");	
		newnearby_actnowbtn.addEventListener("click",getLocation,false);
		function getLocation() {
		  
		  if (navigator.geolocation){
			navigator.geolocation.getCurrentPosition(showPosition);
		  } else {
			latlongdisp.innerHTML = "Geolocation is not supported by this browser.";
		  }
		}

function showPosition(position) {	  
		  /////////////////////////////////////////////////////////
		  
	let memberwhositedspot = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberwhositedspot = memberwhositedspot.memberid.toString();
		  
	  //var oOutput = document.getElementById("displaysent"),
      oData = new FormData();

	  latlongcoords.innerHTML = "Your coordinates are: <br> Latitude "+ position.coords.latitude +" <br>"+"Longitude "+ position.coords.longitude;
	
	  console.log(latlongcoords);
	
	  oData.append("Latitude", position.coords.latitude);
	  oData.append("Longitude", position.coords.longitude);
	  oData.append("WhoSitedspot", memberwhositedspot);

	  var oReq = new XMLHttpRequest();
	  //oReq.open("POST", "scripts/illegalspots.php", true);
	  oReq.open("POST", "scripts/nearbysendloct.php", true);
	  oReq.onload = function(oEvent) {
		if (oReq.readyState == 4 && oReq.status == 200){
		  //latlongdisp.innerHTML = oReq.responseText;	
		  //location.reload();	
		  latlongdispresp.innerHTML = "Added to your list" + '<i class="material-icons" style="vertical-align:-5px;cursor:pointer;margin-left:5px;">loupe</i>';
		  setTimeout(showResposne,3000);
		} else {
		  latlongdisp.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
		}
	  };

	  oReq.send(oData);
		  
		  ////////////////////////////////////////////////////////	  
	}
	
	function showResposne(){
		latlongdispresp.innerHTML = "";
	}