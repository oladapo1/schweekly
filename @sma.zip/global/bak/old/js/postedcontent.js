function sendPostImg(postform){
	passtoPostHandler(postform);	
	
	//alert(postform);
}

function passtoPostHandler(formposted){
	
var form = document.forms.namedItem(formposted);

form.addEventListener('submit', function(ev) {

	var membermakingpost = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermakingpost = membermakingpost.memberid.toString();
	if(formposted == "postsitform"){
		
		folderToUploadpostdimg = "../images/postedimages";
		
		//C:\wamp\www\acpnyesba\images\postedimages
		//C:\wamp\www\acpnyesba\m\images\postedimages
	}
	else{
		alert("Voops!");
	}
   
  var oOutput = document.getElementById("displaysent"),
      oData = new FormData(form);

  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", membermakingpost);

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/postedcontent.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;	
	  //location.reload();	  
	  setTimeout(cleanUp,3000);
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
    }
  };

  oReq.send(oData);
  ev.preventDefault();
}, false);
}

function cleanUp(){
	document.getElementById("postreactn").value = "";
	document.getElementById("mediatopost").value = "";
	document.getElementById("displaysent").innerHTML = "";
	document.getElementById("exclusiveonlyto").value = "-";
}



