let btrecentactivty = document.getElementById("recentactivty");
btrecentactivty.addEventListener("click",function(){pullLogisticservactivities(0);},false);

let btsaveactivity = document.getElementById("savedactivity");
btsaveactivity.addEventListener("click",function(){pullLogisticservactivities(1);},false);

let btdelivreports = document.getElementById("delivreports");
btdelivreports.addEventListener("click",function(){pullLogisticservactivities(2);},false);

let btallactivity = document.getElementById("allactivity");
btallactivity.addEventListener("click",function(){pullLogisticservactivities(3);},false);


function pullLogisticservactivities(btnchoice){

let	gtactvitybtn = btnchoice;
	
let membrqstlogstcs = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
membrqstlogstcs = membrqstlogstcs.memberid.toString();

var formData = new FormData();
formData.append("MembridRqstnActvty",membrqstlogstcs);
formData.append("Activitybtnchosen",gtactvitybtn);

var request = new XMLHttpRequest();
request.open("POST", "scripts/logisticactivities.php");
request.onload = function(oEvent) {
	if (request.status == 200) {
	console.log(request.responseText);
	//document.getElementById("recntlydisplay").innerHTML = request.responseText;
		
let logstcactvty = sessionStorage.setItem("actvtylogstc",request.responseText);
var mylogstcactvty = JSON.parse(sessionStorage.getItem("actvtylogstc"));


		//alert(mylogstcactvty.length);
		//alert(mylogstcactvty[0][0].locdelvryto);
/* 		alert(mylogstcactvty[1].Actitytype);
		let gtload = function(){
			
			for(i in mylogstcactvty){
			alert(mylogstcactvty[i].locdelvryto);
			alert(mylogstcactvty[i].id);
			alert(mylogstcactvty[0][i].locdelvryto);
				
				//alert(mylogstcactvty[1].Actitytype);
			//document.getElementById("saveddisplay").innerHTML = mylogstcactvty[0][i].locdelvryto;
			//document.getElementById("saveddisplay").innerHTML = mylogstcactvty[i].Actitytype;
			}
			
		}
			gtload(); */
		
		var thd = "<thead style='text-align:center;'><th>Location</th><th>Created</th><th>Trans. ID</th></thead>";
			var bdy = "<tbody style='font-size:0.75em;text-align:center;'>";
		
		if(mylogstcactvty[1].Actitytype == 777){
			//var thd = "<thead style='text-align:center;'><th>Location</th><th>Created</th><th>Trans. ID</th></thead>";
		    //var bdy = "<tbody style='font-size:0.75em;text-align:center;'>";
			for(i in mylogstcactvty){
		
		bdy += "<tr><td>"+mylogstcactvty[0][i].locdelvryto+"</td><td>"+mylogstcactvty[0][i].logistcservcreated+"</td><td>"+mylogstcactvty[0][i].transactionid+"</td></tr>";
		
				document.getElementById("recntlydisplay").innerHTML = thd+bdy;
			}
			
		}else if(mylogstcactvty[1].Actitytype == 555){
			
				for(i in mylogstcactvty){
			bdy += "<tr><td>"+mylogstcactvty[0][i].locdelvryto+"</td><td>"+mylogstcactvty[0][i].logistcservcreated+"</td><td>"+mylogstcactvty[0][i].transactionid+"</td></tr>";
		
				document.getElementById("saveddisplay").innerHTML = thd+bdy;
			}
		}else if(mylogstcactvty[1].Actitytype == 444){
			
			for(i in mylogstcactvty){
			bdy += "<tr><td>"+mylogstcactvty[0][i].locdelvryto+"</td><td>"+mylogstcactvty[0][i].logistcservcreated+"</td><td>"+mylogstcactvty[0][i].transactionid+"</td></tr>";
		
				document.getElementById("delivdisplay").innerHTML = thd+bdy;
			}
			
		}else if(mylogstcactvty[1].Actitytype == 111){
			for(i in mylogstcactvty){
			bdy += "<tr><td>"+mylogstcactvty[0][i].locdelvryto+"</td><td>"+mylogstcactvty[0][i].logistcservcreated+"</td><td>"+mylogstcactvty[0][i].transactionid+"</td></tr>";
		
				document.getElementById("allactdisplay").innerHTML = thd+bdy;
			}
			
		}else{
			alert("Pointy");
		}
	
	//document.getElementById(commntresponsespan2).innerHTML = request.responseText;	
	/* setTimeout(function(){document.getElementById(countdownrnow2).value = '200';
	document.getElementById(textareareactn2).value = "";
	document.getElementById(commntresponsespan2).innerHTML = "";},2000); */
	//location.reload();	
	} else {
	console.log("Error " + request.status + " occurred when trying to upload");
	}
	};
request.send(formData);
}