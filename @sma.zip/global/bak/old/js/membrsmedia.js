var gtpodcbtn    = document.getElementById("newpodcastbtn");
var gtvideobtn 	 = document.getElementById("newvideobtn");
var gtytubebtn = document.getElementById("ytubebtn");

let gtpodcfrmid  = document.getElementById("addpodcasts");
let gtvidfrmid   = document.getElementById("addvideos");
let gtytbtxtval  = document.getElementById("newytvideo");

let podtitle = document.getElementById("podctilte");
let vidtitle = document.getElementById("videotilte");
let ytubtitle = document.getElementById("yubtilte");

let podcbtn = 1;
let vidcbtn = 2;
let ytbcbtn = 3;
gtpodcbtn.addEventListener("click",function(){membrMediahandler(gtpodcfrmid.name,podtitle.value,podcbtn);},false);
gtvideobtn.addEventListener("click",function(){membrMediahandler(gtvidfrmid.name,vidtitle.value,vidcbtn);},false);
gtytubebtn.addEventListener("click",function(){membrMediahandler(gtytbtxtval.value,ytubtitle.value,ytbcbtn);},false);

function membrMediahandler(formposted,mediatitle,btntype){
	
	let membermediasendr = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermediasendr = membermediasendr.memberid.toString();
	
	//alert(formposted+'-'+btntype+'-'+mediatitle);
	
	if(btntype === 1){
		
		  form = document.forms.namedItem(formposted);
		  fileinputvalue = form.newpodcast;
		  folderToUploadmedia = "../scontent/podcasts";
		  
		  if(fileinputvalue.files.length == 0){
			alert("No Podcast selected");
			return false;
		  }
		  
		  
		  if(mediatitle == ""){
			  alert("Kindly enter podcast title");
			  return false;
		  }
		  
		  let filenamed = "newpodcast"; //podctilte
		  oData = new FormData(form);
		  oData.append("UploadDir", folderToUploadmedia);
		  oData.append("Podcastitle",mediatitle);
		  oData.append("MediaType", btntype);
		  oData.append("FileNamed", filenamed);
	      oData.append("Whomadepost", membermediasendr);
		
	}else if(btntype === 2){
		
		 form = document.forms.namedItem(formposted);
		 //alert(formposted);
		 fileinputvalue = form.newvideo;
		 folderToUploadmedia = "../scontent/videos";
		 
		  if(fileinputvalue.files.length == 0){
			alert("No Video selected");
			return false;
		  }
		  
		  
		  if(mediatitle == ""){
			  alert("Kindly enter video title");
			  return false;
		  }
		  
		  let filenamed = "newvideo"; //videotilte
		  oData = new FormData(form);
		  oData.append("UploadDir", folderToUploadmedia);
		  oData.append("Videotitle",mediatitle);
		  oData.append("MediaType", btntype);
		  oData.append("FileNamed", filenamed);
	      oData.append("Whomadepost", membermediasendr);
		  
	}else if(btntype === 3){
		
		  
		  if(mediatitle == ""){
			  alert("Kindly enter Youtube video title");
			  return false;
		  }
		  
		
		  oData = new FormData(); //yubtilte
		  oData.append("Ytubeurl", formposted);
		  oData.append("Ytubetitle",mediatitle);
		  oData.append("MediaType", btntype);
	      oData.append("Whomadepost", membermediasendr);
		
	}else{
		
		alert("Oops!");
	}
		
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/membrsmedia.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      alert(oReq.responseText);
	  location.reload();
    } else {
		alert("OOPs!");
    }
  };
  oReq.send(oData);
}