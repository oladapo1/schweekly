function sendnbcastReponsesPostImg(postform){
		//var arrytype = ["BcastsResponses"];
		var txte;
		//alert(postform);
		
	if(postform === "bcastresponses"){
		//arrychked = arrytype[0];
		 txte = document.getElementById("nbcastextaresponses");
		if( txte.value == ""){
			alert("Cannot be empty");
			txte.focus();
			return false;
		}
		//check the store for Bcasts Responses category key
	/* 	let isBcastResponseCatgokeyavailable = sessionStorage.getItem("BcastsResponses");
		 if(isBcastResponseCatgokeyavailable === null){
			alert("You have not made any selection");
			return false;
		}  */		
	}else{
		alert("Cannot process");
	}
	
	passtoBcastRespPostHandler(txte.value,postform);	
}

function getRndIntegerbcr(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function passtoBcastRespPostHandler(messagebcasted,formposted){
//alert(messagebcasted);
	var form = document.forms.namedItem(formposted);

	let memberrespntobcast = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberrespntobcast = memberrespntobcast.memberid.toString();
	
	let bcastoriginID = JSON.parse(sessionStorage.getItem("BcastOrgID"));
	
	let mybcastorgnid = getRndIntegerbcr(1000000,9999999);

	//var exclusiveonlylen = JSON.parse(sessionStorage.getItem(vendortypechked));
	//var exclusiveonlyto = JSON.stringify(JSON.parse(sessionStorage.getItem(vendortypechked)));
	
	folderToUploadpostdimg = "../images/nbcastsresponses";
   
  //var oOutput = document.getElementById("displaysent"),

  oData = new FormData(form);
  oData.append("Bcastmsg", messagebcasted);
  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", memberrespntobcast);
  //oData.append("Exclusiveonlylen", exclusiveonlylen.length); 
  oData.append("BcastOrgID", bcastoriginID);
  oData.append("Bcasstoriginid", mybcastorgnid);
  

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/postedcontent_nbcastsresponses.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  alert(oReq.responseText);	  
	  console.log(oReq.responseText);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);
}

function cleanUp(){
	document.getElementById("postreactn").value = "";
	document.getElementById("mediatopost").value = "";
	document.getElementById("displaysent").innerHTML = "";
	document.getElementById("exclusiveonlyto").value = "-";
}