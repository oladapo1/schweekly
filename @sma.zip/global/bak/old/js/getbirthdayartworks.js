window.addEventListener("load",function(){getBirthdayBuffs()},false);
//document.addEventListener("DOMContentLoaded",getBirthdayBuffs,false);
function getBirthdayBuffs() { 
//alert("recd");
	var mystafformembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mystafformembershipeid = mystafformembershipeid.memberid.toString();
        
		if(mystafformembershipeid == ""){
		alert("You are required to sign");//signin to register staffs
		return false;
			}
		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //console.log(xhttp.responseText);
			    var bdayimages = ["Peach.png","Yellow and Pink Smiley Age Funny Birthday Card.png","Ha_Pea_Birthday-500x500.jpg","Superman-300.gif","Happy-Birthday-to-you-91-500x375.jpg","birthday-message-6-500x500.jpg","birthday-wishes-5-500x500.jpg","birthday-message-watercolour-image-500x500.jpg","Happy-Birthday-Beige-300.gif","My Post.png"];
			    
                localStorage.setItem("BuffbdayPhotos",JSON.stringify(bdayimages));
                
				setTimeout(function(){document.getElementById("birthdaybuffs").innerHTML = xhttp.responseText},1000);

            }
        };
		
	xhttp.open("POST","scripts/birthdayssuggests.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_mystafformembershipeid="+mystafformembershipeid);

}