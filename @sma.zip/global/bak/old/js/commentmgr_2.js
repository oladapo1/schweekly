function sendCommentonpost_o(commentpostid,commentload){
var mymembercommentid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembercommentid = mymembercommentid.memberid.toString();

var formData = new FormData();
formData.append("CommentedLoad", commentload);
formData.append("PostCommentedbyWho", mymembercommentid);
formData.append("CommentedPost", commentpostid);

let commntresponsespan2 = 'commentedresponse2';
let textareareactn2 = 'reactn2';
let countdownrnow2 = 'countdownr2';


var request = new XMLHttpRequest();
request.open("POST", "scripts/commentmgr.php");
request.onload = function(oEvent) {
	if (request.status == 200) {
	
	document.getElementById(commntresponsespan2).innerHTML = request.responseText;	
	setTimeout(function(){document.getElementById(countdownrnow2).value = '200';
	document.getElementById(textareareactn2).value = "";
	document.getElementById(commntresponsespan2).innerHTML = "";},2000);
	location.reload();	
	} else {
	console.log("Error " + request.status + " occurred when trying to upload");
	}
	};
request.send(formData);
}