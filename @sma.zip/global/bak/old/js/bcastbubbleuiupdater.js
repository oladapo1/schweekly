//bcastbubbleuiupdater.js
document.addEventListener("DOMContentLoaded",bubblenBcasthome,false);

//setInterval(bubblenBcasthome,3000);
function bubblenBcasthome(){
	 var getcounts = sessionStorage.getItem("MYbcastbubbleCOUNTs");
		//alert(t.length);
		//document.getElementById("msgsbubble").innerHTML = t;
	 
	 if(getcounts === null){
		 
		  alert("Not available");
		 		
	 }else{
		 //alert("available");
		let t = JSON.parse(getcounts);
		//alert(t.length);
		document.getElementById("msgsbubble").innerHTML = t;
	 }
}