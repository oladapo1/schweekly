//Use sessionStore to allow refresh to view 
window.addEventListener("load",function(){refreshForumTopicID()},false);

function refreshForumTopicID(){
	let pinneddtopicx = sessionStorage.getItem("fcontributntopic");
	let pinnedautorx = sessionStorage.getItem("frmcntribauthor");
	let pinnedtotalvwsx = sessionStorage.getItem("frmcntribttvws");
	sendForumTopicID(pinneddtopicx,pinnedautorx,pinnedtotalvwsx);
}

function sendForumTopicID(ftopicid,gtauthor,gttotalviews){
	
	let pinneddtopic = sessionStorage.setItem("fcontributntopic",ftopicid);
	let pinnedautor = sessionStorage.setItem("frmcntribauthor",gtauthor);
	let pinnedtotalvws = sessionStorage.setItem("frmcntribttvws",gttotalviews);
	
			//alert(ftopicid+" ok "+gttotalviews);
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			
			//alert(xhttp.responseText);
			document.getElementById("myforumcontribsload").innerHTML = xhttp.responseText;
	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","scripts/forum_pull_contributions.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_ftopicid=" +ftopicid+"&send_forumauthor="+gtauthor+"&send_totalviews="+gttotalviews);
}
