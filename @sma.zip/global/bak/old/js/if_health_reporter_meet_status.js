
/* 
function ny(logisticservprovider){
	
	alert(logisticservprovider.value);
} */
let myloupebtn = document.getElementById("myloupebtn");

myloupebtn.addEventListener("click",checkIfHealthReporterMeetsStatus,false);

function checkIfHealthReporterMeetsStatus(){
	
	let t1 = document.getElementById("ailmentfromdate");
	let t2 = document.getElementById("ailmenttodate");
	let t3 = document.getElementById("safehaven");//logisticservprovider
	//let t3 = document.getElementById("logisticservprovider");
	//alert(t1.value+" "+t2.value+" "+t3.value);
	
	if(t1.value == "" && t2.value == "" && t3.value == ""){
		
		alert("All fields requred");
		
	}
	//alert(t1.value+" "+t2.value+" "+t3.value);

	//alert(ailmentfromdate.value+"--"+ailmenttodate.value);
	
	let membermakingreprt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermakingreprt = membermakingreprt.memberid.toString();
	
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		console.log(xhttp.responseText);
		sessionStorage.setItem("AilmentData", '{"\CollatedAilment"\:['+this.responseText+']}');
		createProgressbars();
  	}
};

let sendfromdate = t1.value;
let sendtodate = t2.value;
let zoned = t3.value;

 /* Using POST */	 
xhttp.open("POST","scripts/if_health_reporter_meet_status.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//xhttp.send("sent_membr_ids="+memberdelsaved+"&sentitem_id="+item_id);
xhttp.send("sent_membr_ids="+membermakingreprt+"&sent_datefrom="+sendfromdate+"&sent_dateto="+sendtodate+"&membrzone="+zoned);	
}
