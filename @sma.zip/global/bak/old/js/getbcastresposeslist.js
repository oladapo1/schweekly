document.addEventListener("DOMContentLoaded",pullrecentBcastlist,false);
setInterval(pullrecentBcastlist,5000);
function pullrecentBcastlist(){

	let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();

	let mymembersoccupatn = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembersoccupatn = mymembersoccupatn.occupatntype;
	
	let mymembersspecializatn = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembersspecializatn = mymembersspecializatn.occuspecializatn;
	
	let mymemberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberzone = mymemberzone.zone;

	//alert(mymembershipeid +"="+mymembersoccupatn+"="+mymembersspecializatn+"="+mymemberzone);
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			document.getElementById("recentbcastlistdiv").innerHTML = xhttp.responseText;
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/getbcastresposeslist.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//xhttp.send("send_itemEdited=" +itemEditd +"&send_itemType=" +itemtype+"&send_pullmembersenderxid="+mymembershipeid);
xhttp.send("membr_idd="+mymembershipeid+"&membroccupatn="+mymembersoccupatn+"&membrspec="+mymembersspecializatn+"&membrzone="+mymemberzone);
}