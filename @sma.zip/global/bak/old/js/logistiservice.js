/* let btsave = document.getElementById("savelogisticservbtn");
btsave.addEventListener("click",function(){sendnewLogisticservc(0);},false); */

let btsend = document.getElementById("sendlogisticservbtn");
btsend.addEventListener("click",function(){sendnewLogisticservc(1);},false);

function sendnewLogisticservc(btnchoice){
let	gtsendorsave = btnchoice;

//alert(gtsendorsave);	
	
let memberusrlogistics = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
memberusrlogistics = memberusrlogistics.memberid.toString();
//memberusrlogistics = 332974;
let gtlogsprovidr = document.getElementById("logisticservprovider").value;
let gtsentfrmloc  = document.getElementById("sentfrmloc").value;
let gtdelivtoloc  = document.getElementById("delvtoloc").value;
let gttakeofftty  = document.getElementById("takeofftty").value;
let gtarrivalltty = document.getElementById("arrivalltty").value;
let gtaddanote    = document.getElementById("addanote").value;

var formData = new FormData();
formData.append("MembridServ",memberusrlogistics);
formData.append("ProviderServc",gtlogsprovidr);
formData.append("Sentfromloc",gtsentfrmloc);
formData.append("Delivrytoloc",gtdelivtoloc);
formData.append("Takeofftty",gttakeofftty);
formData.append("Expctdarrvltty",gtarrivalltty);
formData.append("ServicNotes",gtaddanote);
formData.append("Senttype",gtsendorsave);

if(gtaddanote === ""){
	alert("Some fields requires filling");
	return false;
}

var request = new XMLHttpRequest();
request.open("POST", "scripts/logistiservice.php");
request.onload = function(oEvent) {
	if (request.status == 200) {
	alert(request.responseText);
	//document.getElementById(commntresponsespan2).innerHTML = request.responseText;	
	/* setTimeout(function(){document.getElementById(countdownrnow2).value = '200';
	document.getElementById(textareareactn2).value = "";
	document.getElementById(commntresponsespan2).innerHTML = "";},2000); */
	location.reload();	
	} else {
	console.log("Error " + request.status + " occurred when trying to upload");
	}
	};
request.send(formData);
}