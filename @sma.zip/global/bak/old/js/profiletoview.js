var spanidcounter = -1;

function showUpdatedProfileData(){	
event.preventDefault(); 
//alert("Okas");	
  var profileprompterlen;
  var profileprompter = ["usurname","ufirstname","userpixl","userabout","usernamev","buffday","gendre","myzone","statelivn","pharmname","pharmaddr","pharmregId","emailcontact","psnphone","shophone"];
  
  var myprofile = ["lname","fname","photo","aboutpharm","usernickname","dobirth","gendr","zone","state","pharmacyname","pharmaddress","pharmregid","emailofpharm","telf1","telf2"];
    
  profileprompterlen = profileprompter.length;
  myprofilelen = myprofile.length;
  
  var mysa_usenderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  mysa_usenderid = mysa_usenderid.memberid.toString();
	
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
	//alert(this.responseText);
	pharmacistprofile = JSON.parse(this.responseText);
	
	document.getElementById(profileprompter[2]).src = "images/"+pharmacistprofile['photo'];
	 
	for (i = 0; i < myprofilelen; i++){
		x = myprofile[i];
		/* if(pharmacistprofile['gendr'] === "1"){
			document.getElementById(profileprompter[i]).innerHTML = "Female";
			//return false;
		}else if(pharmacistprofile['gendr'] === "2"){
			document.getElementById(profileprompter[i]).innerHTML = "Male";
		} */
			
		 document.getElementById(profileprompter[i]).innerHTML = pharmacistprofile[x];
		
	 }
  }
  };

 /* Using POST */
xhttp.open("POST","scripts/profiletoview.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_mysa_usenderid="+mysa_usenderid);
//xhttp.send();
}