var getmyeventsbtn= document.getElementById("getmyevents");
getmyeventsbtn.addEventListener("click",function(){loadmyPersonalEvents()},false);

function loadmyPersonalEvents(){

getmyeventsbtn.style.display = "none";

var mymembersenderxidev = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderxidev = mymembersenderxidev.memberid.toString();

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){ 
		//alert(xhttp.responseText);
		console.log(xhttp.responseText);
		if(xhttp.responseText == -1){
			//You have no events now
			 alert("You have no events now");
		}
		
	var myEventArrytObj = JSON.parse(xhttp.responseText);
	var elementary_sh ="";	
	
		for(i = 0; i < myEventArrytObj.length; i++){
			
			elementary_sh += "<tr><td>"+myEventArrytObj[i].eventtitle+"</td><td>"+myEventArrytObj[i].eventdate+"</td>"+"<td ><a href='#' style='margin-left:30px;' id='"+myEventArrytObj[i].eventid+"' onclick='getMyeventsOptIns(this.id)' class='ui-btn ui-icon-eye ui-btn-icon-notext'>Icon only</a></td></tr>";
					
			// attache to body
			document.getElementById("listmyeventstbl").innerHTML = elementary_sh;
		}
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pull_my_events.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_myid=" +mymembersenderxidev);	
}


function getMyeventsOptIns(gteventidoptedin){

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			console.log(this.responseText);
			let my_real_optins ="";	
			//myrealoptins
			var myRealOptinsAra = JSON.parse(xhttp.responseText);
			
			document.getElementById("myrealoptins").style.display = "block";
			for(i = 0; i < myRealOptinsAra.length; i++){
				//console.log(myRealOptinsAra.length);
				if(myRealOptinsAra[i].occupatntype == 0){
							career = "Pharmacist";
						}else if(myRealOptinsAra[i].occupatntype == 1){
						career = "Doctor";
						}else if(myRealOptinsAra[i].occupatntype == 2){
							career = "Lab. Scientist";
						}else if(myRealOptinsAra[i].occupatntype == 3){
							career = "Nurse";
						}else if(myRealOptinsAra[i].occupatntype == 4){
							career = "Dentist";
						}else if(myRealOptinsAra[i].occupatntype == 5){
							career = "Other";
						}
				
				//alert(myRealOptinsAra[i].fname);
				my_real_optins+= "<ul class='list-group' style='color:#fff;margin:1px;'><li class='list-group-item active'>"+myRealOptinsAra[i].fname +"-"+myRealOptinsAra[i].lname+"<small style='font-size:0.85em;color: #fff;'> <br>"+myRealOptinsAra[i].telf1+"-"+ myRealOptinsAra[i].emailofpharm+"<br>"+career+"</small></li></ul>";				
			// attache to body
			document.getElementById("myrealoptins").innerHTML = my_real_optins;
			 }		
            }
        };
		
	xhttp.open("POST","scripts/ev3nts_opt_ins.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_optin_ids="+gteventidoptedin);
}