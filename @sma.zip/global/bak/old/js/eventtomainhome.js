///////////////////////////////////////////////
var geteventsubmitbtn = document.getElementById("submitevent");
var geteventsformname = document.getElementById("eventsfrmid");

geteventsubmitbtn.addEventListener("click",function(){sendEventcontent(geteventsformname.name)},false);
function sendEventcontent(eventform){
	
	passtoEventsHandler(eventform);
	
	//passtoEventsHandler(postform.name);
}



function passtoEventsHandler(formposted){
	//alert(formposted+" okin2");
var form = document.forms.namedItem(formposted);

form.addEventListener('submit', function(ev) {
	
	var membersendingevent = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersendingevent = membersendingevent.memberid.toString();
	
	if(formposted === "eventsfrm"){
	
		folderToUploadeventimg = "../images/eventmedia";

	}
	else{
		alert("Voops!");
	}
 
  var oOutput = document.getElementById("displaysentmsg"),
      oData = new FormData(form);

  oData.append("EventUploadDir", folderToUploadeventimg);
  oData.append("Whosentvent", membersendingevent);
/*   oData.append("ImagefrompostFileInput", postpixfiletoupload);
  oData.append("PostLoad", postbody);
  oData.append("Exclusiiveto", onlyto); */

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/eventtomainhome.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;  
	  //setTimeout(cleanUp,2000);
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
    }
  };

  oReq.send(oData);
  ev.preventDefault();
}, false);
}


function cleanUp(){
	/* document.getElementById("postreactn").value = "";
	document.getElementById("mediatopost").value = "";
	document.getElementById("displaysent").innerHTML = "";
	document.getElementById("exclusiveonlyto").value = "-"; */
	//location.reload();
}



