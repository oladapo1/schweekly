  /*  var gtBtn = document.getElementById("mysse");
    gtBtn.onclick = pullMyNotifsToview; */
	
	
//setInterval(pullMyNotifsToview,5000);	

setTimeout(pullMyNotifsToview,3000);	
	
function pullMyNotifsToview(){
//alert(" am in");
var mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

pullconnectrequestNotifsToview(mysa_senderid);

var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			console.log(this.responseText);
			//document.getElementById("pheldr").innerHTML = this.responseText;
			sessionStorage.setItem("myNotifs", '{"\NotifItems"\:'+this.responseText+'}');
		
			placeEachNotiftolabel();
            }
        };
		
	xhttp.open("POST","scripts/notifmgr.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);

}

function pullconnectrequestNotifsToview(userID_o){

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//console.log(this.responseText);
			sessionStorage.setItem("myNotifs_CnReqst", '{"\NotifItems_CnReqs"\:'+this.responseText+'}');
			placeconnectrequestNotiftolabel();
            }
        };
		
	xhttp.open("POST","scripts/notif_connrequest.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("myconreqst_senderid="+userID_o);
}

var notifsumdtotal_o = 0;
function placeconnectrequestNotiftolabel(){

	//let labelconreq = ["requestbubble"];
	
	//let notifsumdtotal = 0;	
	var myObj_o = JSON.parse(sessionStorage.getItem("myNotifs_CnReqst"));
	var gtNotifslen_o = myObj_o.NotifItems_CnReqs.length -1;
	//alert(gtNotifslen_o);
	notifsumdtotal_o = gtNotifslen_o;
	document.getElementById("requestbubble").innerHTML = gtNotifslen_o;
	//document.getElementById(labelconreq[i]).innerHTML = gtNotifslen_o;
}

/*
$connrequest = 0;	//notiftype		
$connacceptstatus = 5;	//notiftype	
birthdaygreetn = 6/notiftype
..................................
Bcast = 2/rxn to bcasts
*ReactiontoBcast = 6/rxn to bcasts
comment = 7/notiftype
Posts 3/notiftype
Forum 1 
Events 4
System 8- Renewals,Emblem,Profile,
Chat 9
Podcast 10


$gthy = array("0","1","2","3");
*/
   
   /*  var gtBtn2 = document.getElementById("mynotifs");
    gtBtn2.onclick = placeEachNotiftolabel; */
function placeEachNotiftolabel(){
	/* let labelarray = ["requestbubble","connectnaccpt","birtdaynotifs","broadcastbubble","eventsbubble","comments","postbubble","forumbubble","eventsnotifs","sytemsnotifs","chatnotifs","notifbubble"]; */
	
	let labelarray = ["forumbubble","broadcastbubble","postbubble","eventsbubble","notifbubble"];
	
	let notifsumdtotal = 0;	
	var myObj = JSON.parse(sessionStorage.getItem("myNotifs"));
	var gtNotifslen = myObj.NotifItems.length;
	
	for(i = 0; i < gtNotifslen-1;i++){// minus 1 bcos of last item : Sealed;
		//alert(myObj.NotifItems[i]);
		//alert(labelarray[i]+" at "+myObj.NotifItems[i]);
		document.getElementById(labelarray[i]).innerHTML = myObj.NotifItems[i];
		notifsumdtotal += parseInt(myObj.NotifItems[i]);
	}
	
	document.getElementById(labelarray[4]).innerHTML = notifsumdtotal+notifsumdtotal_o;		
   }