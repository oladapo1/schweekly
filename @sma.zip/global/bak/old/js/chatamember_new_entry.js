function sendnewChatrnPostImg(postform){
	
	var txtv;		
	if(postform === "newchatr_inputfrm"){

		 txtv = document.getElementById("nbcastextarea_newchat");
		if( txtv.value == ""){
			alert("Cannot be empty");
			txtv.focus();
			return false;
		}
		//check the store for Chatted Member ID category key
		var isChat_ID_key_availableinstore = sessionStorage.getItem("MemberforNewChat");
		 if(isChat_ID_key_availableinstore === null){
			alert("You have not made any selection");
			return false;
		} 		
	}else{
		alert("Cannot process");
	}
	
	passtoPostHandlerv(txtv.value,postform,isChat_ID_key_availableinstore);	
}

function getRndIntegerv(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function passtoPostHandlerv(messagebcasted,formposted,member_id_topost){

	var form = document.forms.namedItem(formposted);

	let membermakingpost = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermakingpost = membermakingpost.memberid.toString();
	let mychatgenid = getRndIntegerv(1000000,9999999);
	//var exclusiveonlylen = JSON.parse(sessionStorage.getItem(vendortypechked));
	//var exclusiveonlyto = JSON.stringify(JSON.parse(sessionStorage.getItem(vendortypechked)));
	
	folderToUploadpostdimg = "../images/chatr";
   
  //var oOutput = document.getElementById("displaysent"),

  oData = new FormData(form);
  oData.append("Chatmsg", messagebcasted);
  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", membermakingpost);
  oData.append("WhoIspostfor", member_id_topost);
  //oData.append("Exclusiveonlylen", exclusiveonlylen.length); 
  //oData.append("WhoIspostfor", exclusiveonlyto);
  oData.append("NewChatCodegen_id", mychatgenid);
  

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/chatamember_new_entry.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  alert(oReq.responseText);	
	  console.log(oReq.responseText);
	  buildUIforNewChatNotifLookdup();// called from lookup_new_chat.js file
	  //location.reload();	  
	  //setTimeout(cleanUp,3000);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);


}

//setInterval(buildUIforNewChatNotifLookdup,5000);

document.addEventListener("DOMContentLoaded", function(){
	//check the store for New ChatMeta Load
		let isNewChatkeyavailable = sessionStorage.getItem("NewChatBuddy");
		 if(isNewChatkeyavailable === null){
			console.log("No new chat instance");
			sessionStorage.setItem("NewChatBuddy","");
			//return false;
		}else{
			
			//alert("ok");
			buildUIforNewChatNotifLookdup();
		}
		
},false);

var text = "";
var spec;

function buildUIforNewChatNotifLookdup(){

let memberlookuprqst = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberlookuprqst = memberlookuprqst.memberid.toString();
	
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		console.log(xhttp.responseText);
		sessionStorage.setItem("NewChatBuddy", this.responseText);
		
		/////////////////////////////////////////////////////////
		let getmetaload = JSON.parse(sessionStorage.getItem("NewChatBuddy"));
		//let topbanr2 = JSON.parse(sessionStorage.getItem("NewChatBuddy"));
		
		//alert(getmetaload.length);
		let chatnotifbubbleval = document.getElementById("chatnotifbubble")
		chatnotifbubbleval.innerHTML = getmetaload.length;
		
	//fname lname	photo occupatntype occuspecializatn
var imgpath = "../images/profileimages";

var occutypearray = ["Pharm.","Dr.","Lab. Sci.","Nrs.","Dentist","Others","Radiologists","Optometrists","Phlebotomist","Physio.","Occ. Thera.","Speech Thera.","Chiropractors","Osteopaths","Audiologists","Sample Col."];
//alert(occutypearray.length);

var occuspecpharm = ["ACPN","Acad.","Admin.","Industry"];

var occuspecdrs = ["Immunologist","Anesthesiologist","Cardiologist","ColonRectal Sur.","Dermatologist","Endocrinologist","Family Phy.","Gastroenterologist","Geriatrician","Hematologist","Nephrologist","Neurologist","ObGyn","Oncologist","Ophthalmologist","Osteopath","Otolaryngologist","Pathologist","Pediatrician","Physiatrist","Plastic Sur.","Podiatrist","Psychiatrist","Pulmonologist","Radiologist","Rheumatologist","General Sur.","Urologist"]

//var spec;

for(i=0;i < getmetaload.length; i++){

//alert(getmetaload[i].occupatntype);
switch(getmetaload[i].occupatntype){
	
	case '0':
	spec = occuspecpharm[getmetaload[i].occuspecializatn];
	//alert(getmetaload[i].occupatntype);
	//alert(getmetaload[i].occuspecializatn);
	break;
	case '1':
	spec = occuspecdrs[getmetaload[i].occuspecializatn];
	break;
	case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case '10':  case '11': case '12': case '13': case '14': case '15':
	spec = "";//occuspecpharm[getmetaload[i].occuspecializatn];
	break;
	default:
	alert("Not in category");
	
}


text += "<li class='collection-item avatar'><img src='"+imgpath+'/'+getmetaload[i].photo+"' alt='' class='circle' style='width:36px;height:38px;'>&nbsp;<span class='title' style='font-weight:700;color:#ffcb05;font-size:0.75em;'>"+occutypearray[getmetaload[i].occupatntype]+"</span>&nbsp;<span style=''>"+getmetaload[i].lname+" "+getmetaload[i].fname+"</span><p style='font-weight:700;font-size:0.8em;'>"+spec+"<br>.</p> <a href='#!' class='secondary-content'><span class='badge #eceff1 blue-grey lighten-5'"+" style='border-radius:10px;color:#607d8b;' id='"+i+"'></span></a></li>";

document.getElementById("chatbuddylistingscols").innerHTML = text;

}		
		/////////////////////////////////////////////////////////	
  	}
};

 /* Using POST */	 
xhttp.open("POST","scripts/lookup_new_chat.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("sent_membr_id="+memberlookuprqst);
}

function cleanUpv(){
	document.getElementById("").value = "";
	document.getElementById("").value = "";
	document.getElementById("").innerHTML = "";
	document.getElementById("").value = "-";
}