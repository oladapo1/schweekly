function sendrepliesasForumviews(ftopic){
//alert(ftopic);
	
var gtmembersridvw = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersridvw = gtmembersridvw.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			//document.getElementById("").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/forumtopicrepliestoviewsinsert.php",true);
	//xhttp.open("POST","scripts/forum_pull_contributions.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_id_membrviews="+gtmembersridvw+"&send_id_ftopic="+ftopic);
}