let statuschkbtn = document.getElementById("completionstatuschkr");
statuschkbtn.addEventListener("click",passMemberidforClearanceStustuschek,false);
function passMemberidforClearanceStustuschek(){
	
	let membermstatuschkr = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membermstatuschkr = membermstatuschkr.memberid.toString();
	//alert(membermstatuschkr);
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				document.getElementById("displaysubmissionlist").innerHTML = xhttp.responseText;
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/completionstatuschecker.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_membr_uiid=" +membermstatuschkr);
	
}