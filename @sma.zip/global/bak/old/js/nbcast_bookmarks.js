function makeabcastBookmark(bkmark,exclusiveto){
//alert(bkmark+"--"+exclusiveto);
	var membersnbcastbkmark = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersnbcastbkmark = membersnbcastbkmark.memberid.toString();	
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        var mytargetelm = "bookmarkit"+bkmark;
    if (this.readyState == 4 && this.status == 200){  
				
		alert(this.responseText);
		console.log(this.responseText);
		if(this.responseText === "Bookmarked successfully"){
		    
		    document.getElementById(mytargetelm).innerHTML = "<i class='material-icons' style='cursor:pointer;font-size:1.1em;width:3%;'>bookmark</i>";
		    
		}else if(this.responseText === "Bookmark unset successfully"){
		    
		    document.getElementById(mytargetelm).innerHTML = "<i class='material-icons' style='cursor:pointer;font-size:1.1em;width:3%;'>bookmark_border</i>";
		    
		}
		//document.getElementById("").innerHTML = this.responseText;
		
  	}
	};
	
	 /* Using POST */
xhttp.open("POST","scripts/nbcast_bookmarks.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_membrid="+membersnbcastbkmark+"&send_bkmarkid="+bkmark+"&send_exclusiveto="+exclusiveto);
}