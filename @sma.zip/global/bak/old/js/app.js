// Define the `phonecatApp` module
var phonecatApp = angular.module('phonecatApp', []);