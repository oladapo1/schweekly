var acpnmemberloginbtn = document.getElementById("acpnmemberloginbtn");

acpnmemberloginbtn.onclick = chkloginLoad_ifempty;

function chkloginLoad_ifempty(){
//alert("Okay");
var gtLoginUname = document.getElementById("usr_regd_email").value;
var gtLoginPasskey = document.getElementById("usr_regd_pwd").value;


if(gtLoginUname == "" || gtLoginPasskey == ""){
	
	alert("All fields are required to proceed");
	//document.getElementById("login_owaun").focus();
	return false;
	
	}else{
		
		muv_login_Up(gtLoginUname,gtLoginPasskey);
		//alert(gtLoginUname + " -- " + gtLoginPasskey);
	}
}

function muv_login_Up(acpnUname,acpnPasskeyr){
	
	//alert(acpnUname+"--"+acpnPasskeyr);
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
			//alert(xhttp.responseText);		
			console.log(xhttp.responseText);		
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				if(xhttp.responseText == 0){ //from logincheckstatusdotphp
					location.href = "pendingapproval.html";
				}else if(xhttp.responseText == -1){//from login_verifystatusdotphp
					location.href = "acctactivation.html";
				}else if(xhttp.responseText === "User does not exist"){
					alert("User does not exist");//from login_komaalo
					location.reload();
				}else if(xhttp.responseText === "check passkey"){
					alert("check passkey");//from login_komaalo
					location.reload();
				}else{//login
			
				sessionStorage.setItem("MYPersonalVALUES",xhttp.responseText);
				let topbanr2 = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
				topbanrsytm = topbanr2.topbanrsystm;
				sessionStorage.setItem("topbanrbysystem",topbanrsytm); //also set in /topbanner_preselectn.js
				/* var mymembersid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
				mymembersid = mymembersid.memberid.toString(); */ 
				createinitLoadmorevalue();
				//checkDelegatedStatus(mymembersid);
				location.href = "omni.php"; // ENSURE to create asession in php
				
				}
			}else{
				//location.reload();
				alert("Critical");
				//alert(xhttp.responseText);
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/login_komaalo.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +acpnUname + "&send_lg_Pwd=" +acpnPasskeyr);
	
}


function createinitLoadmorevalue(){
	
	sessionStorage.setItem("LOADMORElim","0");
	//checkDelegatedStatus();
}
/* 
function checkDelegatedStatus(){
//alert(membersid);
//let mymembersid = 133944;
var mymembersid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersid = mymembersid.memberid.toString();
//alert(mymembersid);
  var oData = new FormData();

  oData.append("send_membrid", mymembersid);
    //alert(mymembersid);
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/checkdelegatedstatus.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //alert(oReq.responseText);
	  console.log(oReq.responseText);
	  
		if(oReq.responseText == "Exists"){
			sessionStorage.setItem("AMDELEGATED","1");
			
		}else if(oReq.responseText == "Does not Exists"){
			sessionStorage.setItem("AMDELEGATED","0");
		}else{
			console.log("Issues setting delegate status");
		}
	  //setTimeout(location.reload(),3000);
    } else {
     alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);
} */
