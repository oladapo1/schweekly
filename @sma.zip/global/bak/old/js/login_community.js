var communtymemberloginbtn = document.getElementById("communtyloginbtn");

communtymemberloginbtn.onclick = chkcommntyloginLoad_ifempty;

function chkcommntyloginLoad_ifempty(){

var gtcomLoginUname = document.getElementById("usr_login_com").value;
var gtcomLoginPasskey = document.getElementById("password_login").value;


if(gtcomLoginUname === "" || gtcomLoginPasskey === ""){
	
	alert("All fields are required");
	//document.getElementById("login_owaun").focus();
	return false;
	
	}else{
		
		muv_comlogin_Up(gtcomLoginUname,gtcomLoginPasskey);
	}
}

function muv_comlogin_Up(yesbacomUname,yesbacomPasskeyr){
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
			//alert(xhttp.responseText);		
			console.log(xhttp.responseText);		
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				if(xhttp.responseText === "0"){ //not yet verified
					location.href = "../acctactivatecommunity.html";
				}else if(xhttp.responseText === "User does not exist"){
					alert("User does not exist");//from login_komaalo
					//location.reload();
				}else if(xhttp.responseText === "check passkey"){
					alert("check passkey");//from login_komaalo
					//location.reload();
				}else{//on login
				sessionStorage.setItem("COMMUNITYMEMBERload",xhttp.responseText);
				location.href = "m_community.php"; // ENSURE to create asession in php
				
				}
			}else{
				//location.reload();
				alert("Critical");
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/login_komaalo_com.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_lg_Uname=" +yesbacomUname + "&send_lg_Pwd=" +yesbacomPasskeyr);
	
}