var gtmemberenewalbtn = document.getElementById("renewalclearancebtn");
var getrenewformname = document.getElementById("acpnclearanceform"); //get form id to retrieve form name
var membrpassport = document.getElementById("membr_passport");
var renewformname = document.getElementById("acpnclearanceform");
const fileUploadLimit = 102400; // 100kb 


gtmemberenewalbtn.addEventListener("click",function(){

	checkmemberPassport();

},false);

function checkmemberPassport(){
	
	if(membrpassport.files.length == 0){
	alert("No passport image selected");
	return false;
	
	}else{	
	
	//converttobase64-passport
	convertoBase64Image(membrpassport);
	
	let member_pssportbase64 = sessionStorage.getItem("Membrpassportdata");

	if(member_pssportbase64 == null){
		  
		  console.log("Passport not yet in store-check again");
		  //setTimeout(console.log("mark time-ensuring passport is attached"),5000);
		  //return false;
		  
	  }
	} 
}

//function to convert passport to base64 image
var imageData = [];
var localStorageKey = "Membrpassportdata";
function convertoBase64Image(e){

		const file =  e.files[0];
		if (file.size <= fileUploadLimit) {
		  const reader = new FileReader();

		  reader.onloadend = () => {
			const base64String = reader.result
			  .replace('data:', '')
			  .replace(/^.+,/, '');

			// Create an object containing image information.
			let imageObj = {
			  name: "image-" + file.name,
			  timestamp: Date.now(),
			  file_base64: base64String.toString()
			};
			
		  // console.log(imageObj.file_base64);
			addImage(imageObj);			
			
		  let renew_formname = renewformname.name;
		  passMembershipRenewaldata(renew_formname);
		  
		  };

		  reader.readAsDataURL(file);
		} else {
		//upload.after("<p>File too large</p>");
		  alert("Passport File too large! - max size allowed is 100kb");
		}	
}

function addImage(imageObj) {
  imageData.push(imageObj);
  sessionStorage.setItem(localStorageKey, JSON.stringify(imageData));
}

function passMembershipRenewaldata(renewformname){
var form = document.forms.namedItem(renewformname);

  let membermakingrenewal = document.getElementById("membr_pcnnumbr");
  let memberdeclaration = document.getElementById("declartion_info");
  
  if(membermakingrenewal.value === ""){
	  alert("fill in pcn_id");
	  return false;
  }
  
   if(memberdeclaration.checked === false){
	  alert("check the declaration info box");
	  return false;
  }
  
  
  let signatureimg = sessionStorage.getItem("Signatureimg");
  
  if(signatureimg == null){
	  
	  alert("signature not in store");
	  return false;
	  
  }

	let memberpssportbase64 = sessionStorage.getItem("Membrpassportdata");

		if(memberpssportbase64 == null){
		  
		  alert("Passport not yet in store-try submit again");
		  return false;
		  
	  }
	  
	let img_data = JSON.parse(memberpssportbase64);
	let	passport = img_data[0].file_base64;//get the image item
 
   var oOutput = document.getElementById("logrenewalrqst"),
  oData = new FormData(form);

  oData.append("Passport_Bs_64", passport);
  oData.append("Signatureimg", signatureimg);
  oData.append("Memberuid", membermakingrenewal.value);//use pcnid for now
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "../scripts/clearanceformhandler.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
	  console.log(oReq.responseText);	  
	  alert(oReq.responseText); 
    } else {
	  alert("Error occurred when trying to upload your file.<br>");
    }
  };

  oReq.send(oData);
}

//check the document page load- apply available metadata in store
document.addEventListener("DOMContentLoaded",function(){
//let mdata = "document.getElementById("careertype").innerHTML";	
let usedata_cue = sessionStorage.getItem("usemydata");
  if(usedata_cue == null){
	  
	  console.log("usedata_cue not in store");
	  return false;
	  
  }
  
  let membrdata = sessionStorage.getItem("memberHistorydata");
  if(membrdata == null){
	  
	  console.log("membrdata not in store");
	  return false;
	  
  }else{
	let mdataarry = ["membr_pcnnumbr","membr_fname","membr_lname","membr_homeaddr","membr_officetel","membr_whatsapp","membr_email","membr_almamater","membr_yrgraduated","membr_othrqualifc","membr_premisaddr","membr_premiseaddrnow","membr_emblemnumbr"];
	
	//let xt = ["membrpcnnumbr","membrhomeaddr","membrofficetel"];	
	let my_personal = JSON.parse(membrdata);
	document.getElementById(mdataarry[0]).value = my_personal[1].membrpcnnumbr;
	document.getElementById(mdataarry[1]).value = my_personal[1].membrfname;
	document.getElementById(mdataarry[2]).value = my_personal[1].membrlname;
	document.getElementById(mdataarry[3]).value = my_personal[1].membrhomeaddr;
	document.getElementById(mdataarry[4]).value = my_personal[1].membrofficetel;
	document.getElementById(mdataarry[5]).value = my_personal[1].membrwhatsapp;
	document.getElementById(mdataarry[6]).value = my_personal[1].membremail;
	document.getElementById(mdataarry[7]).value = my_personal[1].membralmamater;
	document.getElementById(mdataarry[8]).value = my_personal[1].membryrgraduated;
	document.getElementById(mdataarry[9]).value = my_personal[1].membrothrqualifc;
	document.getElementById(mdataarry[10]).value = my_personal[1].membrpremisaddr;
	document.getElementById(mdataarry[11]).value = my_personal[1].membrpremiseaddrnow;
	document.getElementById(mdataarry[12]).value = my_personal[1].membremblemnumbr;
	document.getElementById("mysignaturelabel").src = my_personal[1].siganturblob;
	document.getElementById("declartion_info").checked = true;
	//remember to save the signature 
	sessionStorage.setItem("Signatureimg",my_personal[1].siganturblob);
  }
 
},false);
