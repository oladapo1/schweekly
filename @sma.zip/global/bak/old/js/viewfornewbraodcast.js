function pullrecentBcastlistfullview(bcastid){

	sessionStorage.setItem("BcastOrgID",bcastid);
	
	document.getElementById("viewforbraodcast").innerHTML = "Loading...";
	
	let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			document.getElementById("viewforbraodcast").innerHTML = xhttp.responseText;
	    }
		//this.preventDefault();
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/viewfornewbraodcast.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("memberID="+mymembershipeid+"&bcastID="+bcastid);
}