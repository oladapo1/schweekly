
//function to send to php handler the selected/added SuggestedConnection 
function sendSelectedSuggestedConnectntohandler(tobeconnectedto_id){

var mypersonal_id = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
//alert(typeof mypersonal_id.memberid);
mypersonal_id = JSON.stringify(mypersonal_id.memberid);
//alert(typeof mypersonal_id.memberid);

//alert(mypersonal_id.memberid+"----"+connection_id);
//JSON.stringify();
//var connectionselected = JSON.parse(sessionStorage.getItem("PullsuggestedConnectionstostore")); 

   var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			
			alert(this.responseText);
			
			//sessionStorage.setItem("PullsuggestedConnectionstostore", '{"\SugestedConnectionData"\:'+this.responseText+'}');;
		  //loadtoviewSuggestedConnectns();
				
            }
        };
		
	xhttp.open("POST","scripts/sendselectedconnection.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_mypersonalid="+mypersonal_id+"&send_newconnctreq="+tobeconnectedto_id);
}