document.addEventListener("DOMContentLoaded",pullmyBcastresponsesforview,false);
var btnmybcastviews = document.getElementById("mybcastviews");
btnmybcastviews.addEventListener("click",pullmyBcastresponsesforview,false);

function pullmyBcastresponsesforview(){

	let mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			//console.log(xhttp.responseText);
			//alert(xhttp.responseText);
			//var obj = JSON.parse(xhttp.responseText);
			//alert(obj[1]);
			//document.getElementById("msgsbubble").innerHTML = obj[0];
			  document.getElementById("").innerHTML = xhttp.responseText;
	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/mynbroadcastdetails.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("membr_idod="+mymembershipeid);
}