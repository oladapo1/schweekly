function sendCommentratedval(gtcommentid,gtratedval){
	if(gtratedval == 0){
		alert("rate from 1 - 5");
		return false;
	}
let membrater = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
membrater = membrater.memberid.toString();

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			
			alert(xhttp.responseText);
			//document.getElementById("postscommntersload").innerHTML = xhttp.responseText;
			
	    }
	};

	 /* Using POST */
	 
xhttp.open("POST","scripts/commentedvalues.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_comtidtorate=" +gtcommentid+"&send_ratedval="+gtratedval+"&send_membrratrid="+membrater);
}
