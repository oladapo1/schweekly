/*mylgaexperts
othelgaexperts
rsdaily
mymessages

my_view_result
........................*/
//var occutypearray = ["",""];
var addnewform_inline = document.getElementById("newform_inlines");
//View my health experts

//let viewepxertinmylga    = document.getElementById("mylgaexperts");
let viewexpertinotherlga = document.getElementById("othelgaexperts");
let carrier_hexperts = '<ul class="collection" style="margin:-15px;">';//'<h4 class="card-title">View Health Experts in ... </h4>';
//let carrier_hexpertlists = '<ul class="collection" style="margin:-15px;">';
let m_lga    = "my LGA";
let othr_lga = "other LGA";
let slct = document.getElementById("lgahealthexperts");
var isitmylaga = null;
            
//viewepxertinmylga.addEventListener("click",function(){
    //addnewform_inline.innerHTML = "";
    //slct.length.selectedIndex = "6";
    //var flipsarr =["areubornagain","areuspritfilld","willuliketobecalled"];
	//let lenflips = flipsarr.length;
	//alert(slct.length);
	/*lenflips = slct.length;
	for(i = 0; i < lenflips; i++){
    slct[0].selectedIndex = 0;
	}*/
    //document.getElementById("lga_type").innerHTML = m_lga;
    //document.getElementById("fromcommuembrlga").style.display = "block";
    //isitmylaga = 1;
    
//},false);
/*viewexpertinotherlga.addEventListener("click",function(){
    addnewform_inline.innerHTML = "";
    //slct.selectedIndex = "6";
    document.getElementById("lga_type").innerHTML = othr_lga;
	document.getElementById("fromcommuembrlga").style.display = "block";
	isitmylaga = 0;
    
},false);*/

slct.addEventListener("change",pulltoviewmyLGAhealthexperts,false);

function pulltoviewmyLGAhealthexperts(){
    //alert(slct.selectedIndex);
    //alert(isitmylaga);
    let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
	
	let mycommmemberlga = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmemberlga = mycommmemberlga.commusr_lga.toString();
	let isitonlymy_lga = isitmylaga;
	let selectedexpert = slct.value;//slct.selectedIndex;
	
	
	
	//alert(mycommmembershipeid);
    //to do - isolate the lga types and use to collate the h_experts to view
    //addnewform_inline.innerHTML = "";
	//let m_lga    = "my LGA";
	//let othr_lga = "other LGA";
    //
		/*if(lgatype === 1){
		    document.getElementById("lga_type").innerHTML = m_lga;
		    document.getElementById("fromcommuembrlga").style.display = "block";
		}else if(lgatype === 2){
	        document.getElementById("lga_type").innerHTML = othr_lga;
		    document.getElementById("fromcommuembrlga").style.display = "block";
		}*/


    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            console.log(xhttp.responseText);
            //alert(xhttp.responseText);
			//sessionStorage.setItem("HealthExperts", '{"\CollatedByLGA"\:['+this.responseText+']}');
			sessionStorage.setItem("HealthExperts",this.responseText);
			//to do fix in function to splice off experts in list from the sent list
			createLGAexpertview();
            }
        };
		
	xhttp.open("POST","scripts/comm_healthexpertbylgas.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_mycommmembershipeid="+mycommmembershipeid+"&send_lga="+mycommmemberlga+"&isitonlymy_lga="+isitonlymy_lga+"&send_expert="+selectedexpert);
}

function createLGAexpertview(){
    carrier_hexperts = '<ul class="collection" style="margin:-15px;">';
    let items = JSON.parse(sessionStorage.getItem("HealthExperts"));
    //addnewform_inline.innerHTML = carrier_hexperts;
    //alert(items.length); [{"NOHAY":"No health expert available here yet"}]
    //if(items[0].NOHAY === "No health expert available here yet"){
    if(items[0].NOHEAHY){
         carrier_hexperts += '<li class="collection-item"><p style="font-size:0.85em;font-weight:700;">No health expert available here yet</p></li>';
    }else{
        for(i = 0; i < items.length; i++){
        
    carrier_hexperts += '<li class="collection-item avatar" id="parent_li'+items[i].memberid+'"><img src="../images/profileimages/'+items[i].photo+'"'+' class="circle" style=""><span class="title"></span><p style="font-size:0.85em;font-weight:700;"><br>'+items[i].lname +" "+ items[i].fname+'</p><a href="#!" class="secondary-content"><i class="material-icons" style="font-size:1.65em;margin:0px 1px 0px 4px;" id="'+items[i].memberid+'" onclick="addHealthExperttolist(this)">add_box</i></a></li>';
        
        //{"occupatntype":"0","lga":"17","photo":"pixdefault.png","memberid":"446508","fname":"Oluremi","lname":"Osinowo"}]
    }
    }
    addnewform_inline.innerHTML = carrier_hexperts;
}

//My daily symptoms
let rs_daily = document.getElementById("rsdaily");
rs_daily.addEventListener("click",fillinnewRSDform,false);
//let adddailysymptomreport = ;
let carrier_rdsymptoms = '<h4 class="card-title" style="font-size:0.95em;font-weight:700;">My Daily Symptoms </h4><form id="anewsymptomadd_form" name="anewsymptomadd_form"><div class="form-floating"><textarea class="form-control" placeholder="How are you feeling today? &#128516 &#128567;" id="mytxtareahowifeel" name="mytxtareahowifeel" style="height: 100px;background-color:#f1f1f1;"></textarea><label for="mytxtareahowifeel">Symptom</label></div><div class="input-group mb-3"><div class="file-field input-field"><div class="btn"><span>PIC.</span><input type="file" id="symptomattachmnt" name="symptomattachmnt"></div><div class="file-path-wrapper"><input class="file-path validate" type="text"></div></div><label><input type="checkbox" id="myprefhexpert" name="myprefhexpert"/><span style="font-size:0.95em;color:#101010;">Only for health experts in my list.</span></label></div><button class="btn btn-outline-secondary btn-small" type="button" id="mydsrbtn" onclick="dailySymptomreporter(this);">Send</button> <button class="btn btn-outline-primary btn-small" type="reset">Clear</button></form>';
rs_daily.onclick = fillinnewRSDform;
//	128567	1F637	 	FACE WITH MEDICAL MASK
function fillinnewRSDform(){
	
	//document.getElementById("fromcommuembrlga").style.display = "none";
	
	addnewform_inline.innerHTML = carrier_rdsymptoms;
	
		//let sendnewhworkdatabtn = document.getElementById("myhomeworkbtn");
		//sendnewhworkdatabtn.addEventListener("click",function(){
		
		//alert("ok Hwork");
		
		//},false);
}
 
 var keepmodcount = 0;
  // Daily Symptom in Modal
document.addEventListener('DOMContentLoaded', function() {
    
    var elemsmodal = document.querySelectorAll('.modal');
    var instancesmod = M.Modal.init(elemsmodal, {});
    let gmod = document.getElementById("modal1");
    var instance = M.Modal.getInstance(gmod);
    
    let drsmod1ce = JSON.parse(sessionStorage.getItem("ShowDSRmodalonce"));
    
    if(drsmod1ce === 0){
     instance.close();
     instance.destroy();
    }else{
        instance.open();
    }
    sessionStorage.setItem("ShowDSRmodalonce",keepmodcount);
    //sessionStorage.setItem("ShowDSRmodalonce",drsmod1ce);
    
    let modalcontent = document.getElementById("dailysymptominmodal");
    modalcontent.innerHTML = carrier_rdsymptoms;
    
    let clsbtn = document.getElementById("clsrdailyinmodal");
    clsbtn.onclick = function(){
        instance.close();
        instance.destroy();
    }
    
    //alert(typeof (instance));
  }); 
 
 // add health expert to mylist
 
 function addHealthExperttolist(selectedexpertid){
     //alert(selectedexpertid.id);
      let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
	
     var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            let parent_li = "parent_li"+selectedexpertid.id;
            console.log(xhttp.responseText);
            //alert(xhttp.responseText);
			//sessionStorage.setItem("HealthExperts",this.responseText);
			if(xhttp.responseText === "1"){
			 alert("New health expert added to your list successfully");
			 document.getElementById(parent_li).style.display = "none";
			 navigator.vibrate(200);
			}else if(xhttp.responseText === "0"){
			 alert("Health Expert already in list");   
			}
			collatetoViewMyhexpertlist();
        }
        };
	
	xhttp.open("POST","scripts/add_healthexperttolist.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipeid="+mycommmembershipeid+"&send_expert_id="+selectedexpertid.id);
 }
 
 //remove health expert from mylist
 function removeHealthExpertinlist(selectedexpertid){
     
     //alert(selectedexpertid.id);
      let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
	
     var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            let parent_lst = "parent_lst"+selectedexpertid.id;
            console.log(xhttp.responseText);
            //alert(xhttp.responseText);
			
			if(xhttp.responseText === "1"){
			 alert("Health expert removed from your list successfully");
			 document.getElementById(parent_lst).style.display = "none";
			 navigator.vibrate(200);
			}else if(xhttp.responseText === "0"){
			 alert("Cannot remove Health Expert");   
			}
			collatetoViewMyhexpertlist();
        }
        };
	
	xhttp.open("POST","scripts/remove_healthexperttolist.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipeid="+mycommmembershipeid+"&send_expert_id="+selectedexpertid.id);
 }

 //Initial loading to store is rqd use domcontload
 document.addEventListener("DOMContentloaded",collatetoViewMyhexpertlist(),false);
 function collatetoViewMyhexpertlist(){
     //alert("joop!");
      let gt_mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	gt_mycommmembershipeid = gt_mycommmembershipeid.user_uid.toString();
     
     //alert(gt_mycommmembershipeid);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

            //console.log(xhttp.responseText);
            //alert(xhttp.responseText);
            sessionStorage.setItem("HealthExpertsinlist",this.responseText);
            let listcount = JSON.parse(sessionStorage.getItem("HealthExpertsinlist"));
            document.getElementById("lists_notifbubble").innerHTML = listcount.length;
        }
        };
	
	xhttp.open("POST","scripts/collate_healthexperttostore.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipe_id="+gt_mycommmembershipeid);
 }
 
  //////////////////////////////////////////////////////////////////////////////
 let list_mnu = document.getElementById("mylists");
 list_mnu.addEventListener("click",addHealthExperttolistview,false);
  function addHealthExperttolistview(){
    let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
    carrier_hexpertlists = '<ul class="collection" style="margin:-15px;">';
     let listcount = JSON.parse(sessionStorage.getItem("HealthExpertsinlist"));

       for(i = 0; i < listcount.length; i++){
    carrier_hexpertlists += '<li class="collection-item avatar" id="parent_lst'+listcount[i].memberid+'"><img src="../images/profileimages/'+listcount[i].photo+'"'+' class="circle" style=""><span class="title"></span><p style="font-size:0.85em;font-weight:700;"><br>'+listcount[i].lname +" "+ listcount[i].fname+'</p><a href="#!" class="secondary-content"><i class="material-icons" style="font-size:1.65em;margin:0px 1px 0px 4px;" id="'+listcount[i].memberid+'" onclick="removeHealthExpertinlist(this)">clear</i> <i class="material-icons" style="font-size:1.65em;margin:0px 1px 0px 4px;" onclick="openForm('+listcount[i].memberid+');">chat</i></a></li>';
     }
     addnewform_inline.innerHTML = carrier_hexpertlists;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  
 setInterval(fillBubbleforhexlist,3000);
 function fillBubbleforhexlist(){
     collatetoViewMyhexpertlist();
     let listcount = JSON.parse(sessionStorage.getItem("HealthExpertsinlist"));
     //alert(listcount.length);
     document.getElementById("lists_notifbubble").innerHTML = listcount.length;
     
 }

function openForm(indexofhexpert) {
    let msgbox = '<div class="chat-popup" id="myForm"><form id="mymessagingfrm" name="mymessagingfrm" class="form-container"><label for="msg"><b>Message : <span id="msgforhex_lbl" style="color:#101010;"></span></b></label><textarea placeholder="Type message.." name="msg" id="commtohexmsgstxtarea" name="commtohexmsgstxtarea" required></textarea><button type="submit" class="btn col s6" style="font-size:0.9em !important;" id="submitmsg">Send</button><button type="button" class="btn col s6 cancel" onclick="closeForm()" style="font-size:0.9em !important;">Close</button></form></div>'; 
    addnewform_inline.innerHTML = msgbox;
    let labelhexprt = JSON.parse(sessionStorage.getItem("HealthExpertsinlist"));
    //alert(labelhexprt.length);
    
    for(i = 0;i < labelhexprt.length; i++){
        let k = labelhexprt[i].memberid;
        if(indexofhexpert == k){
            document.getElementById("msgforhex_lbl").innerHTML = labelhexprt[i].lname +" "+labelhexprt[i].fname;
        break;
        }
      }
    
    let submimsgbtn = document.getElementById("submitmsg");
    submimsgbtn.addEventListener("click",function(){
        //commtohexmsgstxtarea commembrid hexuid
    let txtmsgvalue = document.getElementById("commtohexmsgstxtarea").value;
    let mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	mycommmembershipeid = mycommmembershipeid.user_uid.toString();
        //indexofhexpert
        //alert(txtmsgvalue +"-"+indexofhexpert+"-"+mycommmembershipeid);
        if(txtmsgvalue === ""){alert("field cannot be empty");}
         var xhttp = new XMLHttpRequest();
         xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

            console.log(xhttp.responseText);
            alert(xhttp.responseText);
        }
        };
	//alert(txtmsgvalue +"-"+indexofhexpert+"-"+mycommmembershipeid);
	xhttp.open("POST","scripts/comm_msg_to_healthexpert.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipe_id="+mycommmembershipeid+"&send_msgload="+txtmsgvalue+"&send_expertid="+indexofhexpert);
        
    },false);
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}


document.addEventListener("DOMContentloaded",collatetoViewMyMsgReplystostore(),false);
 function collatetoViewMyMsgReplystostore(){
    let gt_mycommmembershipeid = JSON.parse(sessionStorage.getItem("COMMUNITYMEMBERload"));
	gt_mycommmembershipeid = gt_mycommmembershipeid.user_uid.toString();
     var ht = "<p>";
     //alert(gt_mycommmembershipeid);
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

            console.log(xhttp.responseText);
            //alert(xhttp.responseText);
            sessionStorage.setItem("MessageReplies",this.responseText);
            let msgbb = JSON.parse(sessionStorage.getItem("MessageReplies"));
            
            document.getElementById("msgs_notifbubble").innerHTML = msgbb.length;
        }
        };
	
	xhttp.open("POST","scripts/collate_messageresplied.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipe_id="+gt_mycommmembershipeid);
 }
 
  let message_mnu = document.getElementById("mymessages");
 message_mnu.addEventListener("click",collatetoViewMyMsgReplys,false);
 
 function collatetoViewMyMsgReplys(){
     
      addnewform_inline.innerHTML = "";
    /*
    [{"Fname":"Chioma","Lname":"Adetuyi","Photo":"IMG_20201108_155807_493.jpg","Career":"0","LGA":"","MemberID":"933335","Replies":"Saw your message will reply asap"}]*/
    
    carrier_hexpertreplys = '<ul class="collection" style="margin:-15px;">';
     let replycount = JSON.parse(sessionStorage.getItem("MessageReplies"));

    for(i = 0; i < replycount.length; i++){
    carrier_hexpertreplys += '<li class="collection-item avatar" id="messg_lst'+replycount[i].MemberID+'"><img src="../images/profileimages/'+replycount[i].Photo+'"'+' class="circle" style=""><span class="title"></span><p style="font-size:0.85em;font-weight:700;"><br>'+replycount[i].Lname +" "+ replycount[i].Fname+'<br>'+replycount[i].Replies+'<hr> date: '+replycount[i].Replydate+'</p><a href="#!" class="secondary-content"><i class="material-icons" style="font-size:1.65em;margin:0px 1px 0px 4px;" id="messg_lst'+replycount[i].MsgUID+'">chat</i></a></li>'; 
     }
     addnewform_inline.innerHTML = carrier_hexpertreplys;
 }
 
//Messages menu  messages_mnu
/*
let message_mnu = document.getElementById("messages_tcher_mnu");
let carrier_msg_mnu = '<h4 class="card-title">Create New Message</h4>';

message_mnu.onclick = displayMessagesformnLists;

function displayMessagesformnLists(){
	
	addnewform_inline.innerHTML = carrier_msg_mnu;
	
		let frm_name = document.getElementById("messagesnewadd_form").name;
		let pic_id   = document.getElementById("messagesattachmnt").id;
		let sendmsgdatabtn = document.getElementById("mynewmessagebtn");
		
		sendmsgdatabtn.addEventListener("click",function(){
		
		determime_msg_frm_Img_Catgo(frm_name,pic_id);
			
		},false);
		
		
		let searchinputbox = document.getElementById("searchinputbox");
		let searchedmsgdatabtn = document.getElementById("mymsgserchbtn");
		searchedmsgdatabtn.addEventListener("click",function(){
		if(searchinputbox.value === ""){alert("Kindly enter a name");searchinputbox.focus();return false;}
		
		let item = searchinputbox.value;
		let itemisfrom = sessionStorage.getItem("whomtoMSGChoice");
		makeaSearch(item,itemisfrom); // call function in newmsgbyschool js
		
		},false);
}


var keepwhomtomsg = [];
function addWhomtoMsgtostore(gtforwhom,gtid){
	
	//alert(gtforwhom+"-"+gtid);
	//keepwhomtomsg.push(gtforwhom+","+gtid.id);
	//keepwhomtomsg.push(gtid.id);
	//sessionStorage.setItem("MyWhomtoMSGto",JSON.stringify(keepwhomtomsg));
	
	var whom_box_ischked = document.getElementById(gtid.id);
	
	if(whom_box_ischked.checked === true){
		sessionStorage.setItem("MyWhomtoMSGto",'['+'"'+0+'"'+']');
		keepwhomtomsg.push(gtid.id);
		sessionStorage.setItem("MyWhomtoMSGto",JSON.stringify(keepwhomtomsg));
	}else if(whom_box_ischked.checked === false){

	for(i = 0; i < keepwhomtomsg.length; i++){

			if(keepwhomtomsg[i] == gtid.id){
				keepwhomtomsg.splice(i, 1);
				sessionStorage.setItem("MyWhomtoMSGto",JSON.stringify(keepwhomtomsg));
				if(keepwhomtomsg.length === 0){
					//sessionStorage.setItem("MyWhomtoMSGto","0");
					sessionStorage.setItem("MyWhomtoMSGto",'['+'"'+0+'"'+']');
				}
			}
	  }
  }
}*/


/*function dispMsgSearchbox(e){
	//alert(e.value); searchinputbox mynewmessagebtn
	if(e.value == '0' || e.value == '1'){
		
	document.getElementById("searchinputbox").disabled = true;
	document.getElementById("mymsgserchbtn").disabled = true;
	document.getElementById("searchinputbox").value="";
	document.getElementById("searchinputbox").style.cursor = "not-allowed";
	document.getElementById("mymsgserchbtn").style.cursor = "not-allowed";
	sessionStorage.setItem("whomtoMSGChoice",e.value); // to balance and make submission required
	sessionStorage.setItem("MyWhomtoMSGto",'['+'"'+0+'"'+']'); // just in to allow for alignment with the other last two radio btns
	document.getElementById("selectedsearch").innerHTML = "";
		
	}else{
	document.getElementById("searchinputbox").disabled = false;
	document.getElementById("mymsgserchbtn").disabled = false;
	document.getElementById("searchinputbox").focus();
	document.getElementById("searchinputbox").style.cursor = "pointer";
	document.getElementById("mymsgserchbtn").style.cursor = "pointer";
	sessionStorage.setItem("whomtoMSGChoice",e.value); // keeep this values for the makeaSearch function
	document.getElementById("selectedsearch").innerHTML = "";
	keepwhomtomsg = []; // flush the array clean
	sessionStorage.setItem("MyWhomtoMSGto",'['+'"'+0+'"'+']'); // set this storage to 0 or null or nothing
	}
}*/


//Misc menu misc_mnu

/*let misc_mnu = document.getElementById("misc_tcher_mnu");

let carrier_misc_load_i = '<ul class="list-group list-group-flush"></ul>';

misc_mnu.onclick = fillinInitialLoadforMisc;
*/
