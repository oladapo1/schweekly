
//........................... Pharmacists

var pharmcatgo = ["Choose type","ACPN","Academics","Hospitals","Administration","Industry"];

//........................... Doctors

var doctorcatgo = ["Immunologist","Anesthesiologist","Cardiologist","ColonRectal Surgeon","Dermatologist","Endocrinologist","Family Physician","Gastroenterologist","Geriatrician","Hematologist","Nephrologist","Neurologist","ObGyn","Oncologist","Ophthalmologist","Otolaryngologist","Pathologist","Pediatrician","Plastic Surgeon","Podiatrist","Psychiatrist","Pulmonologist","Rheumatologist","General Surgeon","Urologist"];

//........................... ACPN Zones

var acpnzonenations = ["Select Zone","YESBA","ZONE2","ZONE3","ZONE4","ZONE5","ZONE6"];

var extraoptndiv = document.getElementById("extraoptions");
var occuselcted = document.getElementById("acpnoccutype");
occuselcted.addEventListener("change",function (){gtExtraOption(occuselcted.value)},false);
var acpnoptnslcted = false;

	function gtExtraOption(getoccuselctdval){
		//let extraslect = document.createElement("SELECT");
		let extselcdoc = document.getElementById("myextraslectdoc");
		let extselcphrma = document.getElementById("myextraslectpharm");
				
	if(getoccuselctdval == 0){
				acpnoptnslcted = true;
				extraoptndiv.innerHTML = "";
				let extraslect = document.createElement("SELECT");
				extraslect.setAttribute("id","myextraslectpharm");
				extraslect.setAttribute("onchange","acpnZones(this.value)");
				for(i = 0; i < pharmcatgo.length; i++){
					let extraoption = document.createElement("OPTION");
					extraoption.setAttribute("value",i);
					extraoptiontxt = document.createTextNode(pharmcatgo[i]);
					extraoption.appendChild(extraoptiontxt);
					extraslect.appendChild(extraoption);
					extraoptndiv.appendChild(extraslect);

					}
			}else if(getoccuselctdval == 1){
				extraoptndiv.innerHTML = "";
				let extraslect = document.createElement("SELECT");
				extraslect.setAttribute("id","myextraslectdoc");
				for(i = 0; i < doctorcatgo.length; i++){
					let extraoption = document.createElement("OPTION");
					extraoptiontxt = document.createTextNode(doctorcatgo[i]);
					extraoption.appendChild(extraoptiontxt);
					extraslect.appendChild(extraoption);
					extraoptndiv.appendChild(extraslect);
				}				
		}else{
			extraoptndiv.innerHTML = "";
			
			//alert("Choose a profession")
		}
}


//........................... Others
occuselcted.addEventListener("click",function (){selctdOthers(occuselcted.value)},false);

function selctdOthers(getoccuselctdval){
	//extraoptndiv.innerHTML = "";
	if(getoccuselctdval == 5){
		    extraoptndiv.innerHTML = "";
		    let extrainput = document.createElement("INPUT");
			extrainput.setAttribute("id","myextraoccutype");
			extrainput.setAttribute("placeholder","Enter career"); //= document.createTextNode("");
			extrainput.setAttribute("type","text");
			extrainput.setAttribute("maxlength","14");
			extraoptndiv.appendChild(extrainput);			
		}	
}

function acpnZones(gtval){
	//alert(gtval);
	
	if(gtval == 1){
		extraoptndiv.innerHTML = "";
		let extraslect = document.createElement("SELECT");
				extraslect.setAttribute("id","mysubzonespharm");
				
				for(i = 0; i < acpnzonenations.length; i++){
					let zoneoptions = document.createElement("OPTION");
					zoneoptions.setAttribute("value",i);
					zoneoptionstxt = document.createTextNode(acpnzonenations[i]);
					zoneoptions.appendChild(zoneoptionstxt);
					extraslect.appendChild(zoneoptions);
					extraoptndiv.appendChild(extraslect);

					}
	}else{
		alert("OOps");
	}	
}