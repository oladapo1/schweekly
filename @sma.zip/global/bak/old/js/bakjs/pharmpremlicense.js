function passPharPremsRenewaltoHandler(licnseformname){
	//alert(licnseformname);
	var licentype;
	if( licnseformname == "pharmlicensfrm" ){
		licentype = 0;
	}else if( licnseformname == "premslicensfrm" ){
		licentype = 1;
	}else if( licnseformname == "affidlicensfrm" ){
	    licentype = 2;
	}
	
  var form = document.forms.namedItem(licnseformname);
	
  var membermakingrenewal = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  membermakingrenewal = membermakingrenewal.memberid.toString();

  oData = new FormData(form);

  oData.append("LicenceType", licentype);
  oData.append("MemberReqstnRenewClearnce", membermakingrenewal);
  oData.append("RenewUploadDir", "../renewals/renewaldocsUploadDir");
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/pharmpremlicense.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  console.log(oReq.responseText);	  
	  alert(oReq.responseText);	  
    } else {
      alert("Error " + oReq.status + " occurred when trying to upload your file.<br>");
    }
  };

  oReq.send(oData);
}
