var gtnewloc = document.getElementById("setnewcoords");
gtnewloc.onclick = setNewCoords;

function setNewCoords(){
	
	
	let nlat = Math.floor(Math.random() * 1000);
	let nlng = Math.floor(Math.random() * 1000);
	
	document.getElementById("newlatn").innerHTML  = nlat;
	document.getElementById("newlongt").innerHTML = nlng;
	

let mymembersenderloc = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderloc = mymembersenderloc.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			console.log(this.responseText);	
			 }		
        };
		
	xhttp.open("POST","scripts/nearbysendloct.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_membr_ids="+mymembersenderloc+"&sent_nlat="+nlat+"&sent_nlng="+nlng);
}


var gtviewsaved = document.getElementById("viewsvd");
gtviewsaved.onclick = saveNewCoords;

function saveNewCoords(){

let mymembersavedloc = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersavedloc = mymembersavedloc.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			console.log(this.responseText);	
			
			document.getElementById("locsavedata").innerHTML = this.responseText;
			
			}		
        };
		
	xhttp.open("POST","scripts/nearbyloct.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_membr_ids="+mymembersavedloc);
}
