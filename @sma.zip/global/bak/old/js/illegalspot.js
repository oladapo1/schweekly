        var latlongdisp = document.getElementById("mapholderx");
		var latlongcoords = document.getElementById("latlongy");
			
			function getLocation() {
		  
		  if (navigator.geolocation){
			navigator.geolocation.getCurrentPosition(showPosition);
		  } else {
			latlongdisp.innerHTML = "Geolocation is not supported by this browser.";
		  }
		}

function showPosition(position) {	  
		  /////////////////////////////////////////////////////////
		  
	let memberwhositedspot = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberwhositedspot = memberwhositedspot.memberid.toString();
		  
	  //var oOutput = document.getElementById("displaysent"),
      oData = new FormData();

	  latlongcoords.innerHTML = "Latitude "+ position.coords.latitude +" "+"Longitude "+ position.coords.longitude;
	
	  console.log(latlongcoords);
	
	  oData.append("Latitude", position.coords.latitude);
	  oData.append("Longitude", position.coords.longitude);
	  oData.append("WhoSitedspot", memberwhositedspot);

	  var oReq = new XMLHttpRequest();
	  oReq.open("POST", "scripts/illegalspots.php", true);
	  oReq.onload = function(oEvent) {
		if (oReq.readyState == 4 && oReq.status == 200){
		  latlongdisp.innerHTML = oReq.responseText;	
		  //location.reload();	  
		  //setTimeout(location.reload(),3000);
		} else {
		  latlongdisp.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
		}
	  };

	  oReq.send(oData);
		  
		  ////////////////////////////////////////////////////////	  
		  
		}