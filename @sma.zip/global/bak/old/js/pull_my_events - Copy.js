var getmyeventsbtn= document.getElementById("getmyevents");
getmyeventsbtn.addEventListener("click",function(){loadmyPersonalEvents()},false);

function loadmyPersonalEvents(){

getmyeventsbtn.style.display = "none";


var mymembersenderxidev = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderxidev = mymembersenderxidev.memberid.toString();

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){ 
		//alert(xhttp.responseText);
		console.log(xhttp.responseText);
		if(xhttp.responseText == -1){
			//You have no events now
			 alert(You have no events now");
		}
		//document.getElementById().style.display = "";
		
		
	var myEventArrytObj = JSON.parse(xhttp.responseText); 
	
		for(i = 0; i < myEventArrytObj.length; i++){
			
			//alert(myEventArrytObj[i].eventtitle+" "+myEventArrytObj[i].eventdate);
			
			//listmyeventstbl
		   var evpara = document.createElement("TR");
			evpara.setAttribute("class", "mypersonalevents");
						
			var titlenode = document.createTextNode(myEventArrytObj[i].eventtitle);
			var datenode = document.createTextNode(myEventArrytObj[i].eventdate);
									
			var td_eventtitle = document.createElement("TD");
			td_eventtitle.appendChild(titlenode);
			evpara.appendChild(td_eventtitle);
			
			var td_eventdate = document.createElement("TD");
			td_eventdate.appendChild(datenode);
			evpara.appendChild(td_eventdate);
			
			var element = document.getElementById("listmyeventstbl");
			element.appendChild(evpara);
			//element.appendChild(evpara);
				
		}
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pull_my_events.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_myid=" +mymembersenderxidev);	
}