function CheckTurns(arraylen){
var turns = "";
var turnv1,turnv2,arraylen,sizetoload = 4;
turnv1 = parseInt(arraylen/sizetoload);
turnv2 = parseInt(arraylen % sizetoload);
turns = addTurns(turnv1,turnv2);
sessionStorage.setItem("numbrofturns",turns);
}

function addTurns(a,b){
let m_turnv2;

	if(b === 0){
	return a;
	}else{
	m_turnv2 = (b/b);
	return (a+m_turnv2);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////

window.addEventListener("load",function(){loadSuggestedConnectnstosessionstore()},false);

//function to load right sidebar suggestConnections to session store
function loadSuggestedConnectnstosessionstore(){

// storing our array as a string in session Store
	sessionStorage.setItem("myArraystarter",parseInt(0));//initialize
	sessionStorage.setItem("my_loadmocounter",parseInt(0));//initialize
	sessionStorage.setItem("mylimsize",parseInt(4));//initialize

	var membersenderxid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersenderxid = membersenderxid.memberid.toString();
	
	let gt_myArraystarter = JSON.parse(sessionStorage.getItem("myArraystarter"));
	//alert(gt_myArraystarter);
	let gt_limit_mobile = 5; 

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			
			let loadsent = this.responseText;
			loadsent = loadsent.replace(/,\s*$/,"");
		    //console.log(loadsent);			
			//alert(loadsent);			
				
			sessionStorage.setItem("PullsuggestedConnectionstostore", '{"\SugestedConnectionData"\:'+'['+loadsent+']}');
		
		createItems();
				
            }
        };
		
	xhttp.open("POST","scripts/pullSuggestedConnectnstosessionstore.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	/*xhttp.send("send_membersenderid="+membersenderxid+"&send_limit="+gt_limit_mobile+"&send_offset="+gt_myArraystarter);*/
	
	xhttp.send("send_membersenderid="+membersenderxid);
}	
	///////////////////////////////////////////////////////////////////////////////////////////////////

var gtloadmorebtn_m = document.getElementById("myloadmore_m");
gtloadmorebtn_m.addEventListener("click",loadMorseSuggestedConnectn,false);
//function to handle load more
function  loadMorseSuggestedConnectn(){
// first value for load more as LIMIT for PHP handler is initiated at logindotjs file
let addtoloadmore = 4;

let loadmore = addtoloadmore + parseInt(sessionStorage.getItem("LOADMORElim"));
sessionStorage.setItem("LOADMORElim",loadmore);

//alert(loadmore);

var membersenderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
membersenderid = membersenderid.memberid.toString();

   var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			sessionStorage.setItem("PullsuggestedConnectionstostore", '{"\SugestedConnectionData"\:'+this.responseText+'}');
		    //loadtoviewSuggestedConnectns();
			  createItems();
			  alert(this.responseText);
            }
        };
		
	xhttp.open("POST","scripts/pullSuggestedConnectnsforloadmore.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_loadmore="+loadmore+"&send_membersenderid="+membersenderid);

}


////////

//function to send to php handler the selected/added SuggestedConnection 
function sendSelectedSuggestedConnectn(tobeconnectedto_id){

var mypersonal_id = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mypersonal_id = JSON.stringify(mypersonal_id.memberid);

   var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			
			alert(this.responseText);
			
            }
        };
		
	xhttp.open("POST","../scripts/sendselectedconnection.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_mypersonalid="+mypersonal_id+"&send_newconnctreq="+tobeconnectedto_id);
}

////////
	////////////////////////////
	var arrayitems = JSON.parse(sessionStorage.getItem("PullsuggestedConnectionstostore")); //roteski++
	
	function refreshArrLen(){
	let arrayitems = JSON.parse(sessionStorage.getItem("PullsuggestedConnectionstostore")); //roteski++
	return  arrayitems.SugestedConnectionData.length;
	}
	////////////////////////////
		
	var element = document.getElementById("arritems");
	
	function createItems(){
	
	let arrayitems = JSON.parse(sessionStorage.getItem("PullsuggestedConnectionstostore")); //roteski++
		
    //alert("ok "+arrayitems.SugestedConnectionData[2].SugFname); //myObj.NotifItems[i]);//mypersonal.lname
	
	var attacheddiv = "<div class='row' id='lisety'>";
	
	let arrayitemslen = refreshArrLen();
	//alert(arrayitemslen);
	var gtmyArraystarter  = parseInt(sessionStorage.getItem("myArraystarter"));
	var gtmylimsize       = parseInt(sessionStorage.getItem("mylimsize"));
	
		if(gtmyArraystarter > arrayitemslen){
			alert(gtmyArraystarter+ " Cannot be larger than array size " +arrayitemslen);
			sessionStorage.setItem("myArraystarter",parseInt(0));
			sessionStorage.setItem("mylimsize",parseInt(4));
			//text = "";
			attacheddiv = "";
			storeMembers();
			//document.getElementById("arritems").innerHTML = "";
			//restock array
				if(arrayitemslen === 0){
					storeMembers();
				}
		    return false;
		}
		
	for(i = gtmyArraystarter; i < gtmylimsize; i++){
		
		/* if(arrayitems.SugestedConnectionData[i].SugCareer == undefined){
					alert("continue");
				}  */
				//alert(i +" f");
		
		/*if(arrayitems.SugestedConnectionData[i].SugCareer == 0){
							career = "Pharmacist";
						}else if(arrayitems.SugestedConnectionData[i].SugCareer == 1){
						career = "Doctor";
						}else if(arrayitems.SugestedConnectionData[i].SugCareer == 2){
							career = "Lab.Sc";
						}else if(arrayitems.SugestedConnectionData[i].SugCareer == 3){
							career = "Nurse";
						}else if(arrayitems.SugestedConnectionData[i].SugCareer == 4){
							career = "Dentist";
						}else if(arrayitems.SugestedConnectionData[i].SugCareer == 5){
							career = "Other";
						}*/
		
		/* if(arrayitems[i] == undefined){
					continue;
				} */
				//text += "<li id='"+i+"' onclick = removeliItems(this.id);>"+ arrayitems[i] +"</li>";
				//document.getElementById("arritems").innerHTML = text;
				
				attacheddiv += "<div class='col-3' style='border-radius:2px;padding:-2px;' id='"+i+"' onclick = removeliItems(this.id);><div class='' style='margin:0 auto;width:36px;'><img class='rounded' style='width:36px;height:36px;object-fit: cover;' src='../images/profileimages/"+arrayitems.SugestedConnectionData[i].SugPhoto+"' alt='Card image' style='text-align:center;'></div><p style='font-size:0.65em;line-height:0.95;margin-top:5px;text-align:center;'>"+ arrayitems.SugestedConnectionData[i].SugFname +"<br><span style='font-size:0.85em;padding:2px;border-radius:5px;'>"+ arrayitems.SugestedConnectionData[i].SugCareer +" <a href='#' class='ui-btn ui-shadow ui-corner-all ui-icon-plus ui-btn-icon-notext ui-btn-inline' style='margin-left:10px;' id='"+arrayitems.SugestedConnectionData[i].SugMemberID+"'onclick='sendSelectedSuggestedConnectn(this.id);removeliItems(this.id);'>Plus</a></span></p><input type='hidden' id='holdvalu1' name=''></div>";
				
				// attache to body
				document.getElementById("arritems").innerHTML = attacheddiv;
			}
			
			//text = "";
			gtmylimsize += 4;
			sessionStorage.setItem("mylimsize",gtmylimsize);
			sessionStorage.setItem("myArraystarter",parseInt(gtmyArraystarter)+4);
				}
					
	 function clyeanUp(){
			//alert("Okin");
			let newparent = document.getElementById("arritems");	
			let child = document.getElementById("lisety");
			//let child = document.getElementById("arritems");
			newparent.removeChild(child);			
		}
		
		//removes from view tray
	function removeliItems(li_ID){
			//alert(li_ID+"-Poppins");
				setTimeout(function(){document.getElementById(li_ID).style.display="none"},200);
			//let newparent = document.getElementById("lisety");	
			//let child = document.getElementById(li_ID);
			//newparent.removeChild(child);	
			//setTimeout(function(){newparent.removeChild(child)},1000);
			
			recalibrateItems(li_ID);		
		}
		
		
		//removes from the storage
	function recalibrateItems(li_IDx){
		/* arrayitemslen =  refreshArrLen(); // recall the array length
		alert(arrayitemslen+" "+li_IDx); */
		//arrayitems.splice(li_IDx,1);
		delete arrayitems[li_IDx];
		sessionStorage.setItem("membersintest", JSON.stringify(arrayitems));
	}		
