function loadSliderprevnext(){
	let projectIDx = sessionStorage.getItem("PROJCTid");
	//alert(projectIDx);
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		//alert(xhttp.responseText);
		console.log(xhttp.responseText);
		sessionStorage.setItem("SlidePrevw", '{"\Slideprevwload"\:'+this.responseText+'}');
		//document.getElementById("slideprevwdisplay").innerHTML = xhttp.responseText;
		Slidernextv();
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/sldertopfiveprevnextmgr.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_prjtid="+projectIDx);	
	
}
////
var btnprvs = document.getElementById("prvsbtn");

var sldercountr = -1;
btnprvs.onclick = Sliderprev;
function Sliderprev(){
			
	--sldercountr;
				//alert(this.responseText);
		let slideprvnxt = JSON.parse(sessionStorage.getItem("SlidePrevw"));
				//alert(slideprvnxt.Slideprevwload.length);
				
				 if(sldercountr == -1 || sldercountr < 0){
                           sldercountr = 0;
                    }
				
	document.getElementById("mainslidearttitle").innerHTML = slideprvnxt.Slideprevwload[sldercountr].maintitle;
	document.getElementById("slidearttitle").innerHTML = slideprvnxt.Slideprevwload[sldercountr].slidetitle;
	document.getElementById("slideartlcbody").innerHTML = slideprvnxt.Slideprevwload[sldercountr].slidecontent;
	document.getElementById("sliderimgpix").src = "../images/sliderarticlesimg/"+slideprvnxt.Slideprevwload[sldercountr].slideimg;
	//basedir = "images/sliderarticlesimg/"+slideprvnxt.Slideprevwload[sldercountr].slideimg;
	//document.getElementById("sliderimgpix").style.backgroundImage = "url("+basedir+")";
}

var btnenxt = document.getElementById("enxtbtn");
btnenxt.onclick = Slidernextv;
function Slidernextv(){
	sldercountr++;
				//alert(sldercountr);
		let slideprvnxt = JSON.parse(sessionStorage.getItem("SlidePrevw"));
				//alert(slideprvnxt.Slideprevwload.length);
				
				
		if(sldercountr == slideprvnxt.Slideprevwload.length){
		
		sldercountr = sldercountr-1;
		return false;
	
	}
							
	document.getElementById("mainslidearttitle").innerHTML = slideprvnxt.Slideprevwload[sldercountr].maintitle;
	document.getElementById("slidearttitle").innerHTML = slideprvnxt.Slideprevwload[sldercountr].slidetitle;
	document.getElementById("slideartlcbody").innerHTML = slideprvnxt.Slideprevwload[sldercountr].slidecontent;
	document.getElementById("sliderimgpix").src = "../images/sliderarticlesimg/"+slideprvnxt.Slideprevwload[sldercountr].slideimg;
	//basedir = "images/sliderarticlesimg/"+slideprvnxt.Slideprevwload[sldercountr].slideimg;
	//document.getElementById("sliderimgpix").style.backgroundImage = "url("+basedir+")";
}