setTimeout(getcountofRequestConnectionAvail,300);
function getcountofRequestConnectionAvail(){

var gtmembersenderxid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersenderxid = gtmembersenderxid.memberid.toString();

var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			
			myconrequestsArr = JSON.parse(xhttp.responseText); // get connrequest Ids
			myconrequestsArrlen = myconrequestsArr.length;	//get connections requests count size
			console.log(this.responseText);			
			document.getElementById("getreqstobubble").innerHTML = myconrequestsArrlen;
			pullmyConnectionrequests();
            }
        };
		
	xhttp.open("POST","scripts/pullmyconnectionrequestscount.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_pullmembersenderxid="+gtmembersenderxid);	
}

//var gtanchorconnreqst = document.getElementById("connreqstanchor_m");
//gtanchorconnreqst.onclick = pullmyConnectionrequests;

function pullmyConnectionrequests(){
	//alert("OOONda");
var pullmembersenderxid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
pullmembersenderxid = pullmembersenderxid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//console.log(this.responseText);
			//document.getElementById("myreqstconntableview").innerHTML = this.responseText;
			document.getElementById("myconnectionrequests_ul").innerHTML = this.responseText;
			
			//sessionStorage.setItem("PullConnectionsrequestedtostore", '{"\ConnectionRequestData"\:'+this.responseText+'}');
			
			//buildRequestView();
				
            }
        };
		
	xhttp.open("POST","scripts/pullmyconnectionrequests.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	//xhttp.send("send_membersenderxid="+pullmembersenderxid+"&sendvalforloop="+gtcount);
	xhttp.send("send_membersenderxid="+pullmembersenderxid);
	//xhttp.send();
}

  //update this function to send who is approving Id
function acceptconnrequestedBtnIds(whomtoacceptID){
	
	//alert(whomtoacceptID);
	
	/* When there is a click on any of the items btn (in the table - function ) - send the data rqd to update connectnreqst function */
	
	document.getElementById(whomtoacceptID).addEventListener("click", function(){updateAcceptconnrequest(whomtoacceptID);});
	//document.getElementById(whomtoacceptID).addEventListener("click", function(){this.style.display = "none";});
			
}

function updateAcceptconnrequest(toacceptedid){
	
	//alert(toacceptedid);
	
var mymembersenderxid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembersenderxid = mymembersenderxid.memberid.toString();
	
if(toacceptedid === undefined || toacceptedid === ""){
		alert("No Connection request Id set");
		return false;
	}
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		//alert(xhttp.responseText);
		alert("Connection added");// rem work on this - get concrete report from apdateaccept php handler
		location.reload();
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/updateAcceptconnrequest.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_whotoacceptid=" +toacceptedid+"&send_myid="+mymembersenderxid);
}

