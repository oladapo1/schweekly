var gtinterestedineventbtn = document.getElementById("interestedineventbtn");
gtinterestedineventbtn.onclick = getInterestedEventOptinData;
function getInterestedEventOptinData(){	

  var getotpinId = document.getElementById("keepmyinterestid").value;

  var mysa_usenderidforoptin = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  mysa_usenderidforoptin = mysa_usenderidforoptin.memberid.toString();
	
   var xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
	//alert(this.responseText);
	if(this.responseText == 1){
		
		document.getElementById("optinstatusresponse").style.display = "inline";
		document.getElementById("optinstatusresponse").innerHTML = "your have opted for this event";
		setTimeout(hideResponseforOptin,3000);		
		
	}else if(this.responseText == 2){
		document.getElementById("optinstatusresponse").style.display = "inline";
		document.getElementById("optinstatusresponse").innerHTML = "your already opted for this event";
		document.getElementById("optinstatusresponse").style.color = "#095f88";
		setTimeout(hideResponseforOptin,3000);	
	}else{
	    console.log(this.responseText);
		//alert(this.responseText);
	}
  }
};

 /* Using POST */
xhttp.open("POST","scripts/eventintresetedoptins.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_mysa_usenderidoptin="+mysa_usenderidforoptin+"&send_my_eventoptinid="+getotpinId);
}

function hideResponseforOptin(){
	
		document.getElementById("optinstatusresponse").style.display = "none";
		//document.getElementById("interestedineventbtn").style.display = "none";
		
}