//yzonetofpage.js
document.addEventListener("DOMContentLoaded",pullNewsFlashtostorage,false);
function pullNewsFlashtostorage(){

	let membersidt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersidt = membersidt.memberid.toString();
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		//console.log(xhttp.responseText);
		//document.getElementById("newsflashlisted").innerHTML = xhttp.responseText;
		//sessionStorage.setItem("flashInfo", '['+this.responseText+']');
		sessionStorage.setItem("flashInfo", this.responseText);
		
		let flashload = JSON.parse(sessionStorage.getItem("flashInfo"));
		loadFlashInfo(flashload);
  	}
};
 /* Using POST */	 
xhttp.open("POST","scripts/newsflashinfotofpage.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("memberid="+membersidt);
}
//var flashInfo = JSON.parse(sessionStorage.getItem("flashInfo"));
var flashinfocounter = 0;

	function loadFlashInfo(flashInfo){
	
	let flashbody = document.getElementById("flashinfopr");
	setInterval(
		function(){
		if(flashinfocounter == flashInfo.length){
			flashinfocounter = 0;
		}

		$("#flashinfopr").fadeTo("slow", 0.59);
		flashbody.style.backgroundColor = "#015393";
		flashbody.innerHTML = flashInfo[flashinfocounter].newsitem;
		flashbody.style.color = "#fff";
		$("#flashinfopr").fadeTo("slow", 0.99);
		flashinfocounter++;
		},4000);

}


////////////////////////////////////////////////////

///////Podcast///////
var pdcastcounter = -1;
document.addEventListener("DOMContentLoaded",pullPodcaststostorage,false);
function pullPodcaststostorage(){

	let membersidt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersidt = membersidt.memberid.toString();
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){
		sessionStorage.setItem("audiotxtncontent", this.responseText);
		let podcastload = JSON.parse(sessionStorage.getItem("audiotxtncontent"));
		//loadinitPodcast(podcastload);
  	}
};
 /* Using POST */	 
xhttp.open("POST","scripts/podcaststofpage.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("memberid="+membersidt);
}

document.addEventListener("DOMContentLoaded",loadinitPodcast,false);
function loadinitPodcast(){
	pdcastcounter++;
	var audiotxtncontent = JSON.parse(sessionStorage.getItem("audiotxtncontent"));
	//alert(audiotxtncontent[pdcastcounter].podcstitle);
	document.getElementById("podcprv").style.display = "inline";
	
	let pdcastitle = document.getElementById("podcasttitle");
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podcstitle; // Work titles into the media upload
	
	let pdcastrack = document.getElementById("mypodcasts");
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].audionamed;
	
}

//document.addEventListener("DOMContentLoaded",loadPodcastnxt,false);

//Podcasts
//var pdcastcounter = -1;

let pdcanxt = document.getElementById("podcnxt");
pdcanxt.onclick = loadPodcastnxt;

function loadPodcastnxt(){

	var audiotxtncontent = JSON.parse(sessionStorage.getItem("audiotxtncontent"));
	pdcastcounter++;
	if(pdcastcounter == audiotxtncontent.length){
		
		pdcastcounter = pdcastcounter-1;
		return false;
	
	} 
		
	if(pdcastcounter == 1){
		
		document.getElementById("podcprv").style.display = "inline";		
	}
	let pdcastitle = document.getElementById("podcasttitle");
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podcstitle; // Work titles into the media upload
	
	let pdcastrack = document.getElementById("mypodcasts");
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].audionamed;
}

let pdcastprv = document.getElementById("podcprv");
pdcastprv.onclick = loadPodcastprv;

function loadPodcastprv(){
	//alert(pdcastcounter);
var audiotxtncontent = JSON.parse(sessionStorage.getItem("audiotxtncontent"));
		--pdcastcounter;
		//alert(pdcastcounter);
	  if(pdcastcounter == -1 || pdcastcounter < 0){
                        pdcastcounter = 0;
                    }

	let pdcastitle = document.getElementById("podcasttitle");
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podcstitle;
	
	let pdcastrack = document.getElementById("mypodcasts");
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].audionamed;
}
////////////////////////////////////////

///////Video///////
document.addEventListener("DOMContentLoaded",pullVideostorage,false);
function pullVideostorage(){

	let membersidt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersidt = membersidt.memberid.toString();
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){
		sessionStorage.setItem("videotxtncontent", this.responseText);
			
		var videotxtncontent = JSON.parse(sessionStorage.getItem("videotxtncontent"));
		
		loadWeekVideo(videotxtncontent);
  	}
};
 /* Using POST */	 
xhttp.open("POST","scripts/videostofpage.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("memberid="+membersidt);
}

function loadWeekVideo(videotxtncontent){
	//alert(videotxtncontent[0].videonamed);
	let vidtit = document.getElementById("videotitle");
	vidtit.innerHTML = videotxtncontent[0].videotitle;
	let vidref = document.getElementById("myvodeo");
	vidref.poster = "images/postervideo.png";
	//vidref.src = "../scontent/videos/pharmakokinectics.mp4"; 
	vidref.src = "../scontent/videos/"+videotxtncontent[0].videonamed;
	vidref.type= "video/mp4";
	vidref.controls = "true";
}

///////Articles & Notes///////
var articlecounter = -1;
document.addEventListener("DOMContentLoaded",pullArticlestorage,false);
function pullArticlestorage(){

	let membersidt = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membersidt = membersidt.memberid.toString();
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){
		sessionStorage.setItem("articlecontent", this.responseText);
		//console.log(this.responseText);
		let artlceload = JSON.parse(sessionStorage.getItem("articlecontent"));
		//loadinitArticle(artlceload);
		
		//loadArticlenxt();
  	}
};
 /* Using POST */	 
xhttp.open("POST","scripts/articlestofpage.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("memberid="+membersidt);
}

document.addEventListener("DOMContentLoaded",loadinitArticle,false);
function loadinitArticle(){
	articlecounter++;
	var articlecontent = JSON.parse(sessionStorage.getItem("articlecontent")); 
	//alert(articlecontent[0].articletitle);
	//document.getElementById("artlceprv").style.display = "inline";
	let idholder = document.getElementById("idholder");	
	let artictitle = document.getElementById("articletitle");
	artictitle.innerHTML = articlecontent[articlecounter].articletitle;
	idholder.value = articlecontent[articlecounter].featarticleid;
	artictitle.href = "articlesviews.php?atid="+articlecontent[articlecounter].featarticleid;
	articlecounter = 0;
}
	
//var articlecontent = JSON.parse(sessionStorage.getItem("articlecontent")); 	
//Articles

//window.addEventListener("load",function(){loadArticlenxt},false);

let rdarticlenxt = document.getElementById("artclenxt");
rdarticlenxt.onclick = loadArticlenxt;

function loadArticlenxt(){
	var articlecontent = JSON.parse(sessionStorage.getItem("articlecontent")); 
	articlecounter++;
	//alert(articlecounter);
	//alert(articlecontent[1].articletitle);
	if(articlecounter == articlecontent.length){
		
		articlecounter = articlecounter-1;
		return false;
	
	} 
	
	if(articlecounter == 1){
		
		document.getElementById("artlceprv").style.display = "inline";		
	}
	
	//alert(articlecontent[articlecounter].articletitle);
	let idholder = document.getElementById("idholder");
	let artictitle = document.getElementById("articletitle");
	artictitle.innerHTML = articlecontent[articlecounter].articletitle;
	idholder.value = articlecontent[articlecounter].featarticleid;
	artictitle.href = "articlesviews.php?atid="+articlecontent[articlecounter].featarticleid;
}

let rdarticleprv = document.getElementById("artlceprv");
rdarticleprv.onclick = loadArticleprv;

function loadArticleprv(){
	var articlecontent = JSON.parse(sessionStorage.getItem("articlecontent")); 
		--articlecounter;
		//alert(articlecounter);
	  if(articlecounter == -1 || articlecounter < 0){
                      
                        articlecounter = 0;
                    }
					let idholder = document.getElementById("idholder");
	let artictitle = document.getElementById("articletitle");
	artictitle.innerHTML = articlecontent[articlecounter].articletitle;
	idholder.value = articlecontent[articlecounter].featarticleid;
	artictitle.href = "articlesviews.php?atid="+articlecontent[articlecounter].featarticleid;
}