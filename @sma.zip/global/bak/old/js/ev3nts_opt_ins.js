function getMyeventsOptIns(gteventidoptedin){
	
	alert(gteventidoptedin);
/* var gtmembersrid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersrid = gtmembersrid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			mydataload = JSON.parse(this.responseText);
			document.getElementById("alltimeconnectn").innerHTML = mydataload[0];
			document.getElementById("myposts").innerHTML = mydataload[1];
			
            }
        };
		
	xhttp.open("POST","scripts/mprofile_c_p_pts.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_members_id="+gtmembersrid); */	
}