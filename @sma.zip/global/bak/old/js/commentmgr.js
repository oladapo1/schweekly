function sendCommentonpost(commentpostid,commentload){
var mymembercommentid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mymembercommentid = mymembercommentid.memberid.toString();

var formData = new FormData();
formData.append("CommentedLoad", commentload);
formData.append("PostCommentedbyWho", mymembercommentid);
formData.append("CommentedPost", commentpostid);

let commntresponsespan = 'commentedresponse'+commentpostid;
let textareareactn = 'reactn'+commentpostid;
let countdownrnow = 'countdownr'+commentpostid;
let commentbubbler = 'commentbubble'+commentpostid;

var request = new XMLHttpRequest();
request.open("POST", "scripts/commentmgr.php");
request.onload = function(oEvent) {
	if (request.status == 200) {
	//console.log(request.responseText);
	//console.log(" Uploaded!");
	document.getElementById(commntresponsespan).innerHTML = request.responseText;
	document.getElementById(commentbubbler).style.color = "red";
	
	setTimeout(function(){document.getElementById(countdownrnow).value = '200';
	document.getElementById(textareareactn).value = "";
	document.getElementById(commntresponsespan).innerHTML = "";},2000);//countdownr reactn
	
	} else {
	console.log("Error " + request.status + " occurred when trying to upload");
	}
	};
request.send(formData);
}