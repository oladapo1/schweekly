document.addEventListener("DOMContentLoaded", function(){
	//check the store for New ChatMeta Load
		let isNewChatkeyavailable = sessionStorage.getItem("NewChatBuddy");
		 if(isNewChatkeyavailable === null){
			console.log("No new chat instance");
			sessionStorage.setItem("NewChatBuddy","");
			//return false;
		}else{
			
			//alert("ok");
			buildUIforNewChatNotifLookdup();
		}
		
},false);

var text = "";

function buildUIforNewChatNotifLookdup(){

/*let chatnotifbubbleval = document.getElementById("chatnotifbubble");
chatnotifbubbleval.innerHTML = bubbletstvals.reduce(chatBubbleCount);

function chatBubbleCount(total, num) {
  return total + num;
}
*/
let memberlookuprqst = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberlookuprqst = memberlookuprqst.memberid.toString();
	
	
	/* create xhr object */
	let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
		console.log(xhttp.responseText);
		sessionStorage.setItem("NewChatBuddy", this.responseText);
		
		/////////////////////////////////////////////////////////
		let getmetaload = JSON.parse(sessionStorage.getItem("NewChatBuddy"));
		//let topbanr2 = JSON.parse(sessionStorage.getItem("NewChatBuddy"));
		
		//alert(getmetaload.length);
		let chatnotifbubbleval = document.getElementById("chatnotifbubble")
		chatnotifbubbleval.innerHTML = getmetaload.length;
		
	//fname lname	photo occupatntype occuspecializatn
var imgpath = "../images/profileimages";

var occutypearray = ["Pharm.","Dr.","Lab. Sci.","Nrs.","Dentist","Others","Radiologists","Optometrists","Phlebotomist","Physio.","Occ. Thera.","Speech Thera.","Chiropractors","Osteopaths","Audiologists","Sample Col."];

for(i=0;i < getmetaload.length; i++){

text += "<li><div class='collapsible-header'><img src='"+imgpath+'/'+getmetaload[i].photo+"' alt='' class='circle' style='width:36px;height:38px;'>&nbsp;<span style='font-weight:600;color:#ffcb05'>"+occutypearray[getmetaload[i].occupatntype]+"</span>&nbsp;<span style=''>"+getmetaload[i].lname+" "+getmetaload[i].fname+"</span><span class='badge #eceff1 blue-grey lighten-5'"+" style='border-radius:10px;color:#607d8b;' id='"+i+"'></span></div><div class='collapsible-body'>"+"<div class='mesgs'><div class='datecaptured'>dated</div><div class='msg_history'><div class='incoming_msg'><div class='received_msg'><div class='received_withd_msg'><p></p><span class='time_date'> <span>time here</span> | <span>MM DD</span></span></div></div></div><div class='outgoing_msg'><div class='sent_msg'><p></p><span class='time_date'> <span>time here</span> | <span>MM DD</span><i class='material-icons' style='font-size:1.25em;vertical-align:bottom;'>check</i></span></div></div></div></div>"+"<div class='row' style='border-top:1px solid #101010;'><form class='col s12' id='chatresp_frm'><div class='row' style='padding:1px 10px;'><div class='input-field'><i class='material-icons prefix'>mode_edit</i><textarea id='' class='materialize-textarea'></textarea><label for=''>respond</label></div><span class='card-title grey-text text-darken-4' style='cursor:pointer;'><i class='material-icons right'>send</i></span><span class='card-title grey-text text-darken-4' style='cursor:pointer;'><i class='material-icons right'>photo</i></span></div></form></div></div></li><li>";
 
document.getElementById("chatbuddylistings_ul").innerHTML = text;
}
		
		/////////////////////////////////////////////////////////
		
		
  	}
};

 /* Using POST */	 
xhttp.open("POST","scripts/lookup_new_chat.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("sent_membr_id="+memberlookuprqst);
}