function sendnewChatloadnImg(postform){

		alert(postform);
		
	if(postform === "vendorstype"){
		arrychked = arrytypev[0];
		 txtv = document.getElementById("nbcastextareavendors");
		if( txtv.value == ""){
			alert("Cannot be empty");
			txtv.focus();
			return false;
		}
		//check the store for Vendors category key
		let isVendorCatgokeyavailable = sessionStorage.getItem("VendorQuotes");
		 if(isVendorCatgokeyavailable === null){
			alert("You have not made any selection");
			return false;
		} 		
	}else{
		alert("Cannot process");
	}
	
	passtoNewChattoHandlerv(txtv.value,arrychked,postform);	
}

function getRndIntegerv(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function passtoNewChattoHandlerv(messagebcasted,vendortypechked,formposted){

	var form = document.forms.namedItem(formposted);

	//let membermakingpost = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	//membermakingpost = membermakingpost.memberid.toString();
	membermakingpost = 332974;
	let mynewchatr_id = getRndIntegerv(1000000,9999999);
	
	
		  let fileinputvalue = form.nbcastfiles_files;
		  folderToUploadpostdimg = "../images/chatr";
		  
		  if(fileinputvalue.files.length == 0){
			alert("No image selected");
			return false;
		  }
   
  //var oOutput = document.getElementById("displaysent"),

  oData = new FormData(form);
  oData.append("UploadDir", folderToUploadpostdimg);
  oData.append("Whomadepost", membermakingpost);
  oData.append("NewChatrid", mynewchatr_id);
  

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/postedvendorcontent.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  alert(oReq.responseText);	 
	  console.log(oReq.responseText);
	  //location.reload();	  
	  //setTimeout(cleanUp,3000);
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error " + oReq.status + " occurred when trying to upload your file.");
    }
  };

  oReq.send(oData);
}

function cleanUpv(){
	document.getElementById("").value = "";
	document.getElementById("").value = "";
	document.getElementById("").innerHTML = "";
	document.getElementById("").value = "-";
}