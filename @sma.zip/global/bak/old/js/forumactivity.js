var forumpostbtn = document.getElementById("forumpostbtn");

forumpostbtn.onclick = chkforumLoad_ifempty;

function chkforumLoad_ifempty(){

var gtForumtopic = document.getElementById("forumtopic").value;


if(gtForumtopic == ""){
	
	alert("Forum topic cannot be empty");
	document.getElementById("forumpostbtn").focus();
	return false;
	
	}else{
		
		muv_newForumtopictohandler(gtForumtopic);
			
	}

}

function muv_newForumtopictohandler(newforummsg){
	var memberpostnforum = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberpostnforum = memberpostnforum.memberid.toString();
	//alert(memberpostnforum);
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				//alert("sent :)");
				alert(xhttp.responseText);
				document.getElementById("forumtopic").value = "";
				//location.reload();
			}else{
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/forumactivity.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_forumbdy="+newforummsg+"&send_forumemid="+memberpostnforum);	
}





