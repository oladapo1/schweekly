//var flashInfo = JSON.parse(sessionStorage.getItem("flashInfo"));
/*var flashinfocounter = 0;
//function runFlsahInfo(){
	(
	function(){
		var flashInfo = JSON.parse(sessionStorage.getItem("flashInfo"));
		//alert(flashInfo.length);
	//let infodur = flashInfo[flashinfocounter].infoduration;
	
	let flashbody = document.getElementById("flashinfopr");
	setInterval(
			//for(i = 0; i < flashInfo.length;i++){
		function(){
		if(flashinfocounter == flashInfo.length){
			flashinfocounter = 0;
		}
		
		//$("#flashinfopr").fadeToggle(8000);
		$("#flashinfopr").fadeTo("slow", 0.59);
		flashbody.style.backgroundColor = "#015393";
		flashbody.innerHTML = flashInfo[flashinfocounter].newsitem;
		flashbody.style.color = "#fff";
		$("#flashinfopr").fadeTo("slow", 0.99);
		//runFlsahInfo(flashInfo[flashinfocounter].infoduration,flashInfo[flashinfocounter].infobody);
		flashinfocounter++;
		},4000);

}
	)();
*/

document.addEventListener("DOMContentLoaded",loadPodcastnxt,false);
var audiotxtncontent = JSON.parse(sessionStorage.getItem("audiotxtncontent"));
//Podcasts
var pdcastcounter = -1;
//window.onload = loadPodcastnxt; // load first podcast 

let pdcanxt = document.getElementById("podcnxt");
pdcanxt.onclick = loadPodcastnxt;

function loadPodcastnxt(){
	//alert(audiotxtncontent[pdcastcounter].audionamed);
	pdcastcounter++;
	//alert(audiotxtncontent[pdcastcounter].podcstitle);
	if(pdcastcounter == audiotxtncontent.length){
		
		pdcastcounter = pdcastcounter-1;
		return false;
	
	} 
		
	if(pdcastcounter == 1){
		
		document.getElementById("podcprv").style.display = "inline";		
	}
	let pdcastitle = document.getElementById("podcasttitle");
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podcstitle; // Work titles into the media upload
	
	let pdcastrack = document.getElementById("mypodcasts");
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].audionamed;
}

let pdcastprv = document.getElementById("podcprv");
pdcastprv.onclick = loadPodcastprv;

function loadPodcastprv(){

		--pdcastcounter;
	  if(pdcastcounter == -1 || pdcastcounter < 0){
                        //document.getElementById("sectonnumbrs").innerHTML = 0;
                        pdcastcounter = 0;
                    }

	let pdcastitle = document.getElementById("podcasttitle");
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podcstitle;
	
	let pdcastrack = document.getElementById("mypodcasts");
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].audionamed;
}


/*var videotxtncontent = JSON.parse(sessionStorage.getItem("videotxtncontent"));
//Videos
//document.addEventListener("DOMContentLoaded",loadWeekVideo,false);
window.addEventListener("DOMContentLoaded",loadWeekVideo,false);
//window.addEventListener("load",loadWeekVideo,false);
function loadWeekVideo(){
	//alert(videotxtncontent[0].videonamed);
	let vidtit = document.getElementById("videotitle");
	vidtit.innerHTML = videotxtncontent[0].videotitle;
	let vidref = document.getElementById("myvodeo");
	vidref.poster = "images/postervideo.png";
	//vidref.src = "../scontent/videos/pharmakokinectics.mp4"; 
	vidref.src = "../scontent/videos/"+videotxtncontent[0].videonamed;
	vidref.type= "video/mp4";
	vidref.controls = "true";
}*/
///////////////////////////
	/* function seCurtime(){
		let vid = document.getElementById("myvodeo");
		vid.currentTime=3;
	}
	function playVideo(){
		let vid = document.getElementById("myvodeo");
		vid.play(); 
	}
		function pauseVideo(){
		let vid = document.getElementById("myvodeo");
		vid.pause(); 
	} */
		/* function stopVideo(){
		let vid = document.getElementById("myvodeo");
		vid.play(); 
	} */
	
	
var articlecontent = JSON.parse(sessionStorage.getItem("articlecontent")); 	
//Articles
var articlecounter = -1;
//window.addEventListener("load",function(){loadArticlenxt(),loadPodcastnxt();},false);

//window.onload = loadArticlenxt;loadPodcastnxt; // load 

document.addEventListener("DOMContentLoaded",loadArticlenxt,false);

let rdarticlenxt = document.getElementById("artclenxt");
rdarticlenxt.onclick = loadArticlenxt;

function loadArticlenxt(){
	
	articlecounter++;
	alert(articlecounter);
	//alert(articlecontent[articlecounter].articletitle);
	if(articlecounter == articlecontent.length){
		
		articlecounter = articlecounter-1;
		return false;
	
	} 
	//alert(articlecounter);	
	if(articlecounter == 1){
		
		document.getElementById("artlceprv").style.display = "inline";		
	}
	let artictitle = document.getElementById("articletitle");
	artictitle.innerHTML = articlecontent[articlecounter].articletitle;
	artictitle.href = "articlesviews.php?atid="+articlecontent[articlecounter].featarticleid;	
}

let rdarticleprv = document.getElementById("artlceprv");
rdarticleprv.onclick = loadArticleprv;

function loadArticleprv(){
	//alert(articlecontent[articlecounter].articletitle);
		--articlecounter;
	  if(articlecounter == -1 || articlecounter < 0){
                      
                        articlecounter = 0;
                    }
	//alert(articlecounter);
	let artictitle = document.getElementById("articletitle");
	artictitle.innerHTML = articlecontent[articlecounter].articletitle;
	artictitle.href = "articlesviews.php?atid="+articlecontent[articlecounter].featarticleid;
	
}
