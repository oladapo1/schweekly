function getsingleOlderPosts(opostid,postolookup){


//alert(opostid+'-'+postolookup);
	
var gtmembersrid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
gtmembersrid = gtmembersrid.memberid.toString();

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			
			document.getElementById("old_posts_real").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/o_posst_filter_weekly_real.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_opost_id="+opostid+"&send_opost_lookup="+postolookup);
}