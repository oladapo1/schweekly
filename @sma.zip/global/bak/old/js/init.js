(function($){
  $(function(){

    $('.sidenav').sidenav();
	//$('.modal1').modal();
	$('select').formSelect();
	//$('.tabs').tabs();
	//$('.dropdown-trigger').dropdown();
	//$('.collapsible').collapsible();
  }); // end of document ready
})(jQuery); // end of jQuery name space
  
  
  /*  $(document).ready(function(){
    $('.tabs').tabs();
  }); */

/*  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelector('.collapsible.expandable');
    var instances = M.Collapsible.init(elems,{
  accordion : false,
  inDuration : 5000,
  onOpenStart	 : function(){
	  alert("by accordion ");
  }
});


  //instancesy = M.Collapsible.getInstance(elems);
  //instancesy.open(6); // take 0,2,4,6
  
}); */

 document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelector('.collapsible.expandable');
		var instances = M.Collapsible.init(elems,{
	  accordion : false
	});  
});

//function kicstarter(){
	//alert("go far");
//}
  
/*  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems, options);
  }); */
  