var gtmemberenewalbtn = document.getElementById("renewalclearancebtn");
var getrenewformname = document.getElementById("acpnclearanceform"); //get form id to retrieve form name
var membrpassport = document.getElementById("membr_passport");
var renewformname = document.getElementById("acpnclearanceform");
const fileUploadLimit = 3145728; // 3MB in bytes. Formula: 3MB = 3 * 1024 * 1024.


gtmemberenewalbtn.addEventListener("click",function(){
	
	//check passport and signature
	//chkIfsignatureImginStore();
	checkmemberPassport();


},false);

function checkmemberPassport(){
	
	if(membrpassport.files.length == 0){
	alert("No passport image selected");
	return false;
	//event.preventDefault();
	
	}else{	
	//alert(membrpassport.files[0].size(or)name);
	
	//converttobase64-passport
	convertoBase64Image(membrpassport);
	
	//checksignatureagain
	  //if(chkIfsignatureImginStore() == false){
		  //console.log("signature_not");;
		 // return false;
	  //} 
  	
	let renew_formname = renewformname.name;
	 passMembershipRenewaldata(renew_formname);
	//uploadChangeAction(membrpassport.files[0]);
	
	} 
}

//function to convert passport to base64 image
var imageData = [];
var localStorageKey = "Membrpassportdata";
function convertoBase64Image(e){

		const file =  e.files[0];
		if (file.size <= fileUploadLimit) {
		  const reader = new FileReader();

		  reader.onloadend = () => {
			const base64String = reader.result
			  .replace('data:', '')
			  .replace(/^.+,/, '');

			// Create an object containing image information.
			let imageObj = {
			  name: "image-" + file.name,
			  timestamp: Date.now(),
			  file_base64: base64String.toString()
			};
			
		  // console.log(imageObj.file_base64);
			addImage(imageObj);
		  };

		  reader.readAsDataURL(file);
		} else {
		//upload.after("<p>File too large</p>");
		  alert("File too large! - max size allowed is 3MB");
		}	
}

function addImage(imageObj) {
  imageData.push(imageObj);
  sessionStorage.setItem(localStorageKey, JSON.stringify(imageData));
}

function passMembershipRenewaldata(renewformname){
	//alert(renewformname);
	//return false;
var form = document.forms.namedItem(renewformname);

//form.addEventListener('submit', function(ev) {
	
  var membermakingrenewal = 1234;//usememberPCN_ID
  
  //JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  //membermakingrenewal = membermakingrenewal.memberid.toString();
  
  let signatureimg = sessionStorage.getItem("Signatureimg");
  
  if(signatureimg == null){
	  
	  alert("signature not in store");
	  return false;
	  
  }

	let memberpssportbase64 = sessionStorage.getItem("Membrpassportdata");

		if(memberpssportbase64 == null){
		  
		  alert("Passport not in store");
		  return false;
		  
	  }
	  
	let img_data = JSON.parse(memberpssportbase64);
 
	let	passport = img_data[0].file_base64;//get the image item
 
   var oOutput = document.getElementById("logrenewalrqst"),
  oData = new FormData(form);

  oData.append("Passport_Bs_64", passport);
  oData.append("Signatureimg", signatureimg);
  oData.append("Memberuid", membermakingrenewal);
  //oData.append("RenewUploadDir", "../renewals/renewaldocsUploadDir");
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "../scripts/clearanceformhandler.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      //oOutput.innerHTML = oReq.responseText;
	  //setTimeout(function(){oOutput.innerHTML = ""},2000);
	  console.log(oReq.responseText);	  
	  alert(oReq.responseText);
	 //location.reload();	  
    } else {
      //oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
	  alert("Error occurred when trying to upload your file.<br>");
    }
  };

  oReq.send(oData);
  //ev.preventDefault();
//}, false);
}
