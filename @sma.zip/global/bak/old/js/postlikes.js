function sendlikedpost(likedpost){

var mymemberlikeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymemberlikeid = mymemberlikeid.memberid.toString();
  
//alert(mymemberlikeid+"-"+likedpost);  

var formData = new FormData();
formData.append("LikedPost", likedpost);
formData.append("PostLikedbyWho", mymemberlikeid);
var responsespan = 'likedresponse'+likedpost;
var btnID = 'btnliked'+likedpost;
var request = new XMLHttpRequest();
request.open("POST", "scripts/postlikes.php");
request.onload = function(oEvent) {
	if (request.status == 200) {
	//console.log(request.responseText);
	//console.log(" Uploaded!");
	document.getElementById(responsespan).innerHTML = request.responseText;
	setTimeout(function(){document.getElementById(responsespan).innerHTML = "";},2000);
	//document.getElementById(btnID).style.backgroundColor = "yellow";
	location.reload();//change from this method
	} else {
	console.log("Error " + request.status + " occurred when trying to upload");
	}
	};
request.send(formData);
}