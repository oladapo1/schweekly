var gtailmentsendbtn = document.getElementById("logailmentbtn");
var getailmentformname = document.getElementById("ailmentlogform"); //get form id to retrieve form name

gtailmentsendbtn.addEventListener("click",function(){passAilLoggedtotoPostHandler(getailmentformname.name)},false);

function passAilLoggedtotoPostHandler(ailformname){
	//alert(ailformname);
var form = document.forms.namedItem(ailformname);

form.addEventListener('submit', function(ev) {
	
  var membermakingaillog = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  membermakingaillog = membermakingaillog.memberid.toString();
  
  var memberzone = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
  memberzone = memberzone.zone.toString();
  
  if(memberzone === "null"){
	  
	  alert("Kindly fill Zone in your profile section");
	  return false;
  }
  
 
  var oOutput = document.getElementById("logdresponse"),
      oData = new FormData(form);

  oData.append("WhomadeAilmntLog", membermakingaillog);
  oData.append("MembersZone", memberzone);
  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/ailmentlogginform.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;	
	 //location.reload();	  
	  //setTimeout(cleanUpailments,2000);
	  //setTimeout(location.reload(),3000);
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
    }
  };

  oReq.send(oData);
  ev.preventDefault();
}, false);
}

function cleanUpailments(){
	
	document.getElementById("selctailmentype").value = "";
	document.getElementById("selctpersoncatgo").value = "";
	document.getElementById("selctagerange").value = "";
	document.getElementById("selctsubzone").value = "";
	document.getElementById("ailmentlogdate").value = "";
	document.getElementById("logdresponse").innerHTML = "";
	//location.reload();
}