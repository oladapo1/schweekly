// handles Birtday roll 
var holdbirthdaypersonId;
var holdgreetncardId = -1;

function hugbuff(personwhosebdayid){
	document.getElementById("sendbtnbirthdaycard").style.display = "block";	
	holdbirthdaypersonId = personwhosebdayid;
	}
	
	var counter = -1;
	var retrievephotos1 = localStorage.getItem("BuffbdayPhotos");
	var retrievephotos = JSON.parse(retrievephotos1);	
	var len_bdayarray = retrievephotos.length;
		
function displayCenterbtnnext(centerbuffid){
	counter++;
	holdgreetncardId = counter;
	document.getElementById("buffoutterbuddy").style.backgroundImage = "url('../images/birthdaystemplate/"+retrievephotos[counter]+"')";
	
	document.getElementById(centerbuffid).style.display = "block";

	if(counter == len_bdayarray){
	 counter = -1;
	}
}

function displayCenterbtnprev(centerbuffid){
	
	if(counter <= 0){
	 counter = 1;
	}
	counter--;
	holdgreetncardId = counter;
	document.getElementById("buffoutterbuddy").style.backgroundImage = "url('../images/birthdaystemplate/"+retrievephotos[counter]+"')";
	
	document.getElementById(centerbuffid).style.display = "block";
}

var gtsendbdaygretnbtn = document.getElementById("sendbtnbirthdaycard");
gtsendbdaygretnbtn.addEventListener("click",sendBirthdaygreetn,false);

function sendBirthdaygreetn(){
	var mymembershipeidbday = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbday = mymembershipeidbday.memberid.toString();
	
	//alert(mymembershipeidbday +"-"+holdbirthdaypersonId+"-"+holdgreetncardId);
	
	 
		if(mymembershipeidbday === ""){
		alert("You seem not to be logged in");
		return false;
			}
		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                //console.log(xhttp.responseText);
				alert(xhttp.responseText);
			//setTimeout(function(){document.getElementById("myregstaffs").innerHTML = xhttp.responseText},1000);
            }
        };
		
	xhttp.open("POST","scripts/birthdaygreetingroll.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_mymembershipeidbday="+mymembershipeidbday+"&send_holdbirthdaypersonId="+holdbirthdaypersonId+"&send_gcard="+holdgreetncardId);

}
