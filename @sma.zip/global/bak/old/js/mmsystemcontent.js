var sysmcontleadids = {
	flashinfoid     : "flashinfopr",
	yespertid       : "yespertloadr",
	yespertbiobtnid : "yespertbioloadr",
	podcastsid      : "mypodcasts", 
	podcaststtleid  : "podcasttitle",
	videoid         : "myvodeo",
	videottleid     : "videotitle",
	articlesid      : "featuredarticles",
	articlesttleid  : "articletitle"
};

//Flash Info

var flashInfo = [

{
	infotype    :"",
	infobody    :"News flash 1",
	dateissued  :"",
	infoduration :"4000"
},

{
	infotype     :"",
	infobody     :"Gist Cafe",
	dateissued   :"",
	infoduration :"9000"
},

{
	infotype     :"",
	infobody     :"Health flash",
	dateissued   :"",
	infoduration :"9000"
},

{
	infotype     :"",
	infobody     :"Voting will begin in 2 hours time",
	dateissued   :"",
	infoduration :"9000"
},

{
	infotype     :"",
	infobody     :"Get you Emblem at YESBA zone",
	dateissued   :"",
	infoduration :"9000"
}

];

var flashinfocounter = 0;
//function runFlsahInfo(){
	(
	function(){
		
		//alert(flashInfo.length);
	let infodur = flashInfo[flashinfocounter].infoduration;
	
	let flashbody = document.getElementById(sysmcontleadids.flashinfoid);
	setInterval(
			//for(i = 0; i < flashInfo.length;i++){
		function(){
		if(flashinfocounter == flashInfo.length){
			flashinfocounter = 0;
		}
		
		//$("#flashinfopr").fadeToggle(8000);
		$("#flashinfopr").fadeTo("slow", 0.59);
		flashbody.style.backgroundColor = "#101010";
		flashbody.innerHTML = flashInfo[flashinfocounter].infobody;
		flashbody.style.color = "#fff";
		$("#flashinfopr").fadeTo("slow", 0.99);
		//runFlsahInfo(flashInfo[flashinfocounter].infoduration,flashInfo[flashinfocounter].infobody);
		flashinfocounter++;
		},infodur);

}
	)();
	
	
	function runFlsahInfo(e,f){
		let infodur = flashInfo[flashinfocounter].infoduration;
		let flashbody = document.getElementById(sysmcontleadids.flashinfoid);
		
		//alert(e+"--"+f);
		
		setTimeout(function(){flashbody.innerHTML = f;},e);
						
			//flashbody.animate({left: '250px'});
			//$("#flashinfopr").slideDown(3000);}
			 //$("#flashinfopr").fadeIn(3000);
			
		//alert(e+"--"+f);
	}
///////////
//YESBA Expert - specialist in focus

var yespertbio = {
	
	yespertnames    : "Aladesanmi Busola",
	yespertimage    : "../images/aladesanmiyespert.PNG",
	yesperticles    : "5",
	yespertposts    : "42",
	yespertpodcasts : "10",
	yespertconnctn  : "35",
	yespertcareer   : "Doctor",
	yespertbiopsy   : "Some example text some example text. Some example text some example text. Some example text some example text. Some example text some example text.",
	yespertmentors  : "",
	yespertalumnus  : ""
	
}


function loadYespertBiodata(){
	
	//yesbiocontent yespertcareer yespertconnctns yespertpodcasts yespertposts yespertarticles yespertnamez yespimage
	
	document.getElementById("yespimage").src = yespertbio.yespertimage;
	document.getElementById("yespertnamez").innerHTML = yespertbio.yespertnames;
	document.getElementById("yespertarticles").innerHTML = yespertbio.yesperticles;
	document.getElementById("yespertposts").innerHTML = yespertbio.yespertposts;
	document.getElementById("yespertpodcasts").innerHTML = yespertbio.yespertpodcasts;
	document.getElementById("yespertconnctns").innerHTML = yespertbio.yespertconnctn;
	document.getElementById("yespertcareer").innerHTML = yespertbio.yespertcareer;
	document.getElementById("yesbiocontent").innerHTML = yespertbio.yespertbiopsy;
	
}

////////////////

var audiotxtncontent = [
	{
		podctitle : "Everday Ethics",
		podctrack : "EverydayEthics-20180729-SisterHelenPrejean.mp3"
	},
	{
		podctitle : "Grow up land",
		podctrack : "GrownUpLand-20180426-9TheFuture.mp3"
	},
	{
		podctitle : "How to invent a country",
		podctrack : "HowToInventACountry-20180524-WelcomeToHowToInventACountry.mp3"
	},
	{
		podctitle : "Thought of the day",
		podctrack : "ThoughtForTheDay-20180731-RevDrGilesFraser.mp3"
	},
	{
		podctitle : "Catholic : Joyful Mysteries",
		podctrack : "Rosary-Joyful-Mysteries.mp3"
	},
	{
		podctitle : "Comedy of the week",
		podctrack : "ComedyOfTheWeek-20180730-JakeYappsMediaCircus.mp3"
	}
	
];


var videotxtncontent = [
	{
		videotitle : "Pharmako kinetics",
		videorack : "pharmakokinectics.mp4"
	},
	{
		videotitle : "How the brain works",
		videorack : "howthebrainworks.mp4"
	},
	{
		videotitle : "Drug metabolism",
		videorack : "drugmetabolism.mp4"
	},
	{
		videotitle : "Aspirin journey",
		videorack : "Aspirin Journey through the body - 3D Animation.mp4"
	},
	{
		videotitle : "Sodade",
		videorack : "cesarievora_sodade.mp4"
	}
	
];


var articlecontent = [
	{
		artkletitle : "Pharmako kinetics",
		artkleftured : "Meta kinetic nature of drugs"
	},
	{
		artkletitle : "How the brain works",
		artkleftured : "article2"
	},
	{
		artkletitle : "Drug metabolism",
		artkleftured : "article3"
	},
	{
		artkletitle : "Aspirin journey",
		artkleftured : "article4"
	},
	{
		artkletitle : "Sodade",
		artkleftured : "article5"
	}
	
];

/* var loadbtn = {
	podcastprv : "podcprv",
	podcastnxt : "podcnxt",
	articleprv : "artlceprv",
	articlenxt : "artclenxt"
}; */

/* var podcastsload = ["EverydayEthics-20180729-SisterHelenPrejean.mp3","GrownUpLand-20180426-9TheFuture.mp3","HowToInventACountry-20180524-WelcomeToHowToInventACountry.mp3","ThoughtForTheDay-20180731-RevDrGilesFraser.mp3","ComedyOfTheWeek-20180730-JakeYappsMediaCircus.mp3","Rosary-Joyful-Mysteries.mp3"];


var  videoload = ["pharmakokinectics.mp4","howthebrainworks.mp4","drugmetabolism.mp4","Aspirin Journey through the body - 3D Animation.mp4","cesarievora_sodade.mp4"];


var articlesload = ["Meta kinetic nature of drugs","article2","article3","article4","article5"]; */ 



//Podcasts
var pdcastcounter = -1;
//window.onload = loadPodcastnxt; // load first podcast 

let pdcanxt = document.getElementById("podcnxt");
pdcanxt.onclick = loadPodcastnxt;

function loadPodcastnxt(){
	
	pdcastcounter++;
	
	if(pdcastcounter == audiotxtncontent.length){
		
		pdcastcounter = pdcastcounter-1;
		return false;
	
	} 
		
	if(pdcastcounter == 1){
		
		document.getElementById("podcprv").style.display = "inline";		
	}
	let pdcastitle = document.getElementById(sysmcontleadids.podcaststtleid);
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podctitle;
	
	let pdcastrack = document.getElementById(sysmcontleadids.podcastsid);
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].podctrack;
	//alert("/scontent/podcasts/"+podcastsload[0]); 	
}

let pdcastprv = document.getElementById("podcprv");
pdcastprv.onclick = loadPodcastprv;


function loadPodcastprv(){

		--pdcastcounter;
	  if(pdcastcounter == -1 || pdcastcounter < 0){
                        //document.getElementById("sectonnumbrs").innerHTML = 0;
                        pdcastcounter = 0;
                    }

	let pdcastitle = document.getElementById(sysmcontleadids.podcaststtleid);
	pdcastitle.innerHTML = audiotxtncontent[pdcastcounter].podctitle;
	
	let pdcastrack = document.getElementById(sysmcontleadids.podcastsid);
	pdcastrack.src = "../scontent/podcasts/"+audiotxtncontent[pdcastcounter].podctrack;
}



//Videos
	function seCurtime(){
		let vid = document.getElementById("myvodeo");
		vid.currentTime=3;
	}
	function playVideo(){
		let vid = document.getElementById("myvodeo");
		vid.play(); 
	}
		function pauseVideo(){
		let vid = document.getElementById("myvodeo");
		vid.pause(); 
	}
		/* function stopVideo(){
		let vid = document.getElementById("myvodeo");
		vid.play(); 
	} */
	
	
	
//Articles
var articlecounter = -1;
window.addEventListener("load",function(){loadArticlenxt(),loadPodcastnxt();},false);

//window.onload = loadArticlenxt;loadPodcastnxt; // load 

let rdarticlenxt = document.getElementById("artclenxt");
rdarticlenxt.onclick = loadArticlenxt;

function loadArticlenxt(){
	
	articlecounter++;
	
	if(articlecounter == audiotxtncontent.length){
		
		articlecounter = articlecounter-1;
		return false;
	
	} 
	//alert(articlecounter);	
	if(articlecounter == 1){
		
		document.getElementById("artlceprv").style.display = "inline";		
	}
	let artictitle = document.getElementById(sysmcontleadids.articlesttleid);
	artictitle.innerHTML = articlecontent[articlecounter].artkletitle;
	
	/* let artklefetured= document.getElementById(sysmcontleadids.articlesid);
	artklefetured.innerHTML = articlecontent[articlecounter].artkleftured; */	
}

let rdarticleprv = document.getElementById("artlceprv");
rdarticleprv.onclick = loadArticleprv;

function loadArticleprv(){

		--articlecounter;
	  if(articlecounter == -1 || articlecounter < 0){
                        //document.getElementById("sectonnumbrs").innerHTML = 0;
                        articlecounter = 0;
                    }
	//alert(articlecounter);
	let artictitle = document.getElementById(sysmcontleadids.articlesttleid);
	artictitle.innerHTML = articlecontent[articlecounter].artkletitle;
	
	/* let artklefetured = document.getElementById(sysmcontleadids.articlesid);
	artklefetured.innerHTML = articlecontent[articlecounter].artkleftured; */
}
