document.addEventListener("DOMContentloaded",collatetoViewCommunityMsgstostore(),false);
 function collatetoViewCommunityMsgstostore(){
    var memberqstmsgs = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	memberqstmsgs = memberqstmsgs.memberid.toString();
     
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

            console.log(xhttp.responseText);
            //alert(xhttp.responseText);
            sessionStorage.setItem("MessagesFrmComm",this.responseText);
            let msgbb = JSON.parse(sessionStorage.getItem("MessagesFrmComm"));
            
            document.getElementById("allcommunityresponses").innerHTML = msgbb.length;
        }
        };
	
	xhttp.open("POST","scripts/collate_messagesfrmcommunty.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_my_commmembershipe_id="+memberqstmsgs);
 }
 
 
  setInterval(fillmsgBubbleforcomm,3000);
 function fillmsgBubbleforcomm(){
     collatetoViewCommunityMsgstostore();
     let listcount = JSON.parse(sessionStorage.getItem("MessagesFrmComm"));
     document.getElementById("allcommunityresponses").innerHTML = listcount.length;
     
 }
 
 
  let message_mnu = document.getElementById("allcommunityresponsesmnu");
 message_mnu.addEventListener("click",collatetoViewMyCommunityMsgs,false);
 
 function collatetoViewMyCommunityMsgs(){
     let addnewform_inline = document.getElementById("chatbuddylistings");
      addnewform_inline.innerHTML = "";
    /*
    [{"Fname":"Chioma","Lname":"Adetuyi","Photo":"IMG_20201108_155807_493.jpg","Career":"0","LGA":"","MemberID":"933335","Replies":"Saw your message will reply asap"}]
    [{"uname":"batroknig","email":"babtroknigltd@gmail.com","commuid":"167856","msgs":"Hu","sentdate":"2021-08-14 04:43:43","msgUID":"556273"}]
    */
    
    carrier_commsgs = '<ul class="collection" style="margin:-15px;">';
     let replycount = JSON.parse(sessionStorage.getItem("MessagesFrmComm"));

    for(i = 0; i < replycount.length; i++){
    carrier_commsgs += '<li class="collection-item avatar"><img src="" class="circle" style=""><span class="title"></span><p style="font-size:0.85em;font-weight:700;"><br>'+replycount[i].email +" | "+ replycount[i].uname+'<br>'+replycount[i].msgs+'<hr> date: '+replycount[i].sentdate+'</p><a href="#!" class="secondary-content"><i class="material-icons" style="font-size:1.65em;margin:0px 1px 0px 4px;" id="messg_lst'+replycount[i].commuid+'">chat</i></a></li>'; 
     }
     addnewform_inline.innerHTML = carrier_commsgs;
 }