function getItemsandlisthem(){	
var i;

var myObj = JSON.parse(sessionStorage.getItem("initBcastsload"));		

for (i in myObj.BcastsData){

//console.log(myObj.BcastsData[i].Request); //fine

//for Bubblet
document.getElementById("allbroacastbublet").innerHTML = myObj.BcastsData[i].TotalBCasts; 

var para = document.createElement("a");
para.setAttribute("class", "list-group-item list-group-item-action");


var element = document.getElementById("myrecentbcastitems");
element.appendChild(para);

 //create button
  var tdbtn = document.createElement("TD");
  var xbtn = document.createElement("BUTTON");
  xbtn.setAttribute("id", myObj.BcastsData[i].BCid);
  xbtn.setAttribute("class", "myItemsbtn");
  var tbtn = document.createTextNode("+");
  xbtn.appendChild(tbtn);
  para.appendChild(xbtn);
  element.appendChild(para); 
  
  var node = document.createTextNode(myObj.BcastsData[i].Request);
//para.setAttribute("id", myObj.BcastsData[i].BCid);
para.appendChild(node);
  
   
   //collate arguments for function parameters 
   var bcastId  = myObj.BcastsData[i].BCid;
   var expiratndate = myObj.BcastsData[i].Expires;
   var reqstopic = myObj.BcastsData[i].Request;
   var creatndate = myObj.BcastsData[i].Created;
   var msgbcastd = myObj.BcastsData[i].BCmsg;
   var authorofbcast = myObj.BcastsData[i].AuthorId;
   
   
   
 /* send of created ids  to sendArr*/
   sendArr(bcastId,expiratndate,reqstopic,creatndate,msgbcastd,authorofbcast);

}	
	}

var bcastonwatch;

function sendArr(pId,expdate,rqstopic,creatdte,msgbody,authorid){
	
	//alert(pId);
	
	/* When there is a click on any of the items btn (in the shelf - function ) - send the data rqd to updateReactionView function */
	
	document.getElementById(pId).addEventListener("click", function(){updateReactionView(pId,expdate,rqstopic,creatdte,msgbody,authorid);
	bcastonwatch = pId},false);
	//document.getElementById(pId).addEventListener("click", function(){this.style.display = "none";});
	document.getElementById(pId).addEventListener("click", function(){pullmyReactions_m(this.id)},false);
			
}


function updateReactionView(sentItemid,sentexpiratn,sentreqst,sentcreatdate,sentmsgbdy,sentauthorid){
var j;
var authorpix,memphone,authorfname,authorlname,expiresin,bcastopic,createdate,bcastmsg;

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
	//{"Broadcaster":[{"Firstname":"Fermi","Surname":"Logan","Picture":"pixdefault.png"}]}
	
	sessionStorage.setItem("Minidetails", '{"\Broadcaster"\:'+this.responseText+'}');
		var myObj2 = JSON.parse(sessionStorage.getItem("Minidetails"));	
	for (j in myObj2.Broadcaster){
			var bcpix  = myObj2.Broadcaster[j].Picture;
			var bcfname  = myObj2.Broadcaster[j].Firstname;
			var bclname  = myObj2.Broadcaster[j].Surname;
			var bcphone  = myObj2.Broadcaster[j].Phone;
			}
			
			
			document.getElementById("authorpix").src = "../images/profileimages/"+bcpix;
			document.getElementById("authorfname").innerHTML = bcfname;
			document.getElementById("authorlname").innerHTML = bclname;
			document.getElementById("memphone").innerHTML = bcphone;
			document.getElementById("expiresin").innerHTML = sentexpiratn;
			document.getElementById("bcastopic").innerHTML = sentreqst;
			document.getElementById("createdate").innerHTML = sentcreatdate;
			document.getElementById("bcastmsg").innerHTML = sentmsgbdy;	
			
			location.href = "#mybcastsview";
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/getdetailbcaster.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_authorid=" +sentauthorid);
}

function pullmyReactions_m(whoreacted){
	
	//alert(whoreacted);
			
	var mymembershipeidbcasticreated = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbcasticreated = mymembershipeidbcasticreated.memberid.toString();
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
		//console.log(this.responseText);
		document.getElementById("bcastspecreactnsdiv").innerHTML = this.responseText;
		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pulL_allrxn_m.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_whoreacted="+whoreacted);
}


var rxnbtn = document.getElementById("bcastsreactnbtn");
rxnbtn.onclick = sendReactintextarea;

function sendReactintextarea(){
var gtBCastrxnbody = document.getElementById("bcastsreactnarea").value;
if(gtBCastrxnbody == ""){
alert("Cannot be empty!");
document.getElementById("bcastsreactnarea").focus();
return false;
}
if(bcastonwatch == undefined){
alert("Choose a broadcast to react to");
document.getElementById("bcastsreactnarea").value = "";
return false;
}

var mymembershipeidbrxn = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeidbrxn = mymembershipeidbrxn.memberid.toString();
	

/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			
			if(xhttp.responseText){
				alert(xhttp.responseText);
				//location.reload();
			}else{
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/broadcastreactn.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_bcastrxnbdy="+gtBCastrxnbody+"&send_rootbcastid="+bcastonwatch+"&send_mymembershipeidbrxn="+mymembershipeidbrxn);
}

/* window.onload = function(){
pullrecentBroadcast();
}  */

document.addEventListener("DOMContentLoaded",pullrecentBroadcast,false);

//document.getElementById("myrececentrxns").onclick = pullrecentBroadcast;
function pullrecentBroadcast(){
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
	//sessionStorage.setItem("initBcastsload", '{"\BcastsData"\:['+this.responseText+']}');
	sessionStorage.setItem("initBcastsload", '{"\BcastsData"\:'+this.responseText+'}');
				
		getItemsandlisthem();	
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","scripts/pullrecentbcast.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send();
}