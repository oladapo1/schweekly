//HANDLE SAVE ICON - & DISABLEd FIELDS
function getSentFieldData(gtId){
		
	var gtitem = document.getElementById(gtId).value;
	//alert(gtId+" - "+gtitem);
	if(gtId != undefined && gtitem  != ""){
		//mysnackbarFunctionu("edit processing"); // at the frontend, the message is overlapped by xthhp response below
		//alert("edit processing");	
		
		sendtoProfileProcessor(gtitem,gtId);
		
		document.getElementById(gtId).disabled = true;
	}else{
		//mysnackbarFunctionu("do you mean to edit?");
		alert(" do you want to edit?");	
	}

}

//ENABLE FIELD - EDIT ICON
function enableFileds(sentid){

	var enabletextboxField = document.getElementById(sentid);
	enabletextboxField.disabled = false;
	//enabletextboxField.value="";
	enabletextboxField.focus();
	
}


//HANDLE Profilepix UPLOAD
var getm_profilesubmitbtn = document.getElementById("member_mpixbtn");
var getm_profileformname  = document.getElementById("profilepixformid");

getm_profilesubmitbtn.addEventListener("click",function(){determImgCatgo(getm_profileformname.name)},false);

function determImgCatgo(e){
	var fileinputvalue = document.getElementById("mypix_edt");//On the way mypix_edt m_profilepixform
	
	if(fileinputvalue.files.length == 0){
	alert("No image selected");
	event.preventDefault();
	//return false;
	}else{	
	passImgCatgotoHandler(e);
	//alert("On the way "+fileinputvalue.id+" "+e);
	} 
	
	//passImgCatgotoHandler(e);
}

function passImgCatgotoHandler(filepix){
var form = document.forms.namedItem(filepix);

form.addEventListener('submit', function(ev) {
	
	let membereditby_mprofile = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	membereditby_mprofile = membereditby_mprofile.memberid.toString();
	
	 let folderToUpload;
	 let pixfiletoupload;
	//profilepix portfolios banners
	if(filepix == "profilepixforms"){
		
		//folderToUpload = "profileimages";
		folderToUpload = "../images/profileimages";
		//pixfiletoupload = "mypix_edt";
	}
	else{
		alert("Voops!");
	}
  //alert(filepix +" from profile pixle");
 
  var oOutput = document.getElementById("uploadmsg"),
      oData = new FormData(form);

  oData.append("UploadDir", folderToUpload);
  //oData.append("ImagefromFileInput", pixfiletoupload);
  oData.append("Whoeditnpix", membereditby_mprofile);

  var oReq = new XMLHttpRequest();
  oReq.open("POST", "scripts/profilepixuploadr.php", true);
  oReq.onload = function(oEvent) {
    if (oReq.readyState == 4 && oReq.status == 200){
      oOutput.innerHTML = oReq.responseText;
    } else {
      oOutput.innerHTML = "Error " + oReq.status + " occurred when trying to upload your file.<br>";
    }
  };

  oReq.send(oData);
  ev.preventDefault();
}, false);
}

//AjaX HANDLER
function sendtoProfileProcessor(itemEditd,itemtype){

	var mymembershipeid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
	mymembershipeid = mymembershipeid.memberid.toString();

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {
	    if (this.readyState == 4 && this.status == 200) {
			console.log(xhttp.responseText);
			alert(xhttp.responseText);
			//var alert_notify4 = xhttp.responseText;
			//mysnackbarFunctionu(alert_notify4);

	    }
	};

	 /* Using POST */ 
xhttp.open("POST","scripts/profiledit.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_itemEdited=" +itemEditd +"&send_itemType=" +itemtype+"&send_pullmembersenderxid="+mymembershipeid);
}

/*function mysnackbarFunctionu(alertry){
    // Get the snackbar DIV
    var x = document.getElementById("snackbar")

    // Add the "show" class to DIV
	x.className = "show";
	x.innerHTML = alertry;
 

    // After 3 seconds, remove the show class from DIV
    setTimeout(function(){ x.className = x.className.replace("show",""); }, 3000);
}*/