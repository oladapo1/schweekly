function foldUpnOut(thecardtohide){
gtcarddiv = "#"+thecardtohide;
$(gtcarddiv).fadeTo("slow", 0.45);
//$(gtcarddiv).fadeTo("slow", 0.9);
//document.getElementById(thecardtohide).style.display='none';
$(gtcarddiv).slideUp("slow");
event.preventDefault();
setTimeout(function(){document.getElementById(thecardtohide).style.display='none'},1500);
}
