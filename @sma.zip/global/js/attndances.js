let prenstbtn = document.getElementById("statuspresnt");
let absentbtn = document.getElementById("statusabsent");
let ulpresnt  = document.getElementById("presntstatus_ul");
let ulabsent  = document.getElementById("absntsatus_ul");
//////////////////////
let slctorchk = document.getElementById("dselector");
document.addEventListener("DOMContentLoaded",function(){

let schattnd = JSON.parse(sessionStorage.getItem("scweeklymeta"));

//myclassAttendance();
checkStafftype();
}
,false);



function checkStafftype(){
	
let chkstafftype = JSON.parse(sessionStorage.getItem("scweeklymeta"));	
	
	//let vv  = chkstafftype.length;
	let stafftype = chkstafftype[0][0].catype;
	
	//console.log(chkstafftype[0].length);
	//console.log(chkstafftype[1].length);
	console.log(stafftype+" atn");
	
	if(stafftype == 1){
	
	document.getElementById("getpupilbyclass").style.display = "block";
	//document.getElementById("mainattendanceboard").style.display = "none";
	metaTapestaff();
	
	}else if(stafftype == 2){
	
	//console.log();
	myclassAttendance();
	document.getElementById("mainattendanceboard").style.display = "block";
	metaTapestaff();
	}


	function metaTapestaff(){
	
	var classarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
	var classarmarray = ["A","B","C","D","E","F"];
	
	let staffsname  = chkstafftype[0][0].staffsurname;
	let stfirstname = chkstafftype[0][0].stafffname;
	let staffclass  = chkstafftype[0][0].classtut;
	let classarmtut = chkstafftype[0][0].classarm;
	
	document.getElementById("classlbl").innerHTML = "<p style='font-weight:700;font-size:0.7em;color:#101010;'>Hi, "+staffsname+" "+stfirstname+"-"+classarray[staffclass]+" "+classarmarray[classarmtut]+"</p>";
	}

}


slctorchk.addEventListener("change",myclassAttendance,false);

var classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
var classarrylen = classarry[1].length;

function myclassAttendance(){

console.log(classarrylen);

let txt = "";
chkbxpresentids4 = [];
absentees = [];

for (i = 0; i < classarrylen; i++){
	
	let names = classarry[1][i].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][i].pupilsfname;
	
	txt += "<li class='collection-item'><div>"+names+"<a href='#' class='secondary-content'><label><input type='checkbox' class='presentoday' id='"+classarry[1][i].pupilrefnumbr+"'/><span></span> </label></a></div></li>";

}

document.getElementById("classlisting").innerHTML = txt;


if(slctorchk.checked == true){
//console.log("ok");

let to_checkall = document.getElementsByClassName("presentoday");
	
	for (i = 0; i < to_checkall.length; i++) {
	
		to_checkall[i].checked = true;
		
		processPupilcheked(to_checkall[i].id);
	
	}

}else if(slctorchk.checked == false){
//console.log("nok");

let to_uncheckall = document.getElementsByClassName("presentoday");

	for (j = 0; j < to_uncheckall.length; j++) {
	
		to_uncheckall[j].checked = false;
		
		processPupilcheked(to_uncheckall[j].id);
		
	}
    
	cleanQueued();
}

//this code allows for individual pupil checking
let pupilchecked = document.getElementsByClassName("presentoday");
	
	for (i = 0; i < pupilchecked.length; i++) {
	
		pupilchecked[i].onchange = function(){
				
				//console.log("available "+this.id);

				processPupilcheked(this.id);
		}
	}	  
}


var chkbxpresentids4 = [];
var absentees = [];
function processPupilcheked(idload){
	
	//console.log("availab "+idload);
	var isattnselctnboxchked = document.getElementById(idload);

	if(isattnselctnboxchked.checked == true){
		
		setblankSummaryulist();
		
		chkbxpresentids4.push(idload);
		sessionStorage.setItem("Collatedpupils",JSON.stringify(chkbxpresentids4));
		
		sessionStorage.setItem("Absenteespupil",'['+'"'+0+'"'+']');//set to 0
		
		for(k = 0; k < absentees.length; k++){

			if(absentees[k] == idload){
				absentees.splice(k, 1);
				
				sessionStorage.setItem("Absenteespupil",JSON.stringify(absentees));

			}
		
		}
		
	}else if(isattnselctnboxchked.checked == false){
	//console.log("absentees "+idload);
	
	setblankSummaryulist();

	absentees.push(idload);
	sessionStorage.setItem("Absenteespupil",JSON.stringify(absentees));
	
	for(i = 0; i < chkbxpresentids4.length; i++){

			if(chkbxpresentids4[i] == idload){
				chkbxpresentids4.splice(i, 1);
				sessionStorage.setItem("Collatedpupils",JSON.stringify(chkbxpresentids4));
				if(chkbxpresentids4.length == 0){
					sessionStorage.setItem("Collatedpupils",'['+'"'+0+'"'+']');
				}
			}
		}
	}	 
}


function setblankSummaryulist(){
	ulabsent.innerHTML = "";
	ulpresnt.innerHTML = "";
};
		
prenstbtn.addEventListener("click",function(){
	
	let ul_prt  = "";
	let val = 1;

	attendanceSummary(val);
	
	//let colatedpresent = JSON.parse(sessionStorage.getItem("Collatedpupils"));
	//console.log(colatedpresent.length);

});		
		
absentbtn.addEventListener("click",function(){

	let val = 2;
	attendanceSummary(val);

},false);


function attendanceSummary(val){

	if(val == 1){
	let ul_presnt  = "";
	let colatedpresent =  JSON.parse(sessionStorage.getItem("Collatedpupils"));
	
	//display class size
	document.getElementById("totalinclass").innerHTML = "Class size "+classarry[1].length;
	
	if(colatedpresent == null){
	console.log("nullity");
	return false;
	}
	
	//console.log(colatedpresent[0]);
	let prsntclassize  =  getCurclassize(val);
		//console.log(getCurclassize(val));
		
		
	ul_presnt += "<li class='collection-header' style='font-weight:700;'>Pupils Present today  <span class='badge #80cbc4 teal lighten-3 white-text'>"+prsntclassize+"</span></li>";
	
	for(i = 0; i < colatedpresent.length; i++){
		
		for(j = 0; j < classarry[1].length; j++){
			
		let names = classarry[1][j].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][j].pupilsfname;

			
			if(classarry[1][j].pupilrefnumbr == colatedpresent[i]){
					
			ul_presnt += "<li class='collection-item'>"+names+"</li>";
			
			}else{
			//todo
			}

		}
	}	
	
	ulpresnt.innerHTML = ul_presnt;

	}
	else if(val == 2){
	
		let collatedabsent = JSON.parse(sessionStorage.getItem("Absenteespupil"));
		let ul_absnt = "";
		
		let absntclassize = getCurclassize(val);
		
		ul_absnt += "<li class='collection-header' style='font-weight:700;'>Pupils Absent today <span class='badge #546e7a #c62828 red darken-3 white-text'>"+absntclassize+"</span></li>";
		
		for(i = 0; i < collatedabsent.length; i++){
			
			for(j = 0; j < classarry[1].length; j++){
			
				let names = classarry[1][j].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][j].pupilsfname;
				
				if(classarry[1][j].pupilrefnumbr == collatedabsent[i]){
						
				ul_absnt += "<li class='collection-item'>"+names+"</li>";
				
				}else{
				//todo
				}

			}
		}
		ulabsent.innerHTML = ul_absnt;
	}
}


function getCurclassize(curval){
	
	let v;

	if(curval == 1){
	ulabsent.innerHTML = "";
	let colpresent  =  JSON.parse(sessionStorage.getItem("Collatedpupils"));
	
		if(colpresent[0] == 0){
		v = 0;
		}else{
		v = colpresent.length;
		}
	
	}else if(curval == 2){
	ulpresnt.innerHTML = "";
	let colabsent   =  JSON.parse(sessionStorage.getItem("Absenteespupil"));
	
		if(colabsent[0] == 0){
		v = 0;
		}else{
		v = colabsent.length;
		}
	
	}

	return v;
	
}

function cleanQueued(){

chkbxpresentids4 = [];
sessionStorage.setItem("Collatedpupils",'['+'"'+0+'"'+']');

console.log("cleaning complete");
}


let attendances_btn = document.getElementById("attendancesbtn");
attendances_btn.addEventListener("click",sendAttendancetodb,false);
function sendAttendancetodb(){
	
		let puplpresent  =  JSON.parse(sessionStorage.getItem("Collatedpupils"));
		let puplabsent   =  JSON.parse(sessionStorage.getItem("Absenteespupil"));
		let schooluid    =  classarry[0][0].schuid;
		let staffrefid   =  classarry[0][0].staffrefnumbr;
		let schclass     =  classarry[0][0].classtut;
		let clasalias    =  classarry[0][0].classarm;
		
		//console.log(schooluid+"-"+staffrefid+"-"+schclass+"-"+clasalias);
		//return false;
		
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {		
		//console.log(schooluid); return false;

	    if (this.readyState == 4 && this.status == 200) {
			
			console.log(xhttp.responseText);
			
			/* console.log(xhttp.responseText); */
			/* alert(xhttp.responseText); */
			//sessionStorage.setItem("guadianmetaload",xhttp.responseText);

		}
		};

	 /* Using POST */ 
	xhttp.open("POST","../assets/scripts/dailyprogsreports/pushcollatedattn.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("send_schuid="+schooluid+"&pupil_prsnt="+puplpresent+"&pupil_absnt="+puplabsent+"&staff_refid="+staffrefid+"&class_refid="+schclass+"&class_arm="+clasalias); 
}

function checkInitParams(){

//let initcatype = sessionStorage.getItem("Usercatgotype");

	if(initcatype == 1){

	}else if(initcatype == 2){

	}

}

let adminattnrqsbtn = document.getElementById("attendancesrch");
adminattnrqsbtn.addEventListener("click",function(){

attnPupilsrqstbyadmin();

},false);

function attnPupilsrqstbyadmin(){
let classpicked    = document.getElementById("selPresntclass");
let classarmpicked = document.getElementById("classalias2");
let chkstafftype   = JSON.parse(sessionStorage.getItem("scweeklymeta"));	
let stfid    = chkstafftype[0][0].staffrefnumbr;
let sch_id   = chkstafftype[0][0].schuid;
//console.log(stfid);
//let stfirstname = chkstafftype[0][0].stafffname;
//console.log(classpicked.value +"-"+classarmpicked.value);
///////////////////////////////////

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				
				sessionStorage.setItem("scweeklymeta",xhttp.responseText);
				//sessionStorage.setItem("Countr",0);
				////////
				
				myclassAttendance();
				document.getElementById("mainattendanceboard").style.display = "block";
				
				/////////
				//document.getElementById('verifynow').innerHTML = xhttp.responseText;
				//location.href="attendance.html";
				//location.href="dpr.html";

			}else{
				
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/auth/global/screapst/adminglob.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_admin_id="+stfid+"&snd_class="+classpicked.value+"&snd_classarm="+classarmpicked.value+"&snd_schid="+sch_id);
}