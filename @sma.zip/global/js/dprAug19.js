let prevtbtn = document.getElementById("prev");
let nextbtn  = document.getElementById("vext");

document.addEventListener("DOMContentLoaded",function(){

var elems = document.querySelectorAll('.collapsible');
var instances = M.Collapsible.init(elems,{

//onCloseEnd : function(){console.log("hy")}

});    

let schattnd = JSON.parse(sessionStorage.getItem("scweeklymeta"));

//call main function to begin dpr ops - spill first view items
//myclassDailyprogress();

checkStaffDPRtype();


//initialize selection of reports
storedprforSummaryonreveal();

}
,false);

///////////////////////

function checkStaffDPRtype(){
	
let chkstafftype = JSON.parse(sessionStorage.getItem("scweeklymeta"));	
	
	//let vv  = chkstafftype.length;
	let stafftype = chkstafftype[0][0].catype;
	console.log(stafftype+" staff type");
	if(stafftype == 1){
	
	document.getElementById("getpupilbyclass").style.display = "block";
	//document.getElementById("maindprboard").style.display = "none";
	metaTapestaff();
	
	}else if(stafftype == 2){

	myclassDailyprogress();
	document.getElementById("dprmainboard").style.display = "block";
	metaTapestaff();
	}


	function metaTapestaff(){
	
	var classarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
	var classarmarray = ["A","B","C","D","E","F"];
	
	let staffsname  = chkstafftype[0][0].staffsurname;
	let stfirstname = chkstafftype[0][0].stafffname;
	let staffclass  = chkstafftype[0][0].classtut;
	let classarmtut = chkstafftype[0][0].classarm;
	
	document.getElementById("classlbl").innerHTML = "<p style='font-weight:700;font-size:0.7em;color:#101010;'>Hi, "+staffsname+" "+stfirstname+"-"+classarray[staffclass]+" "+classarmarray[classarmtut]+"</p>";
	}

}

////////////////////////
function myclassDailyprogress(){
//console.log("dom ");
let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
let classarrylen = classarry[1].length;
let sweekcounter = sessionStorage.getItem("Countr");

let names = classarry[1][sweekcounter].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][sweekcounter].pupilsfname;

let firstpupilonlist = document.getElementById("pupilnames");
firstpupilonlist.innerHTML = names;

//console.log("dom "+names);
let updatedlabel = Number(sweekcounter)+1;
document.getElementById("listdprsummarylbl").innerHTML = names;
document.getElementById("currclasssize").innerHTML = updatedlabel +"/"+classarrylen;
	  
}


prevtbtn.addEventListener("click",sweekPrev,false);

function sweekPrev(){

let cntr = sessionStorage.getItem("Countr");
sweekcounter = Number(cntr);
if(sweekcounter <= 0){
sweekcounter = 1;
//console.log("Start");
}
sweekcounter--;
//console.log("prev "+sweekcounter);

sessionStorage.setItem("Countr",sweekcounter);

fillTopdetails(sweekcounter);

//clear for new dpr item selection
sessionStorage.removeItem("SelectedDPR");
let uldispsummry = document.getElementById("dprsummry");
uldispsummry.innerHTML = "";
}

nextbtn.addEventListener("click",sweekNext,false);
function sweekNext(){

let cntr = sessionStorage.getItem("Countr");
sweekcounter = Number(cntr);

let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
let classarrylen = classarry[1].length;

//console.log("next "+sweekcounter);

sweekcounter++;

	if(sweekcounter >= classarrylen){
	sweekcounter = classarrylen-1;
	//console.log("End "+sweekcounter);
	sessionStorage.setItem("Countr",sweekcounter);
	return false;

	}

sessionStorage.setItem("Countr",sweekcounter);

fillTopdetails(sweekcounter);

//clear for new dpr item selection
sessionStorage.removeItem("SelectedDPR");
let uldispsummry = document.getElementById("dprsummry");
uldispsummry.innerHTML = "";
}

function fillTopdetails(sweekcounter){

let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
let names = classarry[1][sweekcounter].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][sweekcounter].pupilsfname;

let pupilonlist = document.getElementById("pupilnames");
pupilonlist.innerHTML = names;

let updatedlabel = Number(sweekcounter)+1;
document.getElementById("listdprsummarylbl").innerHTML = names+"'s summary today";
document.getElementById("currclasssize").innerHTML = updatedlabel +"/"+classarry[1].length;
}


let pupilmeta = document.getElementById("submitpupildpr");
pupilmeta.addEventListener("click",sendDailyreporttodb,false);

function sendDailyreporttodb(){
let cntr = sessionStorage.getItem("Countr");
sweekcounter = Number(cntr);

let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
let names = classarry[1][sweekcounter].pupilssurname +"&nbsp;&nbsp;"+ classarry[1][sweekcounter].pupilsfname;
}


function storedprforSummaryonreveal(){

let dprselected = document.getElementsByClassName("myspecificdprs");

	for (i = 0; i < dprselected.length; i++) {
	
		dprselected[i].onchange = function(){
				
			//console.log("available "+this.id+"-"+this.value);
			processDPRselected(this.id,this.value);
		}
	}	  

}



var dprvaloo = [0,0,0,0,0,0,0,0,0,0];
function processDPRselected(id,value){
	
	if(value > 0 && value <= 4){
	dprvaloo[0] = value;
	}else if(value > 4 && value <= 14){
	dprvaloo[1] = value;
	}else if(value > 14 && value <= 20){
	dprvaloo[2] = value;
	}else if(value > 20 && value <= 24){
	dprvaloo[3] = value;
	}else if(value > 24 && value <= 29){
	dprvaloo[4] = value;
	}else if(value > 29 && value <= 38){
	dprvaloo[5] = value;
	}else if(value > 38 && value <= 44){
	dprvaloo[6] = value;
	}else if(value > 44 && value <= 50){
	dprvaloo[7] = value;
	}else if(value > 50 && value <= 55){
	dprvaloo[8] = value;
	}else if(value > 55 && value <= 60){
	dprvaloo[9] = value;
	}
	
	sessionStorage.setItem("SelectedDPR",JSON.stringify(dprvaloo));		

}


let dprlabels = ["Attendance","Temperament/Mood","Learning","Nap/Rest period","Toileting","State of health","Recreation","Appearance","Home Work","Meals"];

let dpritems = ["I was early to school","I cried when I was dropped","I was late for assembly","I was late to school","I was absent from school","I was quiet","I was happy","I was active","I was moody","I was sleepy","I was friendly","I was unhappy","I wasm curious","I was stubborn","I cried a lot today","I took part in today's activities","I was not interested in todays activities","I enjoyed my number work","I enjoyed my letter work","I enjoyed rhymes","I enjoyed Audio-Visual aid, TV programmes","I slept for a short time","I slept today","I did not sleep at all","I slept for a long time","I wet myself","I did not wet myself","I used the toilet with some help","I used the toilet myself","My diapers were changed","I was well","I vomitted","I was feverish","I had slight headache","I had stomache ache","I was at the sick bay","I had a cold","I was stooling","My temperature was a bit high","I played outdoor","I played indoors","I played with my friends","I was rough at play","I did not play","I played alone","My hair was tidy","My hair was untidy today","I was roughly dressed","I was neatly dressed","I did not wear the correct uniform to school","I did not wear my socks","I did my homework","I did not do my home work","My home work was neatly done","My home work was rough","I did not bring my home work","I ate all my food","I ate a little of my food","I ate none of my food","I did not like my food","I wanted to eat the school food"];

let rvealicon = document.getElementById("dprsummaryreeal");
rvealicon.addEventListener("click",fillSummaryonreveal,false);
function fillSummaryonreveal(){
let ftxt = "";
//let classarry = JSON.parse(sessionStorage.getItem("scweeklymeta"));
//let classarrylen = classarry.length;

let dpr_revel = JSON.parse(sessionStorage.getItem("SelectedDPR"));
let revealen = dpr_revel.length;

	
//console.log(revealen+"-"+dpritems.length);


for (i = 0; i < revealen; i++){
	
	let d = dpr_revel[i];
	let dpr_items = dpritems[d];
	//dprlabels
	
	ftxt += "<li class='collection-item'><p style='font-weight:700;font-size:0.85em;color:#880e4f;'>"+dprlabels[i]+"</p>"+dpr_items+"</li>";

}

//ftxt += "<li class='collection-item'>"++"</li>";
let uldispsummry = document.getElementById("dprsummry");

uldispsummry.innerHTML = ftxt;
}


let adminrqstbtn = document.getElementById("admindprreqst");
adminrqstbtn.addEventListener("click",function(){

pullPupilsrqstbyadmin();

},false);

function pullPupilsrqstbyadmin(){
let classpicked    = document.getElementById("selPresntclassdpr");
let classarmpicked = document.getElementById("classaliasdpr");
let chkstafftype   = JSON.parse(sessionStorage.getItem("scweeklymeta"));	
let stfid    = chkstafftype[0][0].staffrefnumbr;
let sch_id   = chkstafftype[0][0].schuid;
//console.log(stfid);
//let stfirstname = chkstafftype[0][0].stafffname;
//console.log(classpicked.value +"-"+classarmpicked.value);
///////////////////////////////////

	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				
				sessionStorage.setItem("scweeklymeta",xhttp.responseText);
				//sessionStorage.setItem("Countr",0);
				////////
				
				myclassDailyprogress();
				document.getElementById("dprmainboard").style.display = "block";
				
				/////////
				//document.getElementById('verifynow').innerHTML = xhttp.responseText;
				//location.href="attendance.html";
				//location.href="dpr.html";

			}else{
				
				location.reload();
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/auth/global/screapst/adminglob.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_admin_id="+stfid+"&snd_class="+classpicked.value+"&snd_classarm="+classarmpicked.value+"&snd_schid="+sch_id);
}