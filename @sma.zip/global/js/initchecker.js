window.onload = checkInitexist();
	function checkInitexist(){

		let getinitags = JSON.parse(sessionStorage.getItem("scweeklymeta"));
			
		if(getinitags == null){
			location.href = "index.html";
		} else if(getinitags != null){
			console.log("Initialized");
		}else{
			console.log("oops! challenges with getting page");
		}
		
	}

