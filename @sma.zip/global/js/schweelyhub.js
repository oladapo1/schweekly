document.addEventListener("DOMContentLoaded",checkInitparamdisplinks,false);
function checkInitparamdisplinks(){
	//console.log("ok");
	let chk = JSON.parse(sessionStorage.getItem("scweeklymeta"));	
	
	if(chk !== null){
	
		document.getElementById("homeattnicn").style.display = "block";
		document.getElementById("homedpricn").style.display = "block";
		
	}else if(chk == null){
	
		document.getElementById("homeattnicn").style.display = "none";
		document.getElementById("homedpricn").style.display = "none";
		
	}
}


let attn_urlicon = document.getElementById("homeattnicn");
let dpr_urlicon  = document.getElementById("homedpricn");

attn_urlicon.addEventListener("click",function(){

let v = 1;	
findUrlinkedtoicon(v);
	
},false);

dpr_urlicon.addEventListener("click",function(){
	
let v = 2;	
findUrlinkedtoicon(v);
	
},false);


function findUrlinkedtoicon(val){
	
	if(val == 1){

	location.href = "attendance.html";
		
	}else if(val == 2){

	location.href = "dpr.html";
		
	}	
}