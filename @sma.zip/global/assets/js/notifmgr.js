//setTimeout(pullMyNotifsToview,3000);	
setInterval(pullMyNotifsToview,3000);	
	
function pullMyNotifsToview(){
var mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

pullconnectrequestNotifsToview(mysa_senderid);

var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			//document.getElementById("pheldr").innerHTML = this.responseText;
			sessionStorage.setItem("myNotifs", '{"\NotifItems"\:'+this.responseText+'}');
			
			placeEachNotiftolabelforBell();
			//placeEachNotiftolabel();
			//lsidebarPOSTsBubbleNotiftolabel();
            }
        };
		
	xhttp.open("POST","scripts/notifmgr.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
}

function pullconnectrequestNotifsToview(userID_o){

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//console.log(this.responseText);
			sessionStorage.setItem("myNotifs_CnReqst", '{"\NotifItems_CnReqs"\:'+this.responseText+'}');
			placeconnectrequestNotiftolabel();
			//bcastBubbleNotiftolabel();
            }
        };
		
	xhttp.open("POST","scripts/notif_connrequest.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("myconreqst_senderid="+userID_o);
}

var notifsumdtotal_o = 0;
function placeconnectrequestNotiftolabel(){	
	var myObj_o = JSON.parse(sessionStorage.getItem("myNotifs_CnReqst"));
	var gtNotifslen_o = myObj_o.NotifItems_CnReqs.length -1;
	//alert(gtNotifslen_o);
	notifsumdtotal_o = gtNotifslen_o;
	document.getElementById("requestbubble").innerHTML = gtNotifslen_o;
}

//document.addEventListener("DOMContentLoaded",placeEachNotiftolabelforBell,false);
function placeEachNotiftolabelforBell(){

	var myObj = JSON.parse(sessionStorage.getItem("myNotifs"));
	var gtNotifslen = myObj.NotifItems.length;

	document.getElementById("notifbubble").innerHTML = myObj.NotifItems;	
	document.getElementById("notifbubblebotm").innerHTML = myObj.NotifItems;	
	
   }
   
   
   
document.addEventListener("DOMContentLoaded",lsidebarPOSTsBubbleNotiftolabel,false);
function lsidebarPOSTsBubbleNotiftolabel(){

let mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);
			document.getElementById("postbubble").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/postsbubletmpage.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
   }
   
document.addEventListener("DOMContentLoaded",bcastBubbleNotiftolabel,false);

function bcastBubbleNotiftolabel(){

let mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			//alert(this.responseText);	
			//console.log(this.responseText);
			document.getElementById("broadcastbubble").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/broadcastbubletfpage.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
   }

document.addEventListener("DOMContentLoaded",birthDayBubbleNotiftolabel,false);
function birthDayBubbleNotiftolabel(){

let mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
				//alert(this.responseText);
			document.getElementById("brthdaybubble").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/bdaybubletfpage.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
   }

document.addEventListener("DOMContentLoaded",lsidebarForumBubbleNotiftolabel,false);
function lsidebarForumBubbleNotiftolabel(){

let mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			document.getElementById("forumbubble").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/forumbubletfpage.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
   }   


document.addEventListener("DOMContentLoaded",lsidebarEventBubbleNotiftolabel,false);
function lsidebarEventBubbleNotiftolabel(){

let mysa_senderid = JSON.parse(sessionStorage.getItem("MYPersonalVALUES"));
mysa_senderid = mysa_senderid.memberid.toString();

		var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			document.getElementById("eventsbubble").innerHTML = this.responseText;
            }
        };
		
	xhttp.open("POST","scripts/eventbubletfpage.php",true);
	xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xhttp.send("sent_mysa_senderid="+mysa_senderid);
   }
   
   
