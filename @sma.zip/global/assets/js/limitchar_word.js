/* limit char-word */

function limitText(limitField, limitCount, limitNum) {
	//alert(limitNum);
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}

//limitchar_word.js
//limitText(this.form.limitedtextarea,this.form.countdown,200);