let srchbtn = document.getElementById("searchpupilbtn");

document.addEventListener("DOMContentLoaded",function(){
		
	let pupilref = sessionStorage.getItem("scwklyparentmeta");
	//let dprcount = 0;
	
	if(pupilref == null){
		
		loadDPRtoview();
		
	}else if(pupilref !== null){				 
		
		chkIftextboxempty();
		let dprcount = sessionStorage.getItem("InitDPRcount");
		createViewswithdata(dprcount);	
	}
	
},false);


let picksecprybtn = document.getElementById("viewpupilbtn");
picksecprybtn.addEventListener("click",pickSecPry,false);
function pickSecPry(){
	
let pupilclasschk = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));

let pplclas = pupilclasschk[0].presentclass;
	console.log(pplclas);
	
	////////
		
	if(pplclas >= 0 && pplclas <= 9){
			
		location.href="primary.html";
						
		}else if(pplclas >= 10 && pplclas <= 15){
			
		location.href="secondary.html";		

		}
		
	////////
	
}

srchbtn.addEventListener("click",loadDPRtoview,false);

srchbtn.addEventListener("click",function(){
		
let srchinput = document.getElementById("srchpupiltxt").value;

	if(srchinput == ""){
		
		let alrt = document.getElementById("alertopbar");
		alrt.innerHTML = "Search box cannot be empty, put pupil id";
		alrt.style.display = "block";
		setTimeout(function(){alrt.style.display = "none";},1000)
		return false;
		}	
		
		document.getElementById("searchpupilbtn").innerHTML = "searching <span class='spinner-border text-info' role='status' style='width:16px;height:16px;' id='busysrchresp'><span class='visually-hidden'>Loading...</span></span>";
		

	
},false);


function chkIftextboxempty(){
	
	let srchinput = document.getElementById("srchpupiltxt").value;

	if(srchinput == ""){
		
		let alrt = document.getElementById("alertopbar");
		alrt.innerHTML = "Search box cannot be empty, enter pupil ID";
		alrt.style.display = "block";
		setTimeout(function(){alrt.style.display = "none";},1000)
		return false;
		}
	
}


function loadDPRtoview(){
		
	let srchinput = document.getElementById("srchpupiltxt").value;
	if(srchinput == ""){
		
		let alrt = document.getElementById("alertopbar");
		alrt.innerHTML = "Search box cannot be empty, fill in pupil id";
		alrt.style.display = "block";
		setTimeout(function(){alrt.style.display = "none";},1000)
		return false;
		}
		
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				let initload = JSON.parse(xhttp.responseText);
			
			if(initload[0] == 0){
				
				let alertbar = document.getElementById("alertopbar");
				alertbar.innerHTML = "Enter correct id, pupil id not found";
				alertbar.style.display = "block";
				setTimeout(function(){alertbar.style.display = "none";},3000);
				document.getElementById("searchpupilbtn").innerHTML = "Search";

				return false;

			}else if(initload[0] !== 0){
				
				sessionStorage.setItem("scwklyparentmeta",xhttp.responseText);
								
				let dprcount = 0;
				sessionStorage.setItem("InitDPRcount",dprcount);
				console.log(dprcount +" loadview");
				document.getElementById("searchpupilbtn").innerHTML = "Search";

				createViewswithdata(dprcount);
				//pickSecPry();

			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/findpupilforparent.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_pupl_id="+srchinput);
}



	var clsarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6","JSS 1","JSS 2","JSS 3","SSS 1","SSS 2","SSS 3"];
	
	var clsarmry = ["A","B","C","D","E","F"];
		
	
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

	var mnth = ["January","February","March","April","May","June","July","August","September","October","November","December"];


function createViewswithdata(statuscount){
	
	//console.log(statuscount +" statuscounted");
	
	let guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	console.log(guard_data[1][0].stafffname);
	console.log(guard_data[2][0].id);
	console.log(guard_data[2][1].id);
	console.log(guard_data[3].length);
	console.log(guard_data[3][0]);
	//console.log(guard_data[4]);
	
	
	if(guard_data === null){
		
		console.log("Guardian meta required");
		return false;
	}
	
	if(guard_data[0].pupilssurname == undefined || guard_data[0].pupilsfname == undefined || guard_data[0].presentclass == undefined || guard_data[0].classalias == undefined){	

	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = "Not found";
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = "Not found";

	}
		
	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = guard_data[0].pupilssurname +" "+guard_data[0].pupilsfname;
	
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = clsarray[guard_data[0].presentclass] +" "+clsarmry[guard_data[0].classalias];
	
	
	//icons controlling the attendances status
	
	if(guard_data[3][0] == 1){
		
		document.getElementById("mornrolcall_on").style.display = "inline-block";
		document.getElementById("mornrolcall_off").style.display = "none";
		
	}
	
	if(guard_data[3][0] == 0){
		
		document.getElementById("mornrolcall_off").style.display = "inline-block";
		document.getElementById("mornrolcall_on").style.display = "none";
		
	}
	
	if(guard_data[3][1] == 1){
		
		document.getElementById("afternrollcall_on").style.display = "inline-block";
		document.getElementById("afternrollcall_off").style.display = "none";
		
	}
	
	if(guard_data[3][1] == 0){
		
		document.getElementById("afternrollcall_off").style.display = "inline-block";
		document.getElementById("afternrollcall_on").style.display = "none";
		
	}
	
}