let srchbtn = document.getElementById("srchpupilbtn");

document.addEventListener("DOMContentLoaded",function(){
		
	let pupilref = sessionStorage.getItem("scwklyparentmeta");
	//let dprcount = 0;
	
	if(pupilref == null){
		
		//loadDPRtoview();
		//console.log("Hy");
		
	}else if(pupilref !== null){
				
		let dprcount = sessionStorage.getItem("InitDPRcount");
		
		createViewswithdata(dprcount);
		currenAttndate(dprcount);
		console.log(dprcount +" DOMC");
	}
	
},false);


let load_replysbtn = document.getElementById("loadreplysbtn");
load_replysbtn.addEventListener("click",collateMessagereplies,false);

function collateMessagereplies(){
	
	document.getElementById("busyloadreplys").style.display = "block";	
	
	let minimeta = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	let schid   = minimeta[0].schuid;
	let staffid = minimeta[1][0].staffrefnumbr;
	let pplid   = minimeta[0].pupilrefnumbr;
	let pplclas = minimeta[0].presentclass;
	let pplarm  = minimeta[0].classalias;
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				
			if(xhttp.responseText){
				
				let replymsg_place = document.getElementById("replymsgplace");
				replymsg_place.innerHTML = xhttp.responseText;
				document.getElementById("busyloadreplys").style.display = "none";

			}else{
				
				//location.reload();
				console.log(xhttp.responseText);
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/pullrepliesfromsch.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_pupl_id="+pplid+"&schuid="+schid+"&stfruid="+staffid+"&snd_class="+pplclas+"&snd_clarm="+pplarm);	
}



let msgbtn = document.getElementById("gadsendmsgbtn");
msgbtn.addEventListener("click",sendparentMessages,false);

function sendparentMessages(){
	
	let pupilmeta    = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	let slctpriority = document.getElementById("mesgaepriority");
	let txtbody      = document.getElementById("gadmsgtxtarea");
	let totchers     = document.getElementById("gadmsgtotcher");
	let toadmin      = document.getElementById("gadmsgtoadmin");
	let schid        = pupilmeta[0].schuid;
	let staffid      = pupilmeta[1][0].staffrefnumbr;
	let pplidmsgcreator = pupilmeta[0].pupilrefnumbr;
	
	let pplclassid   = pupilmeta[0].presentclass; 
	let pplclassarm  = pupilmeta[0].classalias;
	
	let rcver;
	//console.log(slctpriority.value); return false;
	
	if(slctpriority.value == 444){
		
		alert("Select a priority");
		return false;
		
	}
	
	if(txtbody.value === ""){
		
		alert("Message area cannot be empty");
		return false;
		
	}
	
	if(totchers.checked && toadmin.checked){
		
		rcver = 2;
		
	}else if(totchers.checked){
		
		rcver = 0;
		
	}else if(toadmin.checked){
		
		rcver = 1;
		
	}else{
		
		alert ("You have to pick a receiver; teacher or admin");
		return false;
	}
	
	//console.log(rcver); return false;
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				document.getElementById("gadsendmsgbtn").innerHTML = "Sent";
				setTimeout(location.reload(),5000);

			}else{
				alert("Seek support");
				//location.reload();
			}		
  	    }
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/sendparentmsgtosch.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_schuid="+schid+"&stffuid="+staffid+"&rceiver="+rcver+"&txtbody="+txtbody.value+"&msgprity="+slctpriority.value+"&msgcreator="+pplidmsgcreator+"&snd_class="+pplclassid+"&snd_clarm="+pplclassarm);
}

/* limit char-word */
let limittxtmsg = document.getElementById("gadmsgtxtarea");
limittxtmsg.addEventListener("keydown",function(){
	
	let txtarea    = document.getElementById("gadmsgtxtarea");
	let limitchars = document.getElementById("limchars");
	let limnumbr   = 200;
	limitText(txtarea,limitchars,limnumbr);
	
},false);

function limitText(limitField, limitCount, limitNum) {
	//console.log(limitField.value);
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}


	var clsarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6","JSS 1","JSS 2","JSS 3","SSS 1","SSS 2","SSS 3"];
	var clsarmry = ["A","B","C","D","E","F"];
		
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

	var mnth = ["January","February","March","April","May","June","July","August","September","October","November","December"];


	var dprlabelsec = ["Attentiveness","Overactivity","Impulsiveness","Cooperative","Anxiety","Withdrawal","Appearance","Home Work","Non-aggressive","Aggressiveness"];

	var dpritems = ["I had difficulty paying attention","Difficulty sustaining alertness","I did'nt take to instructions","I was distracted by extraneous stimuli","Very calm and collected","Fidgets and jumps out of seat","Walked around the classroom inappropriately","Runs around the classroom inappropriately","I jumped on a desk","I stood on a desk","I behaved orderly","I act impulsively","Blurts out answers before questions ends","I interrupt others","I butt into conversations","I often don't wait for a turn","I refused to follow instructions or rules","I acted defiantly","I argued or talk back to the teacher","I pouted my mouth","I refused to take turns or share","I cheated","I pulled my hair","I bit my nails severally","I twitched repetitively","I paced-shook repetitively","I tapped my hands or feet","I show a tense or worried expression","I complained of a stomach ache","I am withdrawn from the classroom activities","I stared blankly or daydream","I inappropriately fiddle with objects","I appears sullen or detached","I had stomache ache","I was confused all the time","I was at the sick bay all day","I visited the toilet severally","My hair was tidy","My hair was untidy today<","I was roughly dressed","I was neatly dressed","I did not wear the correct uniform to school","I did not wear my socks","I submitted my homework","I did not do my home work","My home work was neatly done","My home work was rough","I did not bring my home work","I used swear word","I used a vulgar language","I teased others inconsiderately","I bother others trying to work","I farted offensively","I touched my genitals publicly","I hissed publicly","I hissed at teacher","I threw objects at other(s)","I spat at another","I threatened another","I bullied another","I verbally abused another","I broke, defaced or destroyed things","Conduct was satisfactory"];
	

let movnext = document.getElementById("nxtee");
let movprev = document.getElementById("prevee");
	 
movnext.addEventListener("click",function(){
		 
		 let dprcount = JSON.parse(sessionStorage.getItem("InitDPRcount"));
		 let guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
		
		//clean attendance icons
		 hideattndanceIcons();
		 
		 dprcount++;
		 
		 let lenload = guard_data[2].length;
		 
		 if(dprcount >= lenload){
			 
			 dprcount = lenload - 1;
			 sessionStorage.setItem("InitDPRcount",dprcount);
		 }
		 
		 console.log(dprcount +" nxt");
		 sessionStorage.setItem("InitDPRcount",dprcount);
		 
		 createViewswithdata(dprcount);
		 //mgrAttendances(dprcount);
		 
	 },false);
	 
movprev.addEventListener("click",function(){
		 
		 let dprcount = JSON.parse(sessionStorage.getItem("InitDPRcount"));
		 
		 //clean attendance icons
		 hideattndanceIcons();
		 
		 dprcount--;
		 		 
		 if(dprcount < 0){
			 dprcount = 0;
			 sessionStorage.setItem("InitDPRcount",dprcount);
		 }
		 
		 sessionStorage.setItem("InitDPRcount",dprcount);
		 console.log(dprcount +" prev");
		 
		 createViewswithdata(dprcount);
		 //mgrAttendances(dprcount);
		 
	 },false);


function createViewswithdata(statuscount){
	
	//console.log(statuscount +" count"); return false;
		
	let guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	if(guard_data === null){
		
		console.log("Guardian meta required");
		return false;
	}
	
	//document.getElementById("primarysch").style.display = "block";

	// place pupil meta
	
	if(guard_data[0].pupilssurname == undefined || guard_data[0].pupilsfname == undefined || guard_data[0].presentclass == undefined || guard_data[0].classalias == undefined){	

	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = "Not found";
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = "Not found";

	}
		
	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = guard_data[0].pupilssurname +" "+guard_data[0].pupilsfname;
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = clsarray[guard_data[0].presentclass] +" "+clsarmry[guard_data[0].classalias];
	
	  
	//let ptcher = document.getElementById("pupilpictopbrd").innerHTML = ; 
	
	//dpr - loading
	 dprlen = guard_data[2].length;
	let dprcount = statuscount;//JSON.parse(sessionStorage.getItem("InitDPRcount"));
	
	for(i = 0; i < dprlen; i++){
		
		if(i == dprcount){
		
		let frmtdate   = new Date(guard_data[2][i].dateposted);
		let frmtyr     = frmtdate.getFullYear();
		let frmtmnth   = frmtdate.getMonth();
		let frmtday    = frmtdate.getDate(); //+days[frmtday]+
		//DPR-for-today
        document.getElementById("pupildatetopbrd").innerHTML = mnth[frmtmnth]+" "+frmtday+", "+frmtyr;
		document.getElementById("attnvesec").innerHTML    = dpritems[guard_data[2][i].attentiveness];
		document.getElementById("oactvsec").innerHTML     = dpritems[guard_data[2][i].overactivity];
		document.getElementById("impluse").innerHTML      = dpritems[guard_data[2][i].impulsiveness];
		document.getElementById("cooprsec").innerHTML     = dpritems[guard_data[2][i].cooperative];
		document.getElementById("anxietysec").innerHTML   = dpritems[guard_data[2][i].anxiety];
		document.getElementById("wthtdrwalsec").innerHTML = dpritems[guard_data[2][i].withdrawal];
		document.getElementById("gappearancsec").innerHTML = dpritems[guard_data[2][i].appearance];
		document.getElementById("gahomewrksec").innerHTML    = dpritems[guard_data[2][i].homework];
		document.getElementById("nonaggrsve").innerHTML   = dpritems[guard_data[2][i].nonaggressive];
		document.getElementById("aggrsveness").innerHTML  = dpritems[guard_data[2][i].aggressive];
		
			
		//homework-for-today
				
		let lenhwrk = guard_data[4].length;
		let hrwork = guard_data[4][statuscount];
		if(hrwork == undefined || hrwork == -1){
			
			document.getElementById("hwmwrkdte").innerHTML = mnth[frmtmnth]+" "+frmtday+", "+frmtyr;
			document.getElementById("homeworklysec").innerHTML = "Not availaible";
			
		}else{
			
			//console.log(lenhwrk +" homework "+statuscount);
			document.getElementById("hwmwrkdte").innerHTML = mnth[frmtmnth]+" "+frmtday+", "+frmtyr;
			document.getElementById("homeworklysec").innerHTML = guard_data[4][statuscount].homewrk;
			
		}
			
		}	
				
	}
	
}


//
function currenAttndate(statuscount){
	
	hideattndanceIcons();
	
	var guard_data;
	
	if(statuscount == 0){
		
		guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
		
		if(guard_data === null){
			
			console.log("Guardian meta required");
			return false;
		}
	}
	
		//attendance-for-today

	if(guard_data[3][0] == 1){
		
		document.getElementById("mornrolcall_on").style.display = "inline-block";
		document.getElementById("mornrolcall_off").style.display = "none";
		
	}
	
	if(guard_data[3][0] == 0){
		
		document.getElementById("mornrolcall_off").style.display = "inline-block";
		document.getElementById("mornrolcall_on").style.display = "none";
		
	}
	
	//afternoon
	let atrnoon = 1;
	console.log(atrnoon); 
	if(guard_data[3][atrnoon] == 1){
		
		document.getElementById("afternrollcall_on").style.display = "inline-block";
		document.getElementById("afternrollcall_off").style.display = "none";
		
	}
	
	if(guard_data[3][atrnoon] == 0){
		
		document.getElementById("afternrollcall_off").style.display = "inline-block";
		document.getElementById("afternrollcall_on").style.display = "none";
		
	}
	
	
}

let dateattndances = document.getElementById("attndates");
dateattndances.addEventListener("change",function(){
	
	//console.log(dateattndances.value);
	
	if(dateattndances.value == undefined || dateattndances.value == ""){
			
			alert("Date has to be supplied");
			return false;
		}
		
	let pupil_data;
		
		pupil_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
		
		if(pupil_data === null){
			
			console.log("Pupil UID required");
			return false;
		}
		
		//run busy indicator
		document.getElementById("attnloadbusy").style.display = "inline-block";

		//console.log(pupil_data[0].pupilrefnumbr);
		
	/////////////////////////////////
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200){  
					
					//alert(xhttp.responseText);
					//console.log(xhttp.responseText);
					
					//switch off busy indicator
					//run busy indicator
					document.getElementById("attnloadbusy").style.display = "none";
		
					let attnload = JSON.parse(xhttp.responseText);
					if(attnload == -1){
						
						alert("Attendance not available");
						hideattndanceIcons();
						return false;
					}
					mgrAttendances(attnload);
					//sessionStorage.setItem("scwklyparentmeta",xhttp.responseText);
									
					//let dprcount = 0;
					//sessionStorage.setItem("InitDPRcount",dprcount);
					//console.log(dprcount +" loadview");
					//document.getElementById("searchpupilbtn").innerHTML = "Search";

					//createViewswithdata(dprcount);
						
		}
	};
	
	 /* Using POST */
	let attndte = dateattndances.value; 
	let ppil_data = pupil_data[0].pupilrefnumbr;
xhttp.open("POST","../assets/scripts/app/findattnforparentbydate.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("chk_pupl_attn_by_date="+attndte+"&gt_pupl_id="+ppil_data);
	
	
	//////////////////////////////////
	
},false);

function mgrAttendances(attn_vals){
	
	hideattndanceIcons();
		//attendance-for-today

	if(attn_vals[0] == 1){
		
		document.getElementById("mornrolcall_on").style.display = "inline-block";
		document.getElementById("mornrolcall_off").style.display = "none";
		
	}
	
	if(attn_vals[0] == 0){
		
		document.getElementById("mornrolcall_off").style.display = "inline-block";
		document.getElementById("mornrolcall_on").style.display = "none";
		
	}
	
	//afternoon
	
	if(attn_vals[1] == 1){
		
		document.getElementById("afternrollcall_on").style.display = "inline-block";
		document.getElementById("afternrollcall_off").style.display = "none";
		
	}
	
	if(attn_vals[1] == 0){
		
		document.getElementById("afternrollcall_off").style.display = "inline-block";
		document.getElementById("afternrollcall_on").style.display = "none";
		
	}
	
	if(attn_vals[0] == "" || attn_vals[1] == ""){
			
			
		}
	
}

function hideattndanceIcons(){
	
	document.getElementById("mornrolcall_off").style.display = "none";
	document.getElementById("mornrolcall_on").style.display = "none";
	document.getElementById("afternrollcall_off").style.display = "none";
	document.getElementById("afternrollcall_on").style.display = "none";
		
}