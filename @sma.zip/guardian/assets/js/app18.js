let srchbtn = document.getElementById("srchpupilbtn");

document.addEventListener("DOMContentLoaded",function(){
	//    pupilsrchfrm  
		
	let pupilref = sessionStorage.getItem("scwklyparentmeta");
		
		//loadDPRtoview();

	if(pupilref == null){
		
		loadDPRtoview();
		
	}else if(pupilref !== null){
		
		let dprcount = sessionStorage.getItem("InitDPRcount");
		createViewswithdata(dprcount);
		console.log(dprcount +" DOMC");
	}
	
	
},false);


/*function checkifPupilexist(){
	
	
	
}*/

srchbtn.addEventListener("click",loadDPRtoview,false);

srchbtn.addEventListener("click",function(){
		
	let srchinput = document.getElementById("srchpupiltxt").value;

	if(srchinput == ""){
		
		let alrt = document.getElementById("alertopbar");
		alrt.innerHTML = "Search box cannot be empty, enter pupil id";
		alrt.style.display = "block";
		setTimeout(function(){alrt.style.display = "none";},1000)
		//alert("Enter pupil id");
		return false;
		}
		
		document.getElementById("srchpupilbtn").innerHTML = "searching <span class='spinner-border text-info' role='status' style='width:16px;height:16px;' id='busysrchresp'><span class='visually-hidden'>Loading...</span></span>";
		

	
},false);

function loadDPRtoview(){
	
	console.log("ok");
	let srchinput = document.getElementById("srchpupiltxt").value;
	
	if(srchinput == ""){
		
		let alrt = document.getElementById("alertopbar");
		alrt.innerHTML = "Search box cannot be empty, enter pupil id";
		alrt.style.display = "block";
		setTimeout(function(){alrt.style.display = "none";},1000)
		//alert("Enter pupil id");
		return false;
	}
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				let initload = JSON.parse(xhttp.responseText);
			
			if(initload[0] == 0){
				
				let alertbar = document.getElementById("alertopbar");
				alertbar.innerHTML = "Enter correct id, pupil id not found";
				alertbar.style.display = "block";
				setTimeout(function(){alertbar.style.display = "none";},3000);
				document.getElementById("srchpupilbtn").innerHTML = "Search";

				return false;

			}else if(initload[0] !== 0){
				
				sessionStorage.setItem("scwklyparentmeta",xhttp.responseText);
								
				let dprcount = 0;
				sessionStorage.setItem("InitDPRcount",dprcount);
				console.log(dprcount +" loadview");
				document.getElementById("srchpupilbtn").innerHTML = "Search";

				createViewswithdata(dprcount);

			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/findpupilforparent.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_pupl_id="+srchinput);
}


/*function forwardnewMessages(){
	
	
}
*/

let load_replysbtn = document.getElementById("loadreplysbtn");
load_replysbtn.addEventListener("click",collateMessagereplies,false);

function collateMessagereplies(){
	
	document.getElementById("busyloadreplys").style.display = "block";	
	
	let minimeta = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	let schid   = minimeta[0].schuid;
	let staffid = minimeta[1][0].staffrefnumbr;
	let pplid   = minimeta[0].pupilrefnumbr;
	let pplclas = minimeta[0].presentclass;
	let pplarm  = minimeta[0].classalias;
	
	/*console.log(minimeta[0].schuid);
	console.log(minimeta[1][0].staffrefnumbr);
	console.log(minimeta[0].pupilrefnumbr);
	return false;*/
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
				//alert(xhttp.responseText);
				
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				//console.log(xhttp.responseText);
				
				//sessionStorage.setItem("scwklyparentmeta",xhttp.responseText);
				
				let replymsg_place = document.getElementById("replymsgplace");
				replymsg_place.innerHTML = xhttp.responseText;
				document.getElementById("busyloadreplys").style.display = "none";
				//let dprcount = 0;
				//sessionStorage.setItem("InitDPRcount",dprcount);
				//console.log(dprcount +" loadview");
				
				//document.getElementById("srchpupilbtn").innerHTML = "Search";
				//createViewswithdata(dprcount);
				//sessionStorage.setItem("Countr",0);
				//location.href="dpr.html";

			}else{
				
				//location.reload();
				console.log(xhttp.responseText);
			}		
  	}
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/pullrepliesfromsch.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("snd_pupl_id="+pplid+"&schuid="+schid+"&stfruid="+staffid+"&snd_class="+pplclas+"&snd_clarm="+pplarm);
	
	
}


let msgbtn = document.getElementById("gadsendmsgbtn");

msgbtn.addEventListener("click",sendparentMessages,false);

function sendparentMessages(){
	
	let pupilmeta    = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	let slctpriority = document.getElementById("hworkpriority");
	let txtbody      = document.getElementById("gadmsgtxtarea");
	let totchers     = document.getElementById("gadmsgtotcher");
	let toadmin      = document.getElementById("gadmsgtoadmin");
	let schid        = pupilmeta[0].schuid;
	let staffid      = pupilmeta[1][0].staffrefnumbr;
	let pplidmsgcreator = pupilmeta[0].pupilrefnumbr;
	
	let pplclassid   = pupilmeta[0].presentclass; 
	let pplclassarm  = pupilmeta[0].classalias;
	
	let rcver;
	
	if(slctpriority.value == 444){
		
		alert("Select a priority");
		return false;
		
	}
	
	if(txtbody.value === ""){
		
		alert("Message area cannot be empty");
		return false;
		
	}
	
	if(totchers.checked && toadmin.checked){
		
		rcver = 2;
		
	}else if(totchers.checked){
		
		rcver = 0;
		
	}else if(toadmin.checked){
		
		rcver = 1;
		
	}else{
		
		alert ("You have to pick a receiver; teacher or admin");
		return false;
	}
	
	//console.log(rcver); return false;
	
	/* create xhr object */
	var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200){  
				
			if(xhttp.responseText){
				//alert(xhttp.responseText);
				console.log(xhttp.responseText);
				document.getElementById("gadsendmsgbtn").innerHTML = "Sent";
				setTimeout(location.reload(),5000);

			}else{
				aler("Seek support");
				//location.reload();
			}		
  	    }
	};
	
	 /* Using POST */
	 
xhttp.open("POST","../assets/scripts/app/sendparentmsgtosch.php",true);
xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xhttp.send("send_schuid="+schid+"&stffuid="+staffid+"&rceiver="+rcver+"&txtbody="+txtbody.value+"&msgprity="+slctpriority.value+"&msgcreator="+pplidmsgcreator+"&snd_class="+pplclassid+"&snd_clarm="+pplclassarm);
}

/* limit char-word */
let limittxtmsg = document.getElementById("gadmsgtxtarea");
limittxtmsg.addEventListener("keydown",function(){
	
	let txtarea    = document.getElementById("gadmsgtxtarea");
	let limitchars = document.getElementById("limchars");
	let limnumbr   = 200;
	limitText(txtarea,limitchars,limnumbr);
	
},false);

function limitText(limitField, limitCount, limitNum) {
	//console.log(limitField.value);
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}


	var clsarray = ["Reception 1","Reception 2","Nursery 1","Nursery 2","Basic 1","Basic 2","Basic 3","Basic 4","Basic 5","Basic 6"];
	var clsarmry = ["A","B","C","D","E","F"];
	
	let dpritems = ["I was early to school","I cried when I was dropped","I was late for assembly","I was late to school","I was absent from school","I was quiet","I was happy","I was active","I was moody","I was sleepy","I was friendly","I was unhappy","I wasm curious","I was stubborn","I cried a lot today","I took part in today's activities","I was not interested in todays activities","I enjoyed my number work","I enjoyed my letter work","I enjoyed rhymes","I enjoyed Audio-Visual aid, TV programmes","I slept for a short time","I slept today","I did not sleep at all","I slept for a long time","I wet myself","I did not wet myself","I used the toilet with some help","I used the toilet myself","My diapers were changed","I was well","I vomitted","I was feverish","I had slight headache","I had stomache ache","I was at the sick bay","I had a cold","I was stooling","My temperature was a bit high","I played outdoor","I played indoors","I played with my friends","I was rough at play","I did not play","I played alone","My hair was tidy","My hair was untidy today","I was roughly dressed","I was neatly dressed","I did not wear the correct uniform to school","I did not wear my socks","I did my homework","I did not do my home work","My home work was neatly done","My home work was rough","I did not bring my home work","I ate all my food","I ate a little of my food","I ate none of my food","I did not like my food","I wanted to eat the school food"];	
	
	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

	var mnth = ["January","February","March","April","May","June","July","August","September","October","November","December"];


let movnext = document.getElementById("nxtee");
let movprev = document.getElementById("prevee");
	 
movnext.addEventListener("click",function(){
		 
		 let dprcount = JSON.parse(sessionStorage.getItem("InitDPRcount"));
		 let guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
		 
		 dprcount++;
		 
		 let lenload = guard_data[2].length;
		 
		 if(dprcount >= lenload){
			 
			 dprcount = lenload - 1;
			 sessionStorage.setItem("InitDPRcount",dprcount);
		 }
		 
		 console.log(dprcount +" nxt");
		 sessionStorage.setItem("InitDPRcount",dprcount);
		 
		 createViewswithdata(dprcount);
		 
	 },false);
	 
movprev.addEventListener("click",function(){
		 
		 let dprcount = JSON.parse(sessionStorage.getItem("InitDPRcount"));
		 
		 dprcount--;
		 		 
		 if(dprcount < 0){
			 dprcount = 0;
			 sessionStorage.setItem("InitDPRcount",dprcount);
		 }
		 
		 sessionStorage.setItem("InitDPRcount",dprcount);
		 console.log(dprcount +" prev");
		 
		 createViewswithdata(dprcount);
		 
	 },false);

function createViewswithdata(statuscount){
	
	//console.log(statuscount +" count"); return false;
	
	let guard_data = JSON.parse(sessionStorage.getItem("scwklyparentmeta"));
	
	if(guard_data === null){
		
		console.log("Guardian meta required");
		return false;
	}
	
	//console.log(guard_data.length);
	//console.log(guard_data[0].pupilsfname+" pupil items");return false;
	//console.log(guard_data[1].length+" staff load");
	//console.log(guard_data[2].length+" dpr load");
	//console.log(guard_data[3].length+" attndance load");
	//console.log(guard_data[4].length+" homework load");
	//console.log(guard_data[5].length+" homework load");
	
	// place pupil meta
	
	if(guard_data[0].pupilssurname == undefined || guard_data[0].pupilsfname == undefined || guard_data[0].presentclass == undefined || guard_data[0].classalias == undefined){	

	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = "Not found";
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = "Not found";

	}
		
	let pnames = document.getElementById("ppuilnametopbrd").innerHTML = guard_data[0].pupilssurname +" "+guard_data[0].pupilsfname;
	let pclass = document.getElementById("pupilclasstobrd").innerHTML = clsarray[guard_data[0].presentclass] +" "+clsarmry[guard_data[0].classalias];
	
	  
	//let ptcher = document.getElementById("pupilpictopbrd").innerHTML = ; 
	
	//dpr - loading
	 dprlen = guard_data[2].length;
	let dprcount = statuscount;//JSON.parse(sessionStorage.getItem("InitDPRcount"));
	
	for(i = 0; i < dprlen; i++){
		
		if(i == dprcount){
		
		let frmtdate   = new Date(guard_data[2][i].dateposted);
		let frmtyr     = frmtdate.getFullYear();
		let frmtmnth   = frmtdate.getMonth();
		let frmtday    = frmtdate.getDate(); //+days[frmtday]+
		//DPR-for-today
        document.getElementById("pupildatetopbrd").innerHTML = mnth[frmtmnth]+" "+frmtday+", "+frmtyr;
		document.getElementById("gaattendance").innerHTML = dpritems[guard_data[2][i].attendance];
		document.getElementById("gatemprmood").innerHTML  = dpritems[guard_data[2][i].temperament];
		document.getElementById("galearning").innerHTML   = dpritems[guard_data[2][i].learning];
		document.getElementById("ganaprest").innerHTML    = dpritems[guard_data[2][i].naprest];
		document.getElementById("gatoiletng").innerHTML   = dpritems[guard_data[2][i].toileting];
		document.getElementById("gasthealth").innerHTML   = dpritems[guard_data[2][i].healthstatus];
		document.getElementById("garecreatn").innerHTML   = dpritems[guard_data[2][i].recreation];
		document.getElementById("gaappearance").innerHTML = dpritems[guard_data[2][i].appearance];
		document.getElementById("gahomewrk").innerHTML    = dpritems[guard_data[2][i].homework];
		document.getElementById("gameals").innerHTML      = dpritems[guard_data[2][i].meals];
		
		//attn-for-today
		
		//console.log(guard_data[3][i].absentees);
		let attnstatusload  = guard_data[3][i].absentees;
		let abscencestatus = attnstatusload.split(",");
		//console.log(abscencestatus);
		
		//console.log(presncstatus.length);
		
		loadlen = abscencestatus.length;
		
		let pupilid = guard_data[0].pupilrefnumbr;
		
		for(j = 0; j < loadlen; j++){
			
			let absteentys = abscencestatus[j];
			
			if(pupilid == absteentys){
				
				//console.log(j +" absence found");
				
				document.getElementById("presencetrue").style.display = "block";
				document.getElementById("presencetrue").innerHTML = "Absent";
				
			}else if(absteentys == 0){
				
				//console.log(absteentys);
				document.getElementById("presencetrue").style.display = "block";
				
			}
			
		}
		
		//homework-for-today
				
		let lenhwrk = guard_data[4].length;
		//console.log(lenhwrk +" homework "+statuscount);
		document.getElementById("homeworkly").innerHTML = guard_data[4][statuscount].homewrk;
			
		}	
				
	}
	
}