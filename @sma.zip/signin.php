
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Signin</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Bootstrap core CSS -->
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="assets/dist/css/signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
<main class="form-signin">
<div class="row">
<div class="col-sm-12 col-xs-12">
<p style="font-size:2.5em;"><img src="assets/images/templogo.png" alt="" class="">SchWeekly</p>
</div>
<div class="col-sm-12 col-xs-12">
<p style="line-height:1.5;font-size:0.9em;">Handles pupil daily reporting better <br> builds engaging community.</p>
<span style="font-size:12px;color:red;" id="verifynow"></span>
</div>
</div>
  
  <div class="bd-example">
        <nav>
          <div class="nav nav-tabs mb-3" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-admin-tab" data-bs-toggle="tab" data-bs-target="#nav-admin" type="button" role="tab" aria-controls="nav-admin" aria-selected="false">Admin</button>
            <button class="nav-link" id="nav-teacher-tab" data-bs-toggle="tab" data-bs-target="#nav-teacher" type="button" role="tab" aria-controls="nav-teacher" aria-selected="true">Staff</button>
          </div>
        </nav>
<div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade active show" id="nav-admin" role="tabpanel" aria-labelledby="nav-admin-tab">
     <p>
	<form id="adminlogin">
    <div class="form-floating">
      <input type="email" class="form-control" id="login_owaun" placeholder="enter school email">
      <label for="login_owaun">Email address</label>
    </div>
    <div class="form-floating mt-1">
      <input type="password" class="form-control" id="login_owapwd" placeholder="enter school key">
      <label for="login_owapwd">Password</label>
    </div>

   <!--  <div class="checkbox mb-3">
      <label>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
    </div> -->
    <button class="w-100 btn btn-lg btn-primary" type="button" id="login_owabtnid">Sign in <span class="spinner-border text-light" role="status" style="width:24px;height:24px;display:none;margin-top:10px;" id="resplogin"><span class="visually-hidden">Loading...</span></span></button>
  </form>
			</p>
          </div>
          <div class="tab-pane fade" id="nav-teacher" role="tabpanel" aria-labelledby="nav-teacher-tab">
            <p>	
	<form id="tcherlogin">
    <div class="form-floating">
      <input type="password" class="form-control" id="login_tchrpwd" placeholder="enter teacher passkey">
      <label for="login_tchrpwd">Password</label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="button" id="login_owabtchernid">Staff's Login <span class="spinner-border text-light" role="status" style="width:24px;height:24px;display:none;margin-top:10px;" id="resplogintchr"><span class="visually-hidden">Loading...</span></span></button>
  </form>
			</p>
          </div>
        </div>
        </div>
<div class="" style="margin-top:30px;">
<span><a href="#" class="" data-bs-toggle="modal" data-bs-target="#mySignupSchEngine">Register your School</a></span> | <span><a href="#">Terms &amp; Conditions</a></span>
</div>
<?php include"assets/includes/signupsengine.inc";?>
</main>
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/scripts/app/login.js"></script>
<script src="assets/scripts/app/signup.js"></script>
<!--<script src="assets/scripts/auth/global/login.js"></script>-->
</body>
</html>
